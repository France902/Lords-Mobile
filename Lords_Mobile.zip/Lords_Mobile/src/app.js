/**
 * ============================================================
 *  src/app.js
 *  Logica client-side — Lords Mobile
 * ============================================================
 *
 *  Questo file è diviso in due grandi sezioni:
 *
 *  ── SEZIONE CLIENT ──────────────────────────────────────────
 *  Tutto ciò che riguarda la pagina: canvas, rendering, UI.
 *  Non fa nessuna richiesta al server.
 *  È l'unica sezione attiva per ora.
 *
 *  ── SEZIONE SERVER (API) ────────────────────────────────────
 *  Funzioni che comunicano con il backend via fetch().
 *  Tutte disabilitate con un flag: USE_SERVER = false.
 *  Quando il server è pronto basta cambiare quel valore.
 *
 * ============================================================
 */


// ════════════════════════════════════════════════════════════
//  CONFIGURAZIONE GLOBALE
// ════════════════════════════════════════════════════════════

/*
    USE_SERVER controlla se le funzioni API sono attive.
    false → tutto gira in locale, nessuna richiesta al server
    true  → le funzioni API chiamano il backend Express
*/
const USE_SERVER = false;




// ════════════════════════════════════════════════════════════
//  SEZIONE CLIENT
//  Canvas, rendering e logica di interfaccia.
//  Funziona completamente offline, senza server.
// ════════════════════════════════════════════════════════════


// ─────────────────────────────────────────────────────────────
//  Configurazione del canvas
//  Tutte le misure del canvas stanno qui — un solo posto da modificare.
// ─────────────────────────────────────────────────────────────

const CANVAS_CONFIG = {
    // Dimensioni di riferimento (come fosse su desktop standard)
    BASE_WIDTH:  900,
    BASE_HEIGHT: 600,

    // Percentuale massima dello schermo che il canvas può occupare
    MAX_WIDTH_PERCENT:  0.96,   // 96% della larghezza viewport
    MAX_HEIGHT_PERCENT: 0.78,   // 78% dell'altezza viewport (lascia spazio all'header)
};


// ─────────────────────────────────────────────────────────────
//  createCanvas()
//  Crea l'elemento <canvas>, lo aggancia al DOM e lo ridimensiona.
//  Chiamato una sola volta all'avvio da init().
//
//  Ritorna: { canvas, ctx } — l'elemento e il suo contesto 2D
// ─────────────────────────────────────────────────────────────

function createCanvas() {

    const canvas  = document.createElement('canvas');
    canvas.id     = 'game-canvas';

    // Aggiunge il canvas dentro il wrapper già presente in index.html
    const wrapper = document.getElementById('canvas-wrapper');
    wrapper.appendChild(canvas);

    const ctx = canvas.getContext('2d');

    // Imposta le dimensioni iniziali (si adattano allo schermo)
    resizeCanvas(canvas);

    return { canvas, ctx };
}


// ─────────────────────────────────────────────────────────────
//  resizeCanvas(canvas)
//  Calcola la dimensione corretta del canvas in base alla viewport.
//  Mantiene il rapporto 3:2 (BASE_WIDTH / BASE_HEIGHT).
//  Chiamato all'avvio e ogni volta che la finestra viene ridimensionata.
// ─────────────────────────────────────────────────────────────

function resizeCanvas(canvas) {

    const { BASE_WIDTH, BASE_HEIGHT, MAX_WIDTH_PERCENT, MAX_HEIGHT_PERCENT } = CANVAS_CONFIG;

    // Spazio disponibile considerando i margini della pagina
    const availableWidth  = window.innerWidth  * MAX_WIDTH_PERCENT;
    const availableHeight = window.innerHeight * MAX_HEIGHT_PERCENT;

    // Fattore di scala: quanto dobbiamo rimpicciolire il canvas di riferimento
    // per farlo stare nello spazio disponibile (usa il limite più restrittivo)
    const scaleByWidth  = availableWidth  / BASE_WIDTH;
    const scaleByHeight = availableHeight / BASE_HEIGHT;
    const scale         = Math.min(scaleByWidth, scaleByHeight, 1); // mai più grande di 1

    canvas.width  = Math.floor(BASE_WIDTH  * scale);
    canvas.height = Math.floor(BASE_HEIGHT * scale);
}


// ─────────────────────────────────────────────────────────────
//  drawScene(ctx, canvas)
//  Disegna il contenuto del canvas.
//  Per ora è una scena placeholder — qui va la grafica di gioco.
// ─────────────────────────────────────────────────────────────

function drawScene(ctx, canvas) {

    const w = canvas.width;
    const h = canvas.height;

    // ── Sfondo ───────────────────────────────────────────────

    // Gradiente radiale: centro più chiaro, bordi scuri — dà profondità alla mappa
    const bgGradient = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.7);
    bgGradient.addColorStop(0,   '#1e1a35');
    bgGradient.addColorStop(0.6, '#16132a');
    bgGradient.addColorStop(1,   '#0e0c1c');

    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, w, h);

    // ── Griglia mappa (decorativa) ────────────────────────────

    // Griglia a esagoni simulata con linee sottili viola scuro
    ctx.strokeStyle = 'rgba(60, 50, 100, 0.3)';
    ctx.lineWidth   = 0.5;

    const gridSize = Math.floor(w / 20);   // dimensione cella adattiva

    for (let x = 0; x < w; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
    }

    for (let y = 0; y < h; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
    }

    // ── Placeholder — testo centrale ──────────────────────────

    // Calcola dimensioni testo proporzionali al canvas
    const titleSize = Math.floor(w * 0.04);
    const subSize   = Math.floor(w * 0.022);

    // Testo principale
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.font         = `700 ${titleSize}px 'Cinzel', serif`;
    ctx.fillStyle    = 'rgba(201, 168, 76, 0.15)';
    ctx.fillText('MAPPA DI GIOCO', w / 2, h / 2 - titleSize * 0.8);

    // Sottotesto
    ctx.font      = `400 ${subSize}px 'Rajdhani', sans-serif`;
    ctx.fillStyle = 'rgba(138, 130, 168, 0.4)';
    ctx.fillText('Il rendering della mappa verrà implementato qui', w / 2, h / 2 + subSize * 0.6);

    // ── Decorazioni angoli interni ────────────────────────────

    drawCornerDecorations(ctx, w, h);
}


// ─────────────────────────────────────────────────────────────
//  drawCornerDecorations(ctx, w, h)
//  Aggiunge piccoli segni decorativi agli angoli del canvas.
//  Richiamato da drawScene().
// ─────────────────────────────────────────────────────────────

function drawCornerDecorations(ctx, w, h) {

    const size    = Math.floor(Math.min(w, h) * 0.04);   // dimensione adattiva
    const padding = size * 0.6;
    const color   = 'rgba(201, 168, 76, 0.25)';

    ctx.strokeStyle = color;
    ctx.lineWidth   = 1;

    // Definisce i 4 angoli: [x, y] del vertice + direzione dei due segmenti
    const corners = [
        { x: padding,     y: padding,      dx:  1, dy:  1 },   // alto-sinistra
        { x: w - padding, y: padding,      dx: -1, dy:  1 },   // alto-destra
        { x: padding,     y: h - padding,  dx:  1, dy: -1 },   // basso-sinistra
        { x: w - padding, y: h - padding,  dx: -1, dy: -1 },   // basso-destra
    ];

    for (const { x, y, dx, dy } of corners) {
        ctx.beginPath();
        ctx.moveTo(x + dx * size, y);      // segmento orizzontale
        ctx.lineTo(x, y);
        ctx.lineTo(x, y + dy * size);      // segmento verticale
        ctx.stroke();
    }
}


// ─────────────────────────────────────────────────────────────
//  init()
//  Punto di ingresso dell'applicazione.
//  Crea il canvas, disegna la scena e imposta il resize.
// ─────────────────────────────────────────────────────────────

function init() {

    const { canvas, ctx } = createCanvas();

    // Prima renderizzazione
    drawScene(ctx, canvas);

    // Ridimensiona il canvas quando l'utente ridimensiona la finestra.
    // Uso un debounce per non chiamare resize ad ogni pixel durante il trascinamento.
    let resizeTimer;

    window.addEventListener('resize', () => {

        clearTimeout(resizeTimer);

        resizeTimer = setTimeout(() => {
            resizeCanvas(canvas);
            drawScene(ctx, canvas);   // ridisegna dopo il resize
        }, 120);
    });

    // Carica i dati dal server solo se USE_SERVER è abilitato
    if (USE_SERVER) {
        initServerData();
    }
}

// Avvia l'app — il file è caricato in fondo al body quindi il DOM è già pronto
//init();




// ════════════════════════════════════════════════════════════
//  SEZIONE SERVER (API)
//  Tutte le funzioni qui sotto comunicano con il backend.
//  Sono disabilitate finché USE_SERVER è false.
//
//  Per attivarle: cambia USE_SERVER = true in cima al file.
//  Il server deve essere in esecuzione su localhost:3000.
// ════════════════════════════════════════════════════════════


// ─────────────────────────────────────────────────────────────
//  apiFetch(url, options)
//  Wrapper interno su fetch() usato da tutte le funzioni API.
//  Aggiunge l'header Content-Type e gestisce gli errori HTTP.
//
//  Non chiamare direttamente: usa le funzioni specifiche sotto.
// ─────────────────────────────────────────────────────────────

async function apiFetch(url, options = {}) {

    const response = await fetch(url, {
        headers: { 'Content-Type': 'application/json' },
        ...options,
    });

    const data = await response.json();

    if (!data.ok) {
        throw new Error(data.error ?? 'Errore sconosciuto dal server');
    }

    return data;
}


// ─────────────────────────────────────────────────────────────
//  UTENTI  →  jsonHandler  →  data/output/<id>.json
// ─────────────────────────────────────────────────────────────

// Carica il profilo di un utente
// → GET /api/users/:id
async function loadUser(userId) {
    const res = await apiFetch(`/api/users/${userId}`);
    return res.data;
}

// Crea un nuovo utente (chiamare una volta sola alla registrazione)
// → POST /api/users
// body: { id, name, level?, power?, guild? }
async function createUser(userData) {
    const res = await apiFetch('/api/users', {
        method: 'POST',
        body:   JSON.stringify(userData),
    });
    return res.data;
}

// Aggiorna campi del profilo (es. dopo un level-up)
// → PUT /api/users/:id
// body: { level?, power?, guild? }  — solo i campi da cambiare
async function updateUser(userId, updates) {
    const res = await apiFetch(`/api/users/${userId}`, {
        method: 'PUT',
        body:   JSON.stringify(updates),
    });
    return res.data;
}


// ─────────────────────────────────────────────────────────────
//  RISORSE  →  csvHandler  →  data/output/<id>_resources.csv
// ─────────────────────────────────────────────────────────────

// Carica le risorse attuali e le mostra nell'UI
// → GET /api/resources/:userId
async function loadResources(userId) {
    const res = await apiFetch(`/api/resources/${userId}`);
    renderResources(res.data);
    return res.data;
}

// Crea le risorse iniziali (chiamare una volta sola alla registrazione)
// → POST /api/resources/:userId
// body: { grano, legno, oro, pietra, ferro }
async function initResources(userId, startingResources) {
    const res = await apiFetch(`/api/resources/${userId}`, {
        method: 'POST',
        body:   JSON.stringify(startingResources),
    });
    return res.data;
}

// Aggiunge o rimuove risorse (valori positivi = guadagno, negativi = perdita)
// → PATCH /api/resources/:userId/add
// body: { grano?: ±N, legno?: ±N, oro?: ±N, ... }
async function applyLoot(userId, delta) {
    const res = await apiFetch(`/api/resources/${userId}/add`, {
        method: 'PATCH',
        body:   JSON.stringify(delta),
    });
    return res.data;
}


// ─────────────────────────────────────────────────────────────
//  BATTAGLIE  →  xmlHandler  →  data/output/battle_<id>.xml
// ─────────────────────────────────────────────────────────────

// Salva il risultato di una battaglia e aggiorna le risorse di entrambi
// → POST /api/battles
// Poi internamente chiama applyLoot per vincitore e perdente
async function resolveBattle(attacker, defender, result) {

    // 1. Salva il log XML della battaglia
    const res = await apiFetch('/api/battles', {
        method: 'POST',
        body:   JSON.stringify({
            attackerId:     attacker.id,
            attackerName:   attacker.name,
            attackerTroops: attacker.troops,
            attackerLosses: result.attackerLosses,
            defenderId:     defender.id,
            defenderName:   defender.name,
            defenderTroops: defender.troops,
            defenderLosses: result.defenderLosses,
            winner:         result.winner,    // 'attacker' | 'defender'
            loot:           result.loot,       // { oro, grano, legno }
        }),
    });

    const battle = res.data;

    // 2. Aggiorna le risorse: il vincitore guadagna, il perdente perde lo stesso importo
    const loot        = battle.result.loot;
    const negativeLoot = { oro: -loot.oro, grano: -loot.grano, legno: -loot.legno };

    if (battle.result.winner === 'attacker') {
        await applyLoot(attacker.id, loot);
        await applyLoot(defender.id, negativeLoot);
    } else {
        await applyLoot(defender.id, loot);
        await applyLoot(attacker.id, negativeLoot);
    }

    return battle;
}

// Carica lo storico battaglie di un utente e lo mostra nell'UI
// → GET /api/battles/user/:userId
async function loadBattleHistory(userId) {
    const res = await apiFetch(`/api/battles/user/${userId}`);
    renderBattleHistory(res.data);
    return res.data;
}


// ─────────────────────────────────────────────────────────────
//  RENDER — funzioni che aggiornano il DOM con i dati del server
//  Queste vengono chiamate solo quando USE_SERVER è true
// ─────────────────────────────────────────────────────────────

// Scrive i valori delle risorse negli elementi HTML
// Gli elementi devono avere id: res-grano, res-legno, res-oro, ecc.
function renderResources(resources) {
    ['grano', 'legno', 'oro', 'pietra', 'ferro'].forEach(key => {
        const el = document.getElementById(`res-${key}`);
        if (el) el.textContent = resources[key].toLocaleString('it-IT');
    });
}

// Costruisce la lista di battaglie nel DOM
// L'elemento con id "battle-log-list" deve esistere in index.html
function renderBattleHistory(battles) {

    const list = document.getElementById('battle-log-list');
    if (!list) return;

    list.innerHTML = battles.map(b => {
        const winnerName = b.result.winner === 'attacker' ? b.attacker.name : b.defender.name;
        const dateStr    = new Date(b.date).toLocaleDateString('it-IT');

        return `
            <li class="battle-entry ${b.result.winner}">
                <span class="battle-date">${dateStr}</span>
                <strong>${b.attacker.name}</strong> vs <strong>${b.defender.name}</strong>
                — Vincitore: <em>${winnerName}</em>
            </li>
        `;
    }).join('');
}


// ─────────────────────────────────────────────────────────────
//  initServerData()
//  Carica tutti i dati dal server all'avvio.
//  Chiamata da init() solo se USE_SERVER è true.
//
//  In un'app reale l'userId verrebbe da sessione o cookie.
// ─────────────────────────────────────────────────────────────

async function initServerData() {

    const userId = 'usr_drago01';   // ← sostituire con la sessione reale

    try {
        // Carica profilo, risorse e storico in parallelo
        const [user] = await Promise.all([
            loadUser(userId),
            loadResources(userId),
            loadBattleHistory(userId),
        ]);

        // Aggiorna il nome del giocatore nell'header se l'elemento esiste
        const nameEl = document.getElementById('player-name');
        if (nameEl) nameEl.textContent = user.name;

    } catch (err) {
        console.warn('[Server] Dati non disponibili:', err.message);
    }
}