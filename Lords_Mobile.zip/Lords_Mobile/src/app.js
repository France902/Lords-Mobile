// ════════════════════════════════════════════════════════════
//  SEZIONE CLIENT (Logica UI e Registrazione)
// ════════════════════════════════════════════════════════════

let playIsPressed = false;

function playAction() {
    if(!playIsPressed) {
        playIsPressed = true;
        document.getElementById('formUtente').style.display = 'flex';
        document.getElementById('btn-gioca').style.display = 'none';
    }
}

// ════════════════════════════════════════════════════════════
//  CONFIGURAZIONE E UTILS API
// ════════════════════════════════════════════════════════════
const USE_SERVER = true; // Impostalo a true per parlare con Express

async function apiFetch(url, options = {}) {
    const response = await fetch(url, {
        headers: { 'Content-Type': 'application/json' },
        ...options,
    });

    const data = await response.json();
    if (!data.ok) {
        throw new Error(data.error ?? 'Errore dal server');
    }
    return data;
}

// ════════════════════════════════════════════════════════════
//  LOGICA UI ACCESSO / LOGIN
// ════════════════════════════════════════════════════════════

/**
 * Trasforma il form di registrazione in un form di login
 */
function mostraLogin() {
    const btnRegistrati = document.getElementById('btn-registrati');
    const btnAccedi = document.getElementById('btn-accedi');
    const oppureTesto = btnAccedi.previousElementSibling; // Prende l'h2 "oppure"
    const formTitle = document.querySelector('#formUtente h2');

    // 1. Nasconde il tasto Accedi e la scritta "oppure"
    btnAccedi.style.display = 'none';
    if (oppureTesto && oppureTesto.tagName === 'H2') {
        oppureTesto.style.display = 'none';
    }

    // 2. Cambia il titolo del form
    if (formTitle) formTitle.textContent = 'Accedi';

    // 3. Modifica il tasto principale (ex Registrati)
    btnRegistrati.textContent = 'ACCEDI';
    
    // 4. Cambia la funzione eseguita al click
    btnRegistrati.onclick = accediUtente;
}

/**
 * Logica per l'accesso dell'utente esistente
 */
async function accediUtente() {
    const nome = document.getElementById('nome').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!nome || !password) {
        alert('Inserisci nome e password.');
        return;
    }

    try {
        // Cerchiamo l'utente tramite le API (assumendo che il tuo backend gestisca il login)
        // Se non hai un endpoint di login dedicato, cerchiamo per nome
        const res = await apiFetch(`/api/users/login`, {
            method: 'POST',
            body: JSON.stringify({ name: nome, password: password })
        });

        const userData = res.data;

        // Salvataggio sessione e redirect
        sessionStorage.setItem('userId', userData.id);
        sessionStorage.setItem('userName', userData.name);
        sessionStorage.setItem('castleRow', userData.castleRow);
        sessionStorage.setItem('castleCol', userData.castleCol);

        window.location.href = '/game.html';

    } catch (err) {
        alert('Errore durante l\'accesso: ' + err.message);
    }
}

async function registraUtente() {
    const nome     = document.getElementById('nome').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!nome || !password) {
        alert('Compila tutti i campi.');
        return;
    }

    const userId = 'usr_' + nome.toLowerCase().replace(/\s+/g, '_') + '_' + Date.now();

    try {
        // ── 1. Genera la mappa se non esiste, poi prendi dimensioni ───────────
        await apiFetch('/api/map');
        const sizeRes       = await apiFetch('/api/mapsize');
        const { cols, rows } = sizeRes.data;

        // ── 2. Scarica la mappa per trovare una cella valida ──────────────────
        const mapRes  = await apiFetch('/api/map');
        const tileMap = mapRes.data.map;

        // Tile non valide per il castello — confronto su .src
        const INVALID = new Set([
            'trees1', 'trees2', 'trees3',
            'campwheat', 'campmineral', 'camprock', 'campwood',
            'mainplayer', 'enemyplayer',
        ]);

        const validCells = [];
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                // La tile è ora un oggetto { src, resources, ownerId, ... }
                const tileSrc = tileMap[r][c]?.src ?? tileMap[r][c];
                
                if (!INVALID.has(tileSrc)) {
                    validCells.push({ r, c });
                }
            }
        }

        

        if (validCells.length === 0) {
            return;
        }

        

        const chosen = validCells[Math.floor(Math.random() * validCells.length)];

        

        // ── 3. Crea utente con posizione castello ─────────────────────────────
        await apiFetch('/api/users', {
            method: 'POST',
            body: JSON.stringify({
                id:        userId,
                name:      nome,
                password:  password,
                level:     1,
                power:     0,
                castleRow: chosen.r,
                castleCol: chosen.c,
            }),
        });

        // ── 4. Risorse e truppe iniziali ──────────────────────────────────────
        await apiFetch(`/api/resources/${userId}`, {
            method: 'POST',
            body: JSON.stringify({ grano: 20, legno: 20, oro: 20, pietra: 20, minerali: 20 }),
        });

        await apiFetch(`/api/troops/${userId}`, {
            method: 'POST',
            body: JSON.stringify({}),
        });

        // ── 5. Piazza il castello sulla mappa ─────────────────────────────────
        await apiFetch('/api/map/tile', {
            method: 'PATCH',
            body: JSON.stringify({
                row:     chosen.r,
                col:     chosen.c,
                tileKey: 'mainplayer',
                ownerId: userId,         // ← salvato nel CSV così sappiamo di chi è
            }),
        });

        // ── 6. Sessione e redirect ────────────────────────────────────────────
        sessionStorage.setItem('userId',    userId);
        sessionStorage.setItem('userName',  nome);
        sessionStorage.setItem('castleRow', chosen.r);
        sessionStorage.setItem('castleCol', chosen.c);

        window.location.href = '/game.html';

    } catch (err) {
        alert('Errore durante la registrazione: ' + err.message);
    }
}

// ════════════════════════════════════════════════════════════
//  INIZIALIZZAZIONE DATI (Eseguita in game.html o all'avvio)
// ════════════════════════════════════════════════════════════

async function initServerData() {
    const userId = sessionStorage.getItem('userId');
    if (!userId || !USE_SERVER) return;

    try {
        // Recuperiamo i dati aggiornati dal server
        const userRes = await apiFetch(`/api/users/${userId}`);
        const resRes  = await apiFetch(`/api/resources/${userId}`);

        // Aggiorna UI
        const nameEl = document.getElementById('player-name');
        if (nameEl) nameEl.textContent = userRes.data.name;
        
        renderResources(resRes.data);

    } catch (err) {
        console.warn('[Server] Errore caricamento:', err.location);
    }
}

function renderResources(resources) {
    ['grano', 'legno', 'oro', 'pietra', 'minerali'].forEach(key => {
        const el = document.getElementById(`res-${key}`);
        if (el) el.textContent = resources[key].toLocaleString('it-IT');
    });
}