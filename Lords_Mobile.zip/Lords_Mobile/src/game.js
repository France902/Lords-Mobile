const canvas = document.getElementById('game-canvas');
const ctx    = canvas.getContext('2d');

// ════════════════════════════════════════════════════
//  SERVER
// ════════════════════════════════════════════════════

const USE_SERVER = true;   // la mappa viene sempre dal server ora

async function apiFetch(url, options = {}) {
    const response = await fetch(url, {
        headers: { 'Content-Type': 'application/json' },
        ...options,
    });
    const data = await response.json();
    if (!data.ok) throw new Error(data.error ?? 'Errore sconosciuto dal server');
    return data;
}

// ════════════════════════════════════════════════════
//  CAMERA — inizia a zero, viene centrata dopo loadMap
// ════════════════════════════════════════════════════

const CAMERA_SPEED = 6;

const camera = { x: 0, y: 0 };

const keys = { w: false, a: false, s: false, d: false };

window.addEventListener('keydown', e => {
    if (e.key === 'w' || e.key === 'W') keys.w = true;
    if (e.key === 'a' || e.key === 'A') keys.a = true;
    if (e.key === 's' || e.key === 'S') keys.s = true;
    if (e.key === 'd' || e.key === 'D') keys.d = true;
});

window.addEventListener('keyup', e => {
    if (e.key === 'w' || e.key === 'W') keys.w = false;
    if (e.key === 'a' || e.key === 'A') keys.a = false;
    if (e.key === 's' || e.key === 'S') keys.s = false;
    if (e.key === 'd' || e.key === 'D') keys.d = false;
});

function updateCamera() {
    let moved = false;
    if (keys.w) { camera.y += CAMERA_SPEED; moved = true; }
    if (keys.s) { camera.y -= CAMERA_SPEED; moved = true; }
    if (keys.a) { camera.x += CAMERA_SPEED; moved = true; }
    if (keys.d) { camera.x -= CAMERA_SPEED; moved = true; }

    if (moved) {
        sessionStorage.setItem('camera_x', camera.x);
        sessionStorage.setItem('camera_y', camera.y);
    }
    return moved;
}

// ════════════════════════════════════════════════════
//  centerCameraOnCastle()
//  Chiamata dopo loadMap() — MAP_ROWS/COLS sono già noti.
//  Converte (castleRow, castleCol) in offset pixel camera.
//
//  La formula inverte la proiezione di drawDiamondGrid:
//    cx = originX + relCol * STEP_X + offsetX
//    cy = originY + relRow * STEP_Y
//  Vogliamo cx = w/2 e cy = h/2, quindi:
//    camera.x = -(relCol * STEP_X + offsetX)
//    camera.y = -(relRow * STEP_Y)
// ════════════════════════════════════════════════════

function centerCameraOnCastle() {
    const castleRow = parseInt(sessionStorage.getItem('castleRow'));
    const castleCol = parseInt(sessionStorage.getItem('castleCol'));

    // Se non ci sono coordinate salvate, resta al centro
    if (isNaN(castleRow) || isNaN(castleCol)) return;

    // Posizione relativa al centro della mappa (in unità tile)
    const relRow = castleRow - Math.floor(MAP_ROWS / 2);
    const relCol = castleCol - Math.floor(MAP_COLS / 2);

    // Le righe dispari hanno un offset orizzontale di HALF_W
    const offsetX = (castleRow % 2 !== 0) ? HALF_W : 0;

    // Offset camera per portare il castello al centro del viewport
    camera.x = -(relCol * STEP_X + offsetX);
    camera.y = -(relRow * STEP_Y);
}

// ════════════════════════════════════════════════════
//  UI — carica e renderizza dati giocatore dal server
// ════════════════════════════════════════════════════

async function loadPlayerUI() {
    const userId = sessionStorage.getItem('userId');
    if (!userId) return;

    try {
        const [userRes, resRes, troopsRes] = await Promise.all([
            apiFetch(`/api/users/${userId}`),
            apiFetch(`/api/resources/${userId}`),
            apiFetch(`/api/troops/${userId}`),
        ]);

        const user   = userRes.data;
        const res    = resRes.data;
        const troops = troopsRes.data;

        // Livello e potenza
        document.getElementById('player-level').textContent = `Lv ${user.level}`;
        document.getElementById('power-value').textContent  = user.power.toLocaleString('it-IT');

        // Risorse
        document.getElementById('res-grano').textContent  = res.grano.toLocaleString('it-IT');
        document.getElementById('res-legno').textContent  = res.legno.toLocaleString('it-IT');
        document.getElementById('res-pietra').textContent = res.pietra.toLocaleString('it-IT');
        document.getElementById('res-oro').textContent    = res.oro.toLocaleString('it-IT');

        // Truppe
        document.getElementById('troop-fanteria').textContent   = troops.fanteria.toLocaleString('it-IT');
        document.getElementById('troop-cavalleria').textContent = troops.cavalleria.toLocaleString('it-IT');
        document.getElementById('troop-arceri').textContent     = troops.arceri.toLocaleString('it-IT');
        document.getElementById('troop-balliste').textContent   = troops.balliste.toLocaleString('it-IT');

    } catch (err) {
        console.warn('[UI] Dati giocatore non disponibili:', err.message);
    }
}



// ════════════════════════════════════════════════════
//  CANVAS
// ════════════════════════════════════════════════════

function resizeCanvas() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
}

resizeCanvas();


// ════════════════════════════════════════════════════
//  MAPPA — ricevuta dal server
// ════════════════════════════════════════════════════

let tileMap  = [];
let MAP_COLS = 0;
let MAP_ROWS = 0;

async function loadMap() {
    const res = await apiFetch('/api/map');
    tileMap  = res.data.map;
    console.log(res.data.map);
    MAP_COLS = res.data.cols;
    MAP_ROWS = res.data.rows;
    console.log(`[Map] Mappa ${MAP_COLS}x${MAP_ROWS} ricevuta dal server.`);
}


// ════════════════════════════════════════════════════
//  TILE TYPES
// ════════════════════════════════════════════════════

const TILE_TYPES = {
    grass1: { src: '/data/input/resources/grass.png',  pattern: null },
    grass2: { src: '/data/input/resources/grass2.png', pattern: null },
    grass3: { src: '/data/input/resources/grass3.png', pattern: null },
    grass4: { src: '/data/input/resources/grass4.png', pattern: null },
    trees1: { src: '/data/input/resources/trees.png', pattern: null },
    trees2: { src: '/data/input/resources/trees2.png', pattern: null },
    trees3: { src: '/data/input/resources/trees3.png', pattern: null },
    campwheat: { src: '/data/input/resources/wheatcamp.png', pattern: null },
    campmineral: { src: '/data/input/resources/mineralcamp.png', pattern: null },
    camprock: { src: '/data/input/resources/rockcamp.png', pattern: null },
    campwood: { src: '/data/input/resources/woodcamp.png', pattern: null },
    mainplayer: { src: '/data/input/resources/castleblue.png', pattern: null },
    enemyplayer: { src: '/data/input/resources/castlered.png', pattern: null },
};

function loadTiles() {
    const promises = Object.entries(TILE_TYPES).map(([key, tile]) => {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                tile.pattern = ctx.createPattern(img, 'repeat');
                tile.image = img; // <--- INDISPENSABILE per drawImage
                resolve();
            };
            img.onerror = () => {
                console.warn(`[Tile] "${key}" non trovato.`);
                tile.pattern = '#4caf50'; // Fallback colore
                tile.image = null;
                resolve();
            };
            img.src = tile.src;
        });
    });
    return Promise.all(promises);
}


// ════════════════════════════════════════════════════
//  COSTANTI GRIGLIA — usate da draw e hit detection
// ════════════════════════════════════════════════════

const HALF_H = 54;
const HALF_W = HALF_H * 2;
const STEP_X = HALF_W * 2;
const STEP_Y = HALF_H;

const TILE_NAMES = {
    grass1:      'Piana erbosa',
    grass2:      'Prateria aperta',
    grass3:      'Pianura fertile',
    grass4:      'Campo selvatico',
    trees1:      'Bosco fitto',
    trees2:      'Foresta incontaminata',
    trees3:      'Foresta antica',
    campwheat:   'Campo di grano',
    campmineral: 'Miniera di minerali',
    camprock:    'Cava di pietra',
    campwood:    'Riserva di legname',
};

// Risorse iniziali per ogni camp — in futuro verranno lette dal server
const CAMP_RESOURCES = {
    campwheat:   2000,
    campmineral: 2000,
    camprock:    2000,
    campwood:    2000,
};

const CAMP_RESOURCE_LABELS = {
    campwheat:   'Grano disponibile',
    campmineral: 'Minerale disponibile',
    camprock:    'Pietra disponibile',
    campwood:    'Legname disponibile',
};


// ════════════════════════════════════════════════════
//  TILE PANEL — logica apertura/chiusura
// ════════════════════════════════════════════════════

const tilePanel         = document.getElementById('tile-panel');
const tilePanelName     = document.getElementById('tile-panel-name');
const tilePanelRes      = document.getElementById('tile-panel-resources');
const tilePanelBtn      = document.getElementById('tile-panel-btn');

let tilePanelOpen = false;

// ════════════════════════════════════════════════════
//  MAP POLLING — controlla ogni 30s se la mappa è cambiata
//  Usa /api/map/version (leggero) prima di scaricare
//  l'intera mappa — evita traffico inutile
// ════════════════════════════════════════════════════

let lastMapVersion = null;

async function checkMapVersion() {
    try {
        const res = await apiFetch('/api/map/version');
        const version = res.data.version;

        // Prima chiamata — salva la versione senza ricaricare
        if (lastMapVersion === null) {
            lastMapVersion = version;
            return;
        }

        if (version !== lastMapVersion) {
            console.log('[Map] Nuova versione rilevata — ricarico la mappa...');
            lastMapVersion = version;
            await reloadMap();
        }

    } catch (err) {
        console.warn('[Poll] Errore verifica versione mappa:', err.message);
    }
}

async function reloadMap() {
    try {
        const res = await apiFetch('/api/map');
        tileMap  = res.data.map;
        MAP_COLS = res.data.cols;
        MAP_ROWS = res.data.rows;

        // Ridisegna immediatamente con la nuova mappa
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawDiamondGrid();
        drawMarchLines();

        console.log('[Map] Mappa aggiornata dal server.');
    } catch (err) {
        console.warn('[Map] Errore ricaricamento mappa:', err.message);
    }
}

// Intervallo polling — 30 secondi
// Non ha senso farlo più frequente: la rigenerazione è oraria
const MAP_POLL_INTERVAL = 30 * 1000;

// ════════════════════════════════════════════════════
//  MARCH SYSTEM — marce multiple simultanee
// ════════════════════════════════════════════════════

const activeMarches = [];   // array — ogni elemento è una marcia indipendente

function mapToScreen(mapRow, mapCol) {
    const relRow  = mapRow - Math.floor(MAP_ROWS / 2);
    const relCol  = mapCol - Math.floor(MAP_COLS / 2);
    const offsetX = (mapRow % 2 !== 0) ? HALF_W : 0;
    return {
        x: canvas.width  / 2 + camera.x + relCol * STEP_X + offsetX,
        y: canvas.height / 2 + camera.y + relRow * STEP_Y,
    };
}

function tileDistance(r1, c1, r2, c2) {
    return Math.abs(r2 - r1) + Math.abs(c2 - c1);
}

// Crea un elemento DOM per l'indicatore di marcia
// Ogni marcia ha il suo div — vengono rimossi all'arrivo
function createMarchIndicator(troops, troopType) {
    const el = document.createElement('div');
    el.className = 'march-indicator';

    const icons = { fanteria: '⚔️', cavalleria: '🐴', arceri: '🏹', balliste: '🪨' };
    el.innerHTML = `${icons[troopType] ?? '⚔️'}<br>${troops}`;

    document.getElementById('ui').appendChild(el);
    return el;
}

// ════════════════════════════════════════════════════
//  MARCH SYSTEM — con persistenza server
// ════════════════════════════════════════════════════

const GATHER_DURATION_PER_TROOP = 2;

function _getGatherDuration(march) {
    // Se il server ha salvato gatherDuration usala,
    // altrimenti calcola da truppe
    if (march.gatherDuration && march.gatherDuration > 0) return march.gatherDuration;
    return (march.troops ?? 1) * GATHER_DURATION_PER_TROOP;
}

function _spawnMarch(march) {
    const gatherDuration = _getGatherDuration(march);

    // Durata totale: andata + raccolta + ritorno
    const totalDuration  = march.durationSeconds * 2 + gatherDuration;
    const elapsed        = (Date.now() - march.startTime) / 1000;

    // Marcia completamente finita offline
    if (elapsed >= totalDuration) {
        const userId = sessionStorage.getItem('userId');
        if (march.id && userId) {
            apiFetch(`/api/marches/${userId}/${march.id}`, { method: 'DELETE' })
                .then(() => loadPlayerUI())
                .catch(() => {});
        }
        console.log(`[March] ${march.id} già completata offline — truppe restituite.`);
        return;
    }

    // Calcola fase e posizione corrente
    const fromPos = mapToScreen(march.castleRow, march.castleCol);
    const toPos   = mapToScreen(march.targetRow,  march.targetCol);

    let currentX, currentY, phase;

    if (elapsed < march.durationSeconds) {
        // FASE 1: in marcia verso destinazione
        phase    = 'marching';
        const p  = elapsed / march.durationSeconds;
        currentX = fromPos.x + (toPos.x - fromPos.x) * p;
        currentY = fromPos.y + (toPos.y - fromPos.y) * p;

    } else if (elapsed < march.durationSeconds + gatherDuration) {
        // FASE 2: raccolta alla destinazione
        phase    = 'gathering';
        currentX = toPos.x;
        currentY = toPos.y;

    } else {
        // FASE 3: ritorno al castello
        phase    = 'returning';
        const returnElapsed = elapsed - march.durationSeconds - gatherDuration;
        const p  = returnElapsed / march.durationSeconds;
        currentX = toPos.x + (fromPos.x - toPos.x) * p;
        currentY = toPos.y + (fromPos.y - toPos.y) * p;
    }

    const indicator = createMarchIndicator(march.troops, march.troopType);
    _updateIndicatorStyle(indicator, phase);
    indicator.style.transition = 'none';
    indicator.style.left       = `${currentX - 20}px`;
    indicator.style.top        = `${currentY  - 20}px`;
    indicator.style.display    = 'flex';

    const marchObj = { ...march, indicator, gatherDuration };
    activeMarches.push(marchObj);

    // Avvia la catena di fasi partendo da quella corrente
    _runMarchPhase(marchObj, phase, elapsed);
}

// Stile visivo per fase — marching=oro, gathering=verde, returning=blu
function _updateIndicatorStyle(indicator, phase) {
    const colors = {
        marching:  'rgba(201, 168, 76, 0.85)',
        gathering: 'rgba(76, 175, 80, 0.85)',
        returning: 'rgba(100, 149, 237, 0.85)',
    };
    indicator.style.background = colors[phase] ?? colors.marching;
}

function _runMarchPhase(march, phase, elapsedAtSpawn) {
    const fromPos        = mapToScreen(march.castleRow, march.castleCol);
    const toPos          = mapToScreen(march.targetRow,  march.targetCol);
    const gatherDuration = _getGatherDuration(march);

    if (phase === 'marching') {
        const remaining = march.durationSeconds - elapsedAtSpawn;

        requestAnimationFrame(() => requestAnimationFrame(() => {
            march.indicator.style.transition = `left ${remaining}s linear, top ${remaining}s linear`;
            march.indicator.style.left = `${toPos.x - 20}px`;
            march.indicator.style.top  = `${toPos.y  - 20}px`;
        }));

        setTimeout(() => {
            _updateIndicatorStyle(march.indicator, 'gathering');
            march.indicator.style.transition = 'none';
            march.indicator.style.left = `${toPos.x - 20}px`;
            march.indicator.style.top  = `${toPos.y  - 20}px`;
            _runMarchPhase(march, 'gathering', march.durationSeconds);
        }, remaining * 1000);

    } else if (phase === 'gathering') {
        const gatherElapsed   = Math.max(0, elapsedAtSpawn - march.durationSeconds);
        const gatherRemaining = gatherDuration - gatherElapsed;

        setTimeout(() => {
            _updateIndicatorStyle(march.indicator, 'returning');
            _runMarchPhase(march, 'returning', march.durationSeconds + gatherDuration);
        }, gatherRemaining * 1000);

    } else if (phase === 'returning') {
        const returnElapsed   = Math.max(0, elapsedAtSpawn - march.durationSeconds - gatherDuration);
        const returnRemaining = march.durationSeconds - returnElapsed;

        requestAnimationFrame(() => requestAnimationFrame(() => {
            march.indicator.style.transition = `left ${returnRemaining}s linear, top ${returnRemaining}s linear`;
            march.indicator.style.left = `${fromPos.x - 20}px`;
            march.indicator.style.top  = `${fromPos.y  - 20}px`;
        }));

        setTimeout(async () => {
            const idx = activeMarches.findIndex(m => m.id === march.id);
            if (idx !== -1) activeMarches.splice(idx, 1);
            march.indicator.remove();

            const userId = sessionStorage.getItem('userId');
            if (march.id && userId) {
                try {
                    // 1. Saccheggia il camp — trasferisce risorse e azzera il camp
                    const isCamp = march.targetTileKey?.startsWith('camp');
                    if (isCamp) {
                        await apiFetch('/api/map/loot', {
                            method: 'POST',
                            body: JSON.stringify({
                                userId,
                                row: march.targetRow,
                                col: march.targetCol,
                            }),
                        });
                    }

                    // 2. Restituisce le truppe e chiude la marcia
                    await apiFetch(`/api/marches/${userId}/${march.id}`, { method: 'DELETE' });

                    // 3. Aggiorna tutta l'UI — risorse e truppe cambiate
                    await loadPlayerUI();

                } catch (err) {
                    console.warn('[March] Errore completamento:', err.message);
                }
            }

            console.log(`[March] ${march.troopType} rientrati — saccheggio completato.`);
        }, returnRemaining * 1000);
    }
}

async function startMarch(targetTile, troops, troopType) {
    const castleRow = parseInt(sessionStorage.getItem('castleRow'));
    const castleCol = parseInt(sessionStorage.getItem('castleCol'));
    const userId    = sessionStorage.getItem('userId');

    if (isNaN(castleRow) || isNaN(castleCol)) {
        console.warn('[March] Posizione castello non in sessione.');
        return;
    }

    const distance        = tileDistance(castleRow, castleCol, targetTile.mapRow, targetTile.mapCol);
    const durationSeconds = distance * 30;
    const startTime       = Date.now();
    const gatherDuration  = troops * GATHER_DURATION_PER_TROOP;   // ← dinamico

    let marchId = null;
    try {
        const res = await apiFetch('/api/marches', {
            method: 'POST',
            body: JSON.stringify({
                userId, castleRow, castleCol,
                targetRow:  targetTile.mapRow,
                targetCol:  targetTile.mapCol,
                troops, troopType,
                durationSeconds, startTime,
                gatherDuration,
            }),
        });
        marchId = res.data.marchId;

        const el = document.getElementById(`troop-${troopType}`);
        if (el) el.textContent = '0';

    } catch (err) {
        alert(`Errore avvio marcia: ${err.message}`);
        return;
    }

    _spawnMarch({
        id: marchId,
        castleRow, castleCol,
        targetRow:  targetTile.mapRow,
        targetCol:  targetTile.mapCol,
        troops, troopType,
        durationSeconds, startTime,
        gatherDuration,
        // Salva la destinazione per il loot — serve sapere che tile era
        targetTileKey: targetTile.tileKey,
    });
}

async function loadMarches() {
    const userId = sessionStorage.getItem('userId');
    if (!userId) return;

    try {
        const res     = await apiFetch(`/api/marches/${userId}`);
        const marches = res.data;

        if (marches.length === 0) return;
        console.log(`[March] ${marches.length} marce attive trovate — ricostruisco...`);

        for (const march of marches) {
            // Rinomina marchId in id per compatibilità con _spawnMarch
            _spawnMarch({ ...march, id: march.marchId });
        }

        for (const march of marches) {
            const tileData    = tileMap[march.targetRow]?.[march.targetCol];
            const tileKey     = typeof tileData === 'string' ? tileData : tileData?.src ?? '';
            _spawnMarch({ ...march, id: march.marchId, targetTileKey: tileKey });
        }

    } catch (err) {
        console.warn('[March] Impossibile caricare le marce:', err.message);
    }
}

function drawMarchLines() {
    if (activeMarches.length === 0) return;

    activeMarches.forEach(march => {
        const from = mapToScreen(march.castleRow, march.castleCol);
        const to   = mapToScreen(march.targetRow,  march.targetCol);

        ctx.beginPath();
        ctx.moveTo(from.x, from.y);
        ctx.lineTo(to.x,   to.y);
        ctx.strokeStyle = 'rgba(201, 168, 76, 0.6)';
        ctx.lineWidth   = 2;
        ctx.setLineDash([8, 6]);
        ctx.stroke();
        ctx.setLineDash([]);

        [from, to].forEach(p => {
            ctx.beginPath();
            ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(201, 168, 76, 0.8)';
            ctx.fill();
        });
    });
}

// Risincronizza gli indicatori quando la camera si sposta
function syncMarchIndicators() {
    const now = Date.now();

    activeMarches.forEach(march => {
        const elapsed       = (now - march.startTime) / 1000;
        const gatherDuration = march.gatherDuration ?? GATHER_DURATION;

        const fromPos = mapToScreen(march.castleRow, march.castleCol);
        const toPos   = mapToScreen(march.targetRow,  march.targetCol);

        let currentX, currentY, remaining, destX, destY;

        if (elapsed < march.durationSeconds) {
            const p   = elapsed / march.durationSeconds;
            currentX  = fromPos.x + (toPos.x - fromPos.x) * p;
            currentY  = fromPos.y + (toPos.y - fromPos.y) * p;
            remaining = march.durationSeconds - elapsed;
            destX     = toPos.x;
            destY     = toPos.y;

        } else if (elapsed < march.durationSeconds + gatherDuration) {
            currentX  = toPos.x;
            currentY  = toPos.y;
            remaining = 0;   // fermo durante la raccolta
            destX     = toPos.x;
            destY     = toPos.y;

        } else {
            const returnElapsed = elapsed - march.durationSeconds - gatherDuration;
            const p   = Math.min(returnElapsed / march.durationSeconds, 1);
            currentX  = toPos.x + (fromPos.x - toPos.x) * p;
            currentY  = toPos.y + (fromPos.y - toPos.y) * p;
            remaining = Math.max(march.durationSeconds - returnElapsed, 0);
            destX     = fromPos.x;
            destY     = fromPos.y;
        }

        march.indicator.style.transition = 'none';
        march.indicator.style.left = `${currentX - 20}px`;
        march.indicator.style.top  = `${currentY  - 20}px`;

        if (remaining > 0) {
            requestAnimationFrame(() => {
                march.indicator.style.transition = `left ${remaining}s linear, top ${remaining}s linear`;
                march.indicator.style.left = `${destX - 20}px`;
                march.indicator.style.top  = `${destY  - 20}px`;
            });
        }
    });
}

function openTilePanel(tile) {
    const tileData = tile.fullData;
    const tileKey  = tile.tileKey; // es. "campwheat"
    
    // 1. Imposta il nome leggibile
    const name = TILE_NAMES[tileKey] ?? tileKey;
    tilePanelName.textContent = name;

    // 2. Gestione risorse dinamiche
    if (tileKey.startsWith('camp')) {
        // PRENDIAMO IL DATO DAL SERVER (fullData) invece che dalla costante fissa
        const amount = (tileData && tileData.resources !== null) ? tileData.resources : 0;
        
        const label = CAMP_RESOURCE_LABELS[tileKey] ?? 'Risorse disponibili';
        tilePanelRes.textContent = `${label}: ${amount.toLocaleString('it-IT')}`;
        tilePanelRes.style.display = 'block';
    } else {
        tilePanelRes.style.display = 'none';
    }

    // 3. Bottone VAI (logica invariata)
    const isNeutral = tileKey.startsWith('grass') || tileKey.startsWith('trees');
    tilePanelBtn.style.display = isNeutral ? 'none' : 'inline-block';

    tilePanel.classList.add('visible');
    tilePanelOpen = true;
}

function closeTilePanel() {
    tilePanel.classList.remove('visible');
    tilePanelOpen = false;
}

// ESC chiude il pannello
window.addEventListener('keydown', e => {
    if (e.key === 'Escape' && tilePanelOpen) closeTilePanel();
});


// ════════════════════════════════════════════════════
//  DRAW
// ════════════════════════════════════════════════════

function drawDiamond(cx, cy, fillStyle, tileKey) {
    // 1. Disegna il Rombo (Terreno)
    ctx.beginPath();
    ctx.moveTo(cx, cy - HALF_H);
    ctx.lineTo(cx + HALF_W, cy);
    ctx.lineTo(cx, cy + HALF_H);
    ctx.lineTo(cx - HALF_W, cy);
    ctx.closePath();

    ctx.fillStyle = fillStyle || '#4caf50';
    ctx.fill();

    // 2. Disegna l'Albero (Immagine Rettangolare sopra)
    if (tileKey && (tileKey.startsWith('trees') || tileKey.startsWith('camp') || tileKey.startsWith('main'))) {
        const tileCfg = TILE_TYPES[tileKey];
        if (tileCfg && tileCfg.image) {
            const img = tileCfg.image;
            // Dimensioni dell'albero (puoi regolarle)
            const imgW = 100; 
            const imgH = 100;
            // Disegniamo l'immagine centrata sulla base del rombo
            // L'offset Y (- imgH + 20) serve a far sembrare l'albero "piantato"
            ctx.drawImage(img, cx - imgW / 2, cy - imgH + 25, imgW, imgH);
        }
    }

    ctx.lineWidth = 2;
    ctx.strokeStyle = fillStyle;
    ctx.stroke();
}

function drawDiamondGrid() {
    const w = canvas.width;
    const h = canvas.height;
    const originX = w / 2 + camera.x;
    const originY = h / 2 + camera.y;

    /*
        Quante tile coprono il viewport — invariato.
        Ma il centro dell'iterazione segue la camera,
        non è sempre fisso a 0.
    */
    const visibleCols = Math.ceil(w / STEP_X) + 6;
    const visibleRows = Math.ceil(h / STEP_Y) + 6;

    // Tile relativa al centro mappa che sta al centro schermo ora
    const centerRelCol = Math.round(-camera.x / STEP_X);
    const centerRelRow = Math.round(-camera.y / STEP_Y);

    const halfC = Math.ceil(visibleCols / 2);
    const halfR = Math.ceil(visibleRows / 2);

    for (let dr = -halfR; dr <= halfR; dr++) {
        const row     = centerRelRow + dr;
        const offsetX = (row % 2 !== 0) ? HALF_W : 0;

        for (let dc = -halfC; dc <= halfC; dc++) {
            const col = centerRelCol + dc;

            const mapRow = row + Math.floor(MAP_ROWS / 2);
            const mapCol = col + Math.floor(MAP_COLS / 2);

            if (mapRow < 0 || mapRow >= MAP_ROWS || mapCol < 0 || mapCol >= MAP_COLS) continue;

            const tileData = tileMap[mapRow][mapCol];
            if (!tileData) continue;
            // Estraiamo la stringa della tile (es. "grass1")
            const tileKey = typeof tileData === 'string' ? tileData : tileData.src;
            
            const tileCfg = TILE_TYPES[tileKey];
            if (!tileCfg) continue;

            const cx = originX + col * STEP_X + offsetX;
            const cy = originY + row * STEP_Y;

            let currentStyle = (tileKey.startsWith('trees') || tileKey.startsWith('camp') || tileKey === 'mainplayer' || tileKey === 'enemyplayer')
                ? TILE_TYPES['grass1'].pattern
                : tileCfg.pattern;

            if (currentStyle instanceof CanvasPattern) {
                const matrix = new DOMMatrix();
                matrix.translateSelf(cx - HALF_W, cy - HALF_H);
                currentStyle.setTransform(matrix);
            }

            drawDiamond(cx, cy, currentStyle, tileKey);
        }
    }
}


// ════════════════════════════════════════════════════
//  HIT DETECTION — quale rombo ha cliccato il mouse?
//
//  Un punto (px, py) è dentro un rombo centrato in
//  (cx, cy) se: |px-cx|/halfW + |py-cy|/halfH <= 1
//  È la formula della norma L1 — il rombo è la "sfera"
//  di raggio 1 in questo spazio metrico.
// ════════════════════════════════════════════════════

function getTileAt(mouseX, mouseY) {
    const originX = canvas.width  / 2 + camera.x;
    const originY = canvas.height / 2 + camera.y;

    // Stima approssimativa — punto di partenza per la ricerca
    const relX      = mouseX - originX;
    const relY      = mouseY - originY;
    const approxRow = Math.round(relY / STEP_Y);
    const approxCol = Math.round(relX / STEP_X);

    // Controlla un'area 3x3 attorno alla stima.
    // Necessario perché i rombi si sovrappongono ai bordi.
    for (let dr = -2; dr <= 2; dr++) {
        for (let dc = -2; dc <= 2; dc++) {
            const row     = approxRow + dr;
            const col     = approxCol + dc;
            const offsetX = (row % 2 !== 0) ? HALF_W : 0;
            const cx      = originX + col * STEP_X + offsetX;
            const cy      = originY + row * STEP_Y;

            const dx = Math.abs(mouseX - cx);
            const dy = Math.abs(mouseY - cy);

            if (dx / HALF_W + dy / HALF_H <= 1) {
                const mapRow = row + Math.floor(MAP_ROWS / 2);
                const mapCol = col + Math.floor(MAP_COLS / 2);

                if (mapRow < 0 || mapRow >= MAP_ROWS || mapCol < 0 || mapCol >= MAP_COLS) continue;

                const tileData = tileMap[mapRow][mapCol];
                console.log(tileData.resources)
                const tileKey = typeof tileData === 'string' ? tileData : tileData.src;

                return { 
                    row, col, mapRow, mapCol, 
                    tileKey: tileKey, 
                    fullData: tileData, // Questo contiene { src, resources, ownerId }
                    cx, cy 
                };
            }
        }
    }

    return null;   // click fuori dalla mappa
}

tilePanelBtn.addEventListener('click', () => {
    if (!currentClickedTile) return;

    // Scorre le tipologie in ordine di priorità — usa la prima disponibile
    const troopOrder = ['fanteria', 'cavalleria', 'arceri', 'balliste'];
    let chosenTroop = null;
    let chosenAmount = 0;

    for (const type of troopOrder) {
        const el     = document.getElementById(`troop-${type}`);
        const amount = el ? parseInt(el.textContent.replace(/\D/g, '')) || 0 : 0;

        if (amount > 0) {
            chosenTroop  = type;
            chosenAmount = amount;
            el.textContent = '0';   // azzera nell'UI — il server verrà aggiornato a destinazione
            break;
        }
    }

    if (!chosenTroop) {
        alert('Non ci sono soldati disponibili.');
        return;
    }

    startMarch(currentClickedTile, chosenAmount, chosenTroop);
    closeTilePanel();
});

// Aggiorna il listener click canvas per salvare currentClickedTile
canvas.addEventListener('click', e => {
    if (tilePanelOpen) { closeTilePanel(); return; }

    const rect = canvas.getBoundingClientRect();
    const tile = getTileAt(e.clientX - rect.left, e.clientY - rect.top);

    if (tile) {
        currentClickedTile = tile;
        console.log(`[Click] (${tile.mapRow}, ${tile.mapCol}) →`, tile.fullData);
        openTilePanel(tile);
    }
});


// ════════════════════════════════════════════════════
//  GAME LOOP
// ════════════════════════════════════════════════════
function gameLoop() {
    const moved = updateCamera();

    if (moved || activeMarches.length > 0) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawDiamondGrid();
        drawMarchLines();

        if (moved && activeMarches.length > 0) {
            syncMarchIndicators();
        }
    }

    requestAnimationFrame(gameLoop);
}


// ════════════════════════════════════════════════════
//  AVVIO
// ════════════════════════════════════════════════════
Promise.all([loadTiles(), loadMap(), loadPlayerUI()]).then(async () => {
    centerCameraOnCastle();

    // Ricostruisce le marce salvate DOPO che la mappa è nota
    // (mapToScreen ha bisogno di MAP_ROWS/COLS)
    await loadMarches();

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawDiamondGrid();
    drawMarchLines();
    gameLoop();

    checkMapVersion();
    setInterval(checkMapVersion, MAP_POLL_INTERVAL);
});

let resizeTimer;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
        resizeCanvas();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawDiamondGrid();
    }, 120);
});


// ════════════════════════════════════════════════════
//  SERVER DATA UTENTE
// ════════════════════════════════════════════════════

async function initServerData(userId) {
    try {
        const res = await apiFetch(`/api/users/${userId}`);
        console.log('[Server] Utente caricato:', res.data.name);
    } catch (err) {
        console.warn('[Server] Dati non disponibili:', err.message);
    }
}