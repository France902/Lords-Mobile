const canvas = document.getElementById('game-canvas');
const ctx    = canvas.getContext('2d');

// ════════════════════════════════════════════════════
//  SERVER
// ════════════════════════════════════════════════════

const USE_SERVER = true;   // la mappa viene sempre dal server ora

// Funzione generica per tutte le chiamate API.
// Invia una richiesta HTTP e restituisce i dati JSON.
// Se il server risponde con ok: false, lancia un errore.
async function apiFetch(url, options) {
    // Se non vengono passate opzioni, usiamo un oggetto vuoto
    if (options === undefined) {
        options = {};
    }

    const response = await fetch(url, {
        headers: { 'Content-Type': 'application/json' },
        method:  options.method  ?? 'GET',
        body:    options.body    ?? undefined,
    });

    const data = await response.json();

    if (!data.ok) {
        // Il server ha risposto ma segnala un errore nell'operazione
        const errorMessage = data.error !== undefined ? data.error : 'Errore sconosciuto dal server';
        throw new Error(errorMessage);
    }

    return data;
}


// ════════════════════════════════════════════════════
//  CAMERA — inizia a zero, viene centrata dopo loadMap
// ════════════════════════════════════════════════════

const CAMERA_SPEED = 6;

// La camera rappresenta lo spostamento del punto di vista
// sul canvas. x/y crescono spostando la visuale a destra/giù.
const camera = { x: 0, y: 0 };

// Tiene traccia dei tasti WASD premuti in questo momento
const keys = { w: false, a: false, s: false, d: false };

window.addEventListener('keydown', function(e) {
    if (e.key === 'w' || e.key === 'W') keys.w = true;
    if (e.key === 'a' || e.key === 'A') keys.a = true;
    if (e.key === 's' || e.key === 'S') keys.s = true;
    if (e.key === 'd' || e.key === 'D') keys.d = true;
});

window.addEventListener('keyup', function(e) {
    if (e.key === 'w' || e.key === 'W') keys.w = false;
    if (e.key === 'a' || e.key === 'A') keys.a = false;
    if (e.key === 's' || e.key === 'S') keys.s = false;
    if (e.key === 'd' || e.key === 'D') keys.d = false;
});

// Aggiorna la posizione della camera in base ai tasti premuti.
// Ritorna true se la camera si è mossa (serve al game loop per sapere
// se ridisegnare la scena).
function updateCamera() {
    let moved = false;

    if (keys.w) { camera.y += CAMERA_SPEED; moved = true; }
    if (keys.s) { camera.y -= CAMERA_SPEED; moved = true; }
    if (keys.a) { camera.x += CAMERA_SPEED; moved = true; }
    if (keys.d) { camera.x -= CAMERA_SPEED; moved = true; }

    // Salva la posizione camera in sessione così sopravvive al refresh
    if (moved) {
        sessionStorage.setItem('camera_x', camera.x);
        sessionStorage.setItem('camera_y', camera.y);
    }

    return moved;
}


// ════════════════════════════════════════════════════
//  centerCameraOnCastle()
//  Chiamata dopo loadMap() — MAP_ROWS/COLS sono già noti.
//
//  Obiettivo: posizionare la camera in modo che il castello
//  del giocatore sia al centro del viewport.
//
//  Come funziona:
//  - drawDiamondGrid disegna ogni tile alla posizione:
//      cx = originX + relCol * STEP_X + offsetX
//      cy = originY + relRow * STEP_Y
//  - "rel" = posizione relativa al centro della mappa
//  - Vogliamo che cx = canvas.width/2 e cy = canvas.height/2
//  - Questo significa che camera.x deve "annullare" l'offset
//    del castello rispetto al centro della mappa.
// ════════════════════════════════════════════════════

function centerCameraOnCastle() {
    const castleRow = parseInt(sessionStorage.getItem('castleRow'));
    const castleCol = parseInt(sessionStorage.getItem('castleCol'));

    // Se le coordinate non ci sono (primo accesso), non spostiamo nulla
    if (isNaN(castleRow) || isNaN(castleCol)) return;

    // Posizione del castello rispetto al centro della mappa (in unità tile)
    const relRow = castleRow - Math.floor(MAP_ROWS / 2);
    const relCol = castleCol - Math.floor(MAP_COLS / 2);

    // Le righe dispari sono sfalsate orizzontalmente di HALF_W (griglia isometrica)
    const offsetX = (relRow % 2 !== 0) ? HALF_W : 0;

    // Impostiamo la camera in modo che il castello finisca al centro
    camera.x = -(relCol * STEP_X + offsetX);
    camera.y = -(relRow * STEP_Y);
}


// ════════════════════════════════════════════════════
//  UI — carica e renderizza dati giocatore dal server
// ════════════════════════════════════════════════════

async function loadPlayerUI() {
    const userId = sessionStorage.getItem('userId');
    if (!userId) return;

    try {
        // Carica in parallelo: dati utente, risorse e truppe
        const userResult   = await apiFetch('/api/users/' + userId);
        const resResult    = await apiFetch('/api/resources/' + userId);
        const troopsResult = await apiFetch('/api/troops/' + userId);

        const user   = userResult.data;
        const res    = resResult.data;
        const troops = troopsResult.data;

        // Aggiorna l'UI con i dati ricevuti
        document.getElementById('player-id').textContent      = user.id.toLocaleString('it-IT');
        document.getElementById('power-value').textContent    = user.power.toLocaleString('it-IT');

        document.getElementById('res-grano').textContent      = res.grano.toLocaleString('it-IT');
        document.getElementById('res-legno').textContent      = res.legno.toLocaleString('it-IT');
        document.getElementById('res-pietra').textContent     = res.pietra.toLocaleString('it-IT');
        document.getElementById('res-minerali').textContent   = res.minerali.toLocaleString('it-IT');

        document.getElementById('troop-fanteria').textContent   = troops.fanteria.toLocaleString('it-IT');
        document.getElementById('troop-cavalleria').textContent = troops.cavalleria.toLocaleString('it-IT');
        document.getElementById('troop-arceri').textContent     = troops.arceri.toLocaleString('it-IT');
        document.getElementById('troop-balliste').textContent   = troops.balliste.toLocaleString('it-IT');

    } catch (err) {
        console.warn('[UI] Dati giocatore non disponibili:', err.message);
    }
}


// ════════════════════════════════════════════════════
//  CANVAS
// ════════════════════════════════════════════════════

function resizeCanvas() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
}

resizeCanvas();


// ════════════════════════════════════════════════════
//  MAPPA — ricevuta dal server
// ════════════════════════════════════════════════════

let tileMap  = [];
let MAP_COLS = 0;
let MAP_ROWS = 0;

async function loadMap() {
    const res = await apiFetch('/api/map');
    tileMap   = res.data.map;
    MAP_COLS  = res.data.cols;
    MAP_ROWS  = res.data.rows;
    console.log('[Map] Mappa ' + MAP_COLS + 'x' + MAP_ROWS + ' ricevuta dal server.');
}


// ════════════════════════════════════════════════════
//  TILE TYPES — dizionario di tutti i tipi di terreno.
//  Ogni tile ha un percorso immagine (src) e due proprietà
//  che vengono riempite al caricamento: pattern e image.
//    pattern → usato da fillStyle per riempire i rombi
//    image   → usato da drawImage per sovrapporre l'icona
// ════════════════════════════════════════════════════

const TILE_TYPES = {
    grass1:      { src: '/data/input/resources/grass.png',       pattern: null },
    grass2:      { src: '/data/input/resources/grass2.png',      pattern: null },
    grass3:      { src: '/data/input/resources/grass3.png',      pattern: null },
    grass4:      { src: '/data/input/resources/grass4.png',      pattern: null },
    trees1:      { src: '/data/input/resources/trees.png',       pattern: null },
    trees2:      { src: '/data/input/resources/trees2.png',      pattern: null },
    trees3:      { src: '/data/input/resources/trees3.png',      pattern: null },
    campwheat:   { src: '/data/input/resources/wheatcamp.png',   pattern: null },
    campmineral: { src: '/data/input/resources/mineralcamp.png', pattern: null },
    camprock:    { src: '/data/input/resources/rockcamp.png',    pattern: null },
    campwood:    { src: '/data/input/resources/woodcamp.png',    pattern: null },
    mainplayer:  { src: '/data/input/resources/castleblue.png',  pattern: null },
    enemyplayer: { src: '/data/input/resources/castlered.png',   pattern: null },
};

// Carica tutte le immagini delle tile in parallelo.
// Ogni immagine genera anche un CanvasPattern usato come fillStyle.
function loadTiles() {
    const promises = Object.keys(TILE_TYPES).map(function(key) {
        const tile = TILE_TYPES[key];

        return new Promise(function(resolve) {
            const img = new Image();

            img.onload = function() {
                tile.pattern = ctx.createPattern(img, 'repeat');
                tile.image   = img;   // necessario per drawImage nei rombi
                resolve();
            };

            img.onerror = function() {
                console.warn('[Tile] "' + key + '" non trovato.');
                tile.pattern = '#4caf50';   // colore verde di fallback
                tile.image   = null;
                resolve();
            };

            img.src = tile.src;
        });
    });

    return Promise.all(promises);
}


// ════════════════════════════════════════════════════
//  COSTANTI GRIGLIA — dimensioni del rombo isometrico.
//
//  HALF_H = metà altezza del rombo
//  HALF_W = metà larghezza (sempre il doppio di HALF_H)
//  STEP_X = spazio orizzontale tra i centri di due tile
//           sulla stessa riga (= larghezza intera)
//  STEP_Y = spazio verticale tra righe adiacenti
//           (= metà altezza — le righe si sovrappongono)
// ════════════════════════════════════════════════════

const HALF_H = 54;
const HALF_W = HALF_H * 2;   // = 108
const STEP_X = HALF_W * 2;   // = 216
const STEP_Y = HALF_H;       // = 54

// Nomi leggibili per ogni tipo di tile — mostrati nel pannello al click
const TILE_NAMES = {
    grass1:      'Piana erbosa',
    grass2:      'Prateria aperta',
    grass3:      'Pianura fertile',
    grass4:      'Campo selvatico',
    trees1:      'Bosco fitto',
    trees2:      'Foresta incontaminata',
    trees3:      'Foresta antica',
    campwheat:   'Campo di grano',
    campmineral: 'Miniera di minerali',
    camprock:    'Cava di pietra',
    campwood:    'Riserva di legname',
};

// Risorse iniziali per ogni camp — in futuro verranno lette dal server
const CAMP_RESOURCES = {
    campwheat:   2000,
    campmineral: 2000,
    camprock:    2000,
    campwood:    2000,
};

const CAMP_RESOURCE_LABELS = {
    campwheat:   'Grano disponibile',
    campmineral: 'Minerale disponibile',
    camprock:    'Pietra disponibile',
    campwood:    'Legname disponibile',
};


// ════════════════════════════════════════════════════
//  TILE PANEL — logica apertura/chiusura
// ════════════════════════════════════════════════════

const tilePanel     = document.getElementById('tile-panel');
const tilePanelName = document.getElementById('tile-panel-name');
const tilePanelRes  = document.getElementById('tile-panel-resources');
const tilePanelBtn  = document.getElementById('tile-panel-btn');

let tilePanelOpen = false;


// ════════════════════════════════════════════════════
//  MAP POLLING — controlla ogni 30s se la mappa è cambiata.
//
//  Prima chiama /api/map/version (piccolo, veloce) per sapere
//  se c'è una nuova versione. Solo in quel caso scarica
//  l'intera mappa — evita traffico inutile.
// ════════════════════════════════════════════════════

let lastMapVersion = null;

async function checkMapVersion() {
    try {
        const res     = await apiFetch('/api/map/version');
        const version = res.data.version;

        // Prima esecuzione: salva la versione attuale senza ricaricare
        if (lastMapVersion === null) {
            lastMapVersion = version;
            return;
        }

        // Se la versione è cambiata, scarica la mappa aggiornata
        if (version !== lastMapVersion) {
            console.log('[Map] Nuova versione rilevata — ricarico la mappa...');
            lastMapVersion = version;
            await reloadMap();
        }

    } catch (err) {
        console.warn('[Poll] Errore verifica versione mappa:', err.message);
    }
}

async function reloadMap() {
    try {
        const res = await apiFetch('/api/map');
        tileMap   = res.data.map;
        MAP_COLS  = res.data.cols;
        MAP_ROWS  = res.data.rows;

        // Ridisegna subito con la nuova mappa
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawDiamondGrid();
        drawMarchLines();

        console.log('[Map] Mappa aggiornata dal server.');
    } catch (err) {
        console.warn('[Map] Errore ricaricamento mappa:', err.message);
    }
}

// Intervallo di polling: 30 secondi
// Non serve più frequente — la mappa si rigenera ogni ora
const MAP_POLL_INTERVAL = 30 * 1000;


// ════════════════════════════════════════════════════
//  MARCH SYSTEM — marce multiple simultanee.
//
//  Ogni marcia è un oggetto nell'array activeMarches.
//  Una marcia ha tre fasi in sequenza:
//    1. 'marching'  — le truppe si muovono verso la destinazione
//    2. 'gathering' — le truppe raccolgono risorse (o combattono)
//    3. 'returning' — le truppe tornano al castello
//
//  L'animazione usa CSS transition su left/top del div indicatore.
// ════════════════════════════════════════════════════

const activeMarches = [];   // ogni elemento è una marcia indipendente


// Converte una posizione sulla mappa (riga, colonna) in coordinate
// pixel sul canvas, tenendo conto della camera e dello sfalsamento
// isometrico delle righe dispari.
function mapToScreen(mapRow, mapCol) {
    const relRow  = mapRow - Math.floor(MAP_ROWS / 2);
    const relCol  = mapCol - Math.floor(MAP_COLS / 2);

    // Le righe dispari sono sfalsate a destra di HALF_W (griglia isometrica)
    const offsetX = (relRow % 2 !== 0) ? HALF_W : 0;

    return {
        x: canvas.width  / 2 + camera.x + relCol * STEP_X + offsetX,
        y: canvas.height / 2 + camera.y + relRow * STEP_Y,
    };
}

// Distanza Manhattan tra due tile (usata per calcolare la durata della marcia)
function tileDistance(r1, c1, r2, c2) {
    return Math.abs(r2 - r1) + Math.abs(c2 - c1);
}

// Crea il div HTML che appare sulla mappa per rappresentare una marcia.
// Viene rimosso quando la marcia termina.
function createMarchIndicator(troops, troopType) {
    const el = document.createElement('div');
    el.className = 'march-indicator';

    const icons = { fanteria: '⚔️', cavalleria: '🐴', arceri: '🏹', balliste: '🪨' };
    const icon  = icons[troopType] !== undefined ? icons[troopType] : '⚔️';
    el.innerHTML = icon + '<br>' + troops;

    document.getElementById('ui').appendChild(el);
    return el;
}


// ════════════════════════════════════════════════════
//  MARCH SYSTEM — con persistenza server
// ════════════════════════════════════════════════════

const GATHER_DURATION_PER_TROOP = 2;

// Calcola la durata della fase di raccolta per una marcia.
// Usa il valore salvato dal server se disponibile,
// altrimenti lo calcola dalle truppe.
function _getGatherDuration(march) {
    if (march.gatherDuration && march.gatherDuration > 0) {
        return march.gatherDuration;
    }
    return (march.troops !== undefined ? march.troops : 1) * GATHER_DURATION_PER_TROOP;
}

// Ricostruisce una marcia già avviata (es. dopo un refresh della pagina).
// Calcola a che punto è la marcia in base al tempo trascorso,
// poi avvia l'animazione dalla fase corretta.
function _spawnMarch(march) {
    const gatherDuration = _getGatherDuration(march);

    // Durata totale = andata + raccolta + ritorno
    const totalDuration = march.durationSeconds * 2 + gatherDuration;
    const elapsed       = (Date.now() - march.startTime) / 1000;

    // La marcia è già completata mentre eravamo offline: chiudiamo sul server
    if (elapsed >= totalDuration) {
        const userId = sessionStorage.getItem('userId');
        if (march.id && userId) {
            apiFetch('/api/marches/' + userId + '/' + march.id, { method: 'DELETE' })
                .then(function() { loadPlayerUI(); })
                .catch(function() {});
        }
        console.log('[March] ' + march.id + ' già completata offline — truppe restituite.');
        return;
    }

    // Coordinate schermo del castello e della destinazione
    const fromPos = mapToScreen(march.castleRow, march.castleCol);
    const toPos   = mapToScreen(march.targetRow,  march.targetCol);

    // Determina la fase attuale e la posizione visiva corrente
    let currentX, currentY, phase;

    if (elapsed < march.durationSeconds) {
        // FASE 1: in viaggio verso la destinazione
        // p = quanto è avanzata la marcia (0.0 = appena partita, 1.0 = arrivata)
        phase        = 'marching';
        const p      = elapsed / march.durationSeconds;
        currentX     = fromPos.x + (toPos.x - fromPos.x) * p;
        currentY     = fromPos.y + (toPos.y - fromPos.y) * p;

    } else if (elapsed < march.durationSeconds + gatherDuration) {
        // FASE 2: ferma alla destinazione, sta raccogliendo
        phase    = 'gathering';
        currentX = toPos.x;
        currentY = toPos.y;

    } else {
        // FASE 3: in viaggio di ritorno al castello
        // returnElapsed = secondi trascorsi dall'inizio del ritorno
        phase               = 'returning';
        const returnElapsed = elapsed - march.durationSeconds - gatherDuration;
        const p             = returnElapsed / march.durationSeconds;
        currentX            = toPos.x + (fromPos.x - toPos.x) * p;
        currentY            = toPos.y + (fromPos.y - toPos.y) * p;
    }

    // Crea l'indicatore visivo e lo posiziona sulla posizione attuale
    const indicator = createMarchIndicator(march.troops, march.troopType);
    _updateIndicatorStyle(indicator, phase);
    indicator.style.transition = 'none';
    indicator.style.left       = (currentX - 20) + 'px';
    indicator.style.top        = (currentY - 20) + 'px';
    indicator.style.display    = 'flex';

    // Costruisce l'oggetto marcia completo e lo aggiunge all'array attivo
    const marchObj = Object.assign({}, march, { indicator: indicator, gatherDuration: gatherDuration });
    activeMarches.push(marchObj);

    // Avvia l'animazione dalla fase attuale
    _runMarchPhase(marchObj, phase, elapsed);
}

// Cambia il colore dell'indicatore in base alla fase corrente:
//   marching  = oro    (in viaggio)
//   gathering = verde  (raccolta)
//   returning = blu    (ritorno)
function _updateIndicatorStyle(indicator, phase) {
    if (phase === 'marching') {
        indicator.style.background = 'rgba(201, 168, 76, 0.85)';
    } else if (phase === 'gathering') {
        indicator.style.background = 'rgba(76, 175, 80, 0.85)';
    } else {
        indicator.style.background = 'rgba(100, 149, 237, 0.85)';
    }
}

// Gestisce l'animazione di una singola fase della marcia.
// Al termine di ogni fase chiama se stessa per avviare la successiva.
//
//   elapsedAtSpawn = secondi già trascorsi quando questa funzione viene chiamata
//                    (serve per calcolare quanto tempo rimane nella fase attuale)
function _runMarchPhase(march, phase, elapsedAtSpawn) {
    const fromPos        = mapToScreen(march.castleRow, march.castleCol);
    const toPos          = mapToScreen(march.targetRow,  march.targetCol);
    const gatherDuration = _getGatherDuration(march);

    if (phase === 'marching') {
        // Calcola il tempo rimasto per arrivare a destinazione
        const remaining = march.durationSeconds - elapsedAtSpawn;

        // Due requestAnimationFrame consecutivi garantiscono che il browser
        // abbia eseguito almeno un layout prima di avviare la transition CSS.
        // Senza questo, impostare transition e posizione nello stesso frame
        // farebbe ignorare la transition (nessuna animazione visibile).
        requestAnimationFrame(function() {
            requestAnimationFrame(function() {
                march.indicator.style.transition = 'left ' + remaining + 's linear, top ' + remaining + 's linear';
                march.indicator.style.left = (toPos.x - 20) + 'px';
                march.indicator.style.top  = (toPos.y - 20) + 'px';
            });
        });

        // Quando arrivа a destinazione, passa alla fase di raccolta
        setTimeout(function() {
            _updateIndicatorStyle(march.indicator, 'gathering');
            march.indicator.style.transition = 'none';
            march.indicator.style.left = (toPos.x - 20) + 'px';
            march.indicator.style.top  = (toPos.y - 20) + 'px';
            _runMarchPhase(march, 'gathering', march.durationSeconds);
        }, remaining * 1000);

    } else if (phase === 'gathering') {
        // Calcola quanto tempo di raccolta è già trascorso
        const gatherElapsed   = Math.max(0, elapsedAtSpawn - march.durationSeconds);
        const gatherRemaining = gatherDuration - gatherElapsed;

        // Quando la raccolta finisce, avvia il ritorno
        setTimeout(function() {
            _updateIndicatorStyle(march.indicator, 'returning');
            _runMarchPhase(march, 'returning', march.durationSeconds + gatherDuration);
        }, gatherRemaining * 1000);

    } else if (phase === 'returning') {
        // Calcola il tempo rimasto per tornare al castello
        const returnElapsed   = Math.max(0, elapsedAtSpawn - march.durationSeconds - gatherDuration);
        const returnRemaining = march.durationSeconds - returnElapsed;

        // Anima il ritorno verso il castello (stesso meccanismo della partenza)
        requestAnimationFrame(function() {
            requestAnimationFrame(function() {
                march.indicator.style.transition = 'left ' + returnRemaining + 's linear, top ' + returnRemaining + 's linear';
                march.indicator.style.left = (fromPos.x - 20) + 'px';
                march.indicator.style.top  = (fromPos.y - 20) + 'px';
            });
        });

        // Al termine del ritorno: chiude la marcia e aggiorna risorse/truppe
        setTimeout(async function() {
            // Rimuove la marcia dall'array attivo
            const idx = activeMarches.findIndex(function(m) { return m.id === march.id; });
            if (idx !== -1) {
                activeMarches.splice(idx, 1);
            }
            march.indicator.remove();

            const userId = sessionStorage.getItem('userId');
            if (march.id && userId) {

                const isCamp  = march.targetTileKey !== undefined && march.targetTileKey.startsWith('camp');
                const isEnemy = march.targetTileKey === 'enemyplayer';

                // 1. Se era un camp: raccoglie risorse tramite API
                if (isCamp) {
                    try {
                        await apiFetch('/api/map/loot', {
                            method: 'POST',
                            body: JSON.stringify({
                                userId:  userId,
                                row:     march.targetRow,
                                col:     march.targetCol,
                                troops:  march.troops,
                            }),
                        });
                    } catch (err) {
                        console.warn('[March] Errore loot:', err.message);
                    }
                }

                // 2. Se era un castello nemico: risolve la battaglia
                if (isEnemy) {
                    try {
                        const res = await apiFetch('/api/battles/resolve', {
                            method: 'POST',
                            body: JSON.stringify({
                                attackerId:  userId,
                                defenderId:  march.targetOwnerId,
                                troopType:   march.troopType,
                                marchTroops: march.troops,
                            }),
                        });

                        const b = res.data;

                        // Costruisce il messaggio di esito della battaglia
                        let esito;
                        if (b.winner === 'attacker') {
                            // Converte il bottino in una stringa leggibile
                            const lootParts = [];
                            const lootKeys  = Object.keys(b.loot);
                            for (let i = 0; i < lootKeys.length; i++) {
                                lootParts.push(b.loot[lootKeys[i]] + ' ' + lootKeys[i]);
                            }
                            esito = '⚔️ Hai VINTO!\nPerdite: ' + b.attackerLosses + '\nBottino: ' + lootParts.join(', ');
                        } else {
                            esito = '💀 Hai PERSO!\nPerdite: ' + b.attackerLosses;
                        }
                        alert(esito);

                    } catch (err) {
                        console.warn('[Battle] Errore risoluzione:', err.message);
                    }
                }

                // 3. Chiude la marcia sul server.
                // Per le battaglie NON restituisce le truppe (già gestito da /api/battles/resolve).
                // Per i camp SÌ le restituisce.
                const returnTroops = isEnemy ? 'false' : 'true';
                try {
                    await apiFetch('/api/marches/' + userId + '/' + march.id + '?returnTroops=' + returnTroops, { method: 'DELETE' });
                } catch (err) {
                    console.warn('[March] Errore chiusura:', err.message);
                }

                await loadPlayerUI();
            }
        }, returnRemaining * 1000);
    }
}

// Avvia una nuova marcia verso una tile (camp o castello nemico).
// Salva la marcia sul server e poi avvia l'animazione locale.
async function startMarch(targetTile, troops, troopType) {
    const castleRow = parseInt(sessionStorage.getItem('castleRow'));
    const castleCol = parseInt(sessionStorage.getItem('castleCol'));
    const userId    = sessionStorage.getItem('userId');

    if (isNaN(castleRow) || isNaN(castleCol)) {
        console.warn('[March] Posizione castello non in sessione.');
        return;
    }

    // Ogni tile di distanza costa 30 secondi di marcia
    const distance        = tileDistance(castleRow, castleCol, targetTile.mapRow, targetTile.mapCol);
    const durationSeconds = distance * 30;
    const startTime       = Date.now();

    // Le battaglie non hanno fase di raccolta
    const isBattle       = targetTile.tileKey === 'enemyplayer';
    const gatherDuration = isBattle ? 0 : troops * GATHER_DURATION_PER_TROOP;

    // Salva la marcia sul server e riceve l'ID assegnato
    let marchId = null;
    try {
        const res = await apiFetch('/api/marches', {
            method: 'POST',
            body: JSON.stringify({
                userId:         userId,
                castleRow:      castleRow,
                castleCol:      castleCol,
                targetRow:      targetTile.mapRow,
                targetCol:      targetTile.mapCol,
                troops:         troops,
                troopType:      troopType,
                durationSeconds: durationSeconds,
                startTime:       startTime,
                gatherDuration:  gatherDuration,
            }),
        });
        marchId = res.data.marchId;

        loadPlayerUI();

        // Azzera le truppe inviate nell'UI locale (il server è già aggiornato)
        const el = document.getElementById('troop-' + troopType);
        if (el) el.textContent = '0';

    } catch (err) {
        alert('Errore avvio marcia: ' + err.message);
        return;
    }

    // Legge l'ownerId della tile in modo sicuro (può essere null)
    let targetOwnerId = null;
    if (targetTile.fullData !== undefined && targetTile.fullData !== null) {
        targetOwnerId = targetTile.fullData.ownerId !== undefined ? targetTile.fullData.ownerId : null;
    }

    _spawnMarch({
        id:             marchId,
        castleRow:      castleRow,
        castleCol:      castleCol,
        targetRow:      targetTile.mapRow,
        targetCol:      targetTile.mapCol,
        troops:         troops,
        troopType:      troopType,
        durationSeconds: durationSeconds,
        startTime:       startTime,
        gatherDuration:  gatherDuration,
        targetTileKey:  targetTile.tileKey,
        targetOwnerId:  targetOwnerId,
    });
}

// Carica le marce attive dal server (es. dopo un refresh della pagina)
// e ricostruisce l'animazione per ognuna.
async function loadMarches() {
    const userId = sessionStorage.getItem('userId');
    if (!userId) return;

    try {
        const res     = await apiFetch('/api/marches/' + userId);
        const marches = res.data;
        if (marches.length === 0) return;

        for (let i = 0; i < marches.length; i++) {
            const march    = marches[i];
            const tileData = tileMap[march.targetRow] !== undefined
                ? tileMap[march.targetRow][march.targetCol]
                : undefined;

            // Ricava il tileKey dalla tile: può essere una stringa o un oggetto
            let tileKey = '';
            if (typeof tileData === 'string') {
                tileKey = tileData;
            } else if (tileData !== undefined && tileData.src !== undefined) {
                tileKey = tileData.src;
            }

            // Aggiunge l'id (il server usa marchId, internamente usiamo id)
            const marchWithId = Object.assign({}, march, { id: march.marchId, targetTileKey: tileKey });
            _spawnMarch(marchWithId);
        }

    } catch (err) {
        console.warn('[March] Impossibile caricare le marce:', err.message);
    }
}

// Disegna le linee tratteggiate che collegano castello e destinazione
// per ogni marcia attiva.
function drawMarchLines() {
    if (activeMarches.length === 0) return;

    for (let i = 0; i < activeMarches.length; i++) {
        const march = activeMarches[i];
        const from  = mapToScreen(march.castleRow, march.castleCol);
        const to    = mapToScreen(march.targetRow,  march.targetCol);

        ctx.beginPath();
        ctx.moveTo(from.x, from.y);
        ctx.lineTo(to.x,   to.y);
        ctx.strokeStyle = 'rgba(201, 168, 76, 0.6)';
        ctx.lineWidth   = 2;
        ctx.setLineDash([8, 6]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Cerchietto alle due estremità della linea
        const endpoints = [from, to];
        for (let j = 0; j < endpoints.length; j++) {
            const p = endpoints[j];
            ctx.beginPath();
            ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(201, 168, 76, 0.8)';
            ctx.fill();
        }
    }
}

// Risincronizza la posizione visiva degli indicatori HTML
// quando la camera si sposta (i div non si muovono con il canvas).
//
// Per ogni marcia attiva:
//   1. Calcola la posizione pixel attuale in base al tempo trascorso
//   2. Sposta subito il div (transition: none) alla posizione corretta
//   3. Riattiva la transition verso la destinazione con il tempo residuo
function syncMarchIndicators() {
    const now = Date.now();

    for (let i = 0; i < activeMarches.length; i++) {
        const march          = activeMarches[i];
        const elapsed        = (now - march.startTime) / 1000;
        const gatherDuration = march.gatherDuration !== undefined ? march.gatherDuration : GATHER_DURATION_PER_TROOP;

        const fromPos = mapToScreen(march.castleRow, march.castleCol);
        const toPos   = mapToScreen(march.targetRow,  march.targetCol);

        let currentX, currentY, remaining, destX, destY;

        if (elapsed < march.durationSeconds) {
            // Fase 1: interpolazione lineare verso la destinazione
            const p   = elapsed / march.durationSeconds;
            currentX  = fromPos.x + (toPos.x - fromPos.x) * p;
            currentY  = fromPos.y + (toPos.y - fromPos.y) * p;
            remaining = march.durationSeconds - elapsed;
            destX     = toPos.x;
            destY     = toPos.y;

        } else if (elapsed < march.durationSeconds + gatherDuration) {
            // Fase 2: fermo alla destinazione
            currentX  = toPos.x;
            currentY  = toPos.y;
            remaining = 0;
            destX     = toPos.x;
            destY     = toPos.y;

        } else {
            // Fase 3: interpolazione lineare verso il castello
            const returnElapsed = elapsed - march.durationSeconds - gatherDuration;
            const p   = Math.min(returnElapsed / march.durationSeconds, 1);
            currentX  = toPos.x + (fromPos.x - toPos.x) * p;
            currentY  = toPos.y + (fromPos.y - toPos.y) * p;
            remaining = Math.max(march.durationSeconds - returnElapsed, 0);
            destX     = fromPos.x;
            destY     = fromPos.y;
        }

        // Sposta istantaneamente alla posizione corretta
        march.indicator.style.transition = 'none';
        march.indicator.style.left = (currentX - 20) + 'px';
        march.indicator.style.top  = (currentY  - 20) + 'px';

        // Poi riavvia la transition verso la destinazione
        if (remaining > 0) {
            const dest_x = destX;
            const dest_y = destY;
            requestAnimationFrame(function() {
                march.indicator.style.transition = 'left ' + remaining + 's linear, top ' + remaining + 's linear';
                march.indicator.style.left = (dest_x - 20) + 'px';
                march.indicator.style.top  = (dest_y - 20) + 'px';
            });
        }
    }
}


// ════════════════════════════════════════════════════
//  TILE PANEL — apertura con dati della tile cliccata
// ════════════════════════════════════════════════════

function openTilePanel(tile) {
    const tileData = tile.fullData;
    const tileKey  = tile.tileKey;

    // Mostra il nome leggibile della tile
    const name = TILE_NAMES[tileKey] !== undefined ? TILE_NAMES[tileKey] : tileKey;
    tilePanelName.textContent = name;

    // Per i camp mostra le risorse disponibili (dato dal server)
    if (tileKey.startsWith('camp')) {
        let amount = 0;
        if (tileData !== undefined && tileData !== null && tileData.resources !== null) {
            amount = tileData.resources;
        }
        const label = CAMP_RESOURCE_LABELS[tileKey] !== undefined ? CAMP_RESOURCE_LABELS[tileKey] : 'Risorse disponibili';
        tilePanelRes.textContent   = label + ': ' + amount.toLocaleString('it-IT');
        tilePanelRes.style.display = 'block';
    } else {
        tilePanelRes.style.display = 'none';
    }

    // Bottone MARCIA: visibile solo per i camp
    const isCamp = tileKey.startsWith('camp');
    tilePanelBtn.style.display = isCamp ? 'inline-block' : 'none';

    // Bottone ATTACCA: visibile solo per i castelli nemici
    const isEnemy = tileKey === 'enemyplayer';
    tilePanelAttackBtn.style.display = isEnemy ? 'inline-block' : 'none';

    tilePanel.classList.add('visible');
    tilePanelOpen = true;
}

function closeTilePanel() {
    tilePanel.classList.remove('visible');
    tilePanelOpen = false;
}

// ESC chiude il pannello
window.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && tilePanelOpen) closeTilePanel();
});


// ════════════════════════════════════════════════════
//  DRAW
// ════════════════════════════════════════════════════

// Disegna un singolo rombo isometrico centrato in (cx, cy).
// Se la tile è un albero, camp o castello, disegna anche
// l'immagine sopra al rombo.
function drawDiamond(cx, cy, fillStyle, tileKey) {
    // 1. Disegna il rombo (terreno di base)
    ctx.beginPath();
    ctx.moveTo(cx,          cy - HALF_H);   // vertice in alto
    ctx.lineTo(cx + HALF_W, cy);            // vertice a destra
    ctx.lineTo(cx,          cy + HALF_H);   // vertice in basso
    ctx.lineTo(cx - HALF_W, cy);            // vertice a sinistra
    ctx.closePath();

    ctx.fillStyle = fillStyle || '#4caf50';
    ctx.fill();

    // 2. Sovrappone l'immagine (albero, camp, castello) se presente
    const needsImage = tileKey !== undefined && (
        tileKey.startsWith('trees') ||
        tileKey.startsWith('camp')  ||
        tileKey.startsWith('main')  ||
        tileKey.startsWith('enemy')
    );

    if (needsImage) {
        const tileCfg = TILE_TYPES[tileKey];
        if (tileCfg !== undefined && tileCfg.image !== null) {
            const imgW = 100;
            const imgH = 100;
            // L'immagine è centrata orizzontalmente sul rombo e leggermente
            // alzata (+25) per sembrare "piantata" nel terreno
            ctx.drawImage(tileCfg.image, cx - imgW / 2, cy - imgH + 25, imgW, imgH);
        }
    }

    ctx.lineWidth   = 2;
    ctx.strokeStyle = fillStyle;
    ctx.stroke();
}

// Disegna l'intera griglia isometrica visibile nel viewport.
// Calcola quali tile sono visibili in base alla posizione della camera,
// poi disegna solo quelle — evita di iterare tutta la mappa.
function drawDiamondGrid() {
    const w       = canvas.width;
    const h       = canvas.height;
    const originX = w / 2 + camera.x;
    const originY = h / 2 + camera.y;

    // Quante tile coprono il viewport + un margine di 6 per evitare pop-in
    const visibleCols = Math.ceil(w / STEP_X) + 6;
    const visibleRows = Math.ceil(h / STEP_Y) + 6;

    // Tile relativa al centro della mappa che si trova ora al centro dello schermo
    const centerRelCol = Math.round(-camera.x / STEP_X);
    const centerRelRow = Math.round(-camera.y / STEP_Y);

    const halfC = Math.ceil(visibleCols / 2);
    const halfR = Math.ceil(visibleRows / 2);

    for (let dr = -halfR; dr <= halfR; dr++) {
        const row     = centerRelRow + dr;
        const offsetX = (row % 2 !== 0) ? HALF_W : 0;   // sfalsamento righe dispari

        for (let dc = -halfC; dc <= halfC; dc++) {
            const col = centerRelCol + dc;

            // Converti da coordinate relative a coordinate assolute nella mappa
            const mapRow = row + Math.floor(MAP_ROWS / 2);
            const mapCol = col + Math.floor(MAP_COLS / 2);

            // Salta le tile fuori dai bordi della mappa
            if (mapRow < 0 || mapRow >= MAP_ROWS || mapCol < 0 || mapCol >= MAP_COLS) continue;

            const tileData = tileMap[mapRow][mapCol];
            if (!tileData) continue;

            // Il tileKey può essere una stringa diretta o dentro tileData.src
            let tileKey = typeof tileData === 'string' ? tileData : tileData.src;

            // I castelli mostrano colore diverso a seconda di chi è il proprietario
            if (tileKey === 'mainplayer' || tileKey === 'enemyplayer') {
                const ownerId     = tileData.ownerId !== undefined ? tileData.ownerId : null;
                const currentUser = sessionStorage.getItem('userId');
                tileKey = (ownerId === currentUser) ? 'mainplayer' : 'enemyplayer';
            }

            const tileCfg = TILE_TYPES[tileKey];
            if (!tileCfg) continue;

            // Coordinate pixel del centro di questa tile
            const cx = originX + col * STEP_X + offsetX;
            const cy = originY + row * STEP_Y;

            // Le tile con immagine sovrapposta (alberi, camp, castelli) usano l'erba
            // come base del rombo — l'immagine viene disegnata sopra da drawDiamond
            const isOverlay = tileKey.startsWith('trees') || tileKey.startsWith('camp')
                           || tileKey === 'mainplayer'    || tileKey === 'enemyplayer';

            let currentStyle = isOverlay ? TILE_TYPES['grass1'].pattern : tileCfg.pattern;

            // Il pattern deve essere traslato al centro del rombo corrente,
            // altrimenti si disallineerebbe scorrendo la camera
            if (currentStyle instanceof CanvasPattern) {
                const matrix = new DOMMatrix();
                matrix.translateSelf(cx - HALF_W, cy - HALF_H);
                currentStyle.setTransform(matrix);
            }

            drawDiamond(cx, cy, currentStyle, tileKey);
        }
    }
}


// ════════════════════════════════════════════════════
//  HIT DETECTION — quale rombo ha cliccato il mouse?
//
//  Un punto (px, py) è DENTRO un rombo centrato in (cx, cy)
//  se soddisfa questa condizione:
//
//    |px - cx| / HALF_W  +  |py - cy| / HALF_H  <=  1
//
//  Questa è la formula della distanza "a Manhattan" normalizzata.
//  Il rombo è esattamente la "sfera di raggio 1" in questa metrica:
//  tutti i punti equidistanti dal centro secondo questa misura
//  formano un rombo (invece di un cerchio come in Euclide).
// ════════════════════════════════════════════════════

function getTileAt(mouseX, mouseY) {
    const originX = canvas.width  / 2 + camera.x;
    const originY = canvas.height / 2 + camera.y;

    // Stima approssimativa del rombo: divide le coordinate per la dimensione
    // di una tile per ottenere l'indice di riga/colonna di partenza.
    // Non è esatta (i rombi si sovrappongono sui bordi), ma è un buon punto
    // di partenza per la ricerca nell'area 5x5 qui sotto.
    const relX      = mouseX - originX;
    const relY      = mouseY - originY;
    const approxRow = Math.round(relY / STEP_Y);
    const approxCol = Math.round(relX / STEP_X);

    // Controlla un'area 5x5 attorno alla stima.
    // Necessario perché i rombi isometrici si sovrappongono agli angoli:
    // un click vicino al bordo di un rombo può appartenere a quello adiacente.
    for (let dr = -2; dr <= 2; dr++) {
        for (let dc = -2; dc <= 2; dc++) {
            const row     = approxRow + dr;
            const col     = approxCol + dc;
            const offsetX = (row % 2 !== 0) ? HALF_W : 0;
            const cx      = originX + col * STEP_X + offsetX;
            const cy      = originY + row * STEP_Y;

            // Test di appartenenza al rombo (vedi commento sopra)
            const dx = Math.abs(mouseX - cx);
            const dy = Math.abs(mouseY - cy);

            if (dx / HALF_W + dy / HALF_H <= 1) {
                const mapRow = row + Math.floor(MAP_ROWS / 2);
                const mapCol = col + Math.floor(MAP_COLS / 2);

                if (mapRow < 0 || mapRow >= MAP_ROWS || mapCol < 0 || mapCol >= MAP_COLS) continue;

                const tileData = tileMap[mapRow][mapCol];
                let tileKey    = typeof tileData === 'string' ? tileData : tileData.src;

                // Distingue castello del giocatore da quello nemico
                if (tileKey === 'mainplayer' || tileKey === 'enemyplayer') {
                    const ownerId     = tileData.ownerId !== undefined ? tileData.ownerId : null;
                    const currentUser = sessionStorage.getItem('userId');
                    tileKey = (ownerId === currentUser) ? 'mainplayer' : 'enemyplayer';
                }

                return {
                    row:      row,
                    col:      col,
                    mapRow:   mapRow,
                    mapCol:   mapCol,
                    tileKey:  tileKey,
                    fullData: tileData,   // contiene { src, resources, ownerId }
                    cx:       cx,
                    cy:       cy,
                };
            }
        }
    }

    return null;   // click fuori dalla mappa
}

// ════════════════════════════════════════════════════
//  CLICK SU BOTTONI PANNELLO
// ════════════════════════════════════════════════════

// Bottone "VAI" — invia truppe verso un camp
tilePanelBtn.addEventListener('click', function() {
    if (!currentClickedTile) return;

    // Cerca la prima tipologia di truppe disponibile (in ordine di priorità)
    const troopOrder = ['fanteria', 'cavalleria', 'arceri', 'balliste'];
    let chosenTroop  = null;
    let chosenAmount = 0;

    for (let i = 0; i < troopOrder.length; i++) {
        const type   = troopOrder[i];
        const el     = document.getElementById('troop-' + type);
        const amount = el ? parseInt(el.textContent.replace(/\D/g, '')) || 0 : 0;

        if (amount > 0) {
            chosenTroop  = type;
            chosenAmount = amount;
            el.textContent = '0';   // aggiornamento ottimistico nell'UI
            break;
        }
    }

    if (!chosenTroop) {
        alert('Non ci sono soldati disponibili.');
        return;
    }

    startMarch(currentClickedTile, chosenAmount, chosenTroop);
    closeTilePanel();
});

// Click sul canvas — apre il pannello della tile cliccata
canvas.addEventListener('click', function(e) {
    if (tilePanelOpen) {
        closeTilePanel();
        return;
    }

    const rect = canvas.getBoundingClientRect();
    const tile = getTileAt(e.clientX - rect.left, e.clientY - rect.top);

    if (tile) {
        currentClickedTile = tile;
        console.log('[Click] (' + tile.mapRow + ', ' + tile.mapCol + ') →', tile.fullData);
        openTilePanel(tile);
    }
});


// ════════════════════════════════════════════════════
//  GAME LOOP
// ════════════════════════════════════════════════════

function gameLoop() {
    const moved = updateCamera();

    // Ridisegna solo se qualcosa è cambiato (ottimizzazione prestazioni)
    if (moved || activeMarches.length > 0) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawDiamondGrid();
        drawMarchLines();

        // Se ci sono marce attive E la camera si è mossa,
        // risincronizza i div HTML con le nuove coordinate
        if (moved && activeMarches.length > 0) {
            syncMarchIndicators();
        }
    }

    requestAnimationFrame(gameLoop);
}


// ════════════════════════════════════════════════════
//  AVVIO — carica tutto in parallelo, poi parte il gioco
// ════════════════════════════════════════════════════

Promise.all([loadTiles(), loadMap(), loadPlayerUI()]).then(async function() {
    // Centra la visuale sul castello del giocatore
    centerCameraOnCastle();

    // loadMarches deve aspettare che la mappa sia caricata
    // perché usa MAP_ROWS/MAP_COLS per convertire le coordinate
    await loadMarches();

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawDiamondGrid();
    drawMarchLines();
    gameLoop();

    // Avvia il controllo periodico aggiornamenti mappa
    checkMapVersion();
    setInterval(checkMapVersion, MAP_POLL_INTERVAL);
});

// Ridisegna il canvas quando la finestra cambia dimensione
let resizeTimer;
window.addEventListener('resize', function() {
    clearTimeout(resizeTimer);
    // Aspetta 120ms prima di ridisegnare — evita chiamate continue durante il resize
    resizeTimer = setTimeout(function() {
        resizeCanvas();
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawDiamondGrid();
    }, 120);
});


// ════════════════════════════════════════════════════
//  SERVER DATA UTENTE
// ════════════════════════════════════════════════════

async function initServerData(userId) {
    try {
        const res = await apiFetch('/api/users/' + userId);
        console.log('[Server] Utente caricato:', res.data.name);
    } catch (err) {
        console.warn('[Server] Dati non disponibili:', err.message);
    }
}

// Costo di una singola truppa reclutata (1 di ogni risorsa)
const TROOP_COST = { grano: -1, legno: -1, pietra: -1, minerali: -1 };

// Mappa da numero tasto a tipo truppa
const TROOP_ID_MAP = {
    1: 'fanteria',
    2: 'cavalleria',
    3: 'arceri',
    4: 'balliste',
};

// Variabili per il reclutamento continuo (tasto tenuto premuto)
let recruitInterval = null;
let recruitTimeout  = null;

// Avvia il reclutamento: esegue subito una volta, poi ripete
// ogni 150ms dopo un ritardo iniziale di 300ms (comportamento "hold to repeat")
function startRecruiting(numTipo) {
    recluta(numTipo);

    recruitTimeout = setTimeout(function() {
        recruitInterval = setInterval(function() { recluta(numTipo); }, 150);
    }, 300);
}

function stopRecruiting() {
    clearTimeout(recruitTimeout);
    clearInterval(recruitInterval);
    recruitTimeout  = null;
    recruitInterval = null;
}

// Recluta una singola truppa:
// 1. Legge le risorse attuali dal server
// 2. Controlla che ci siano risorse sufficienti
// 3. Sottrae 1 a ogni risorsa
// 4. Aggiunge 1 alla truppa scelta
// 5. Aggiorna l'UI
async function recluta(numTipo) {
    const userId    = sessionStorage.getItem('userId');
    const troopType = TROOP_ID_MAP[numTipo];

    if (!troopType) {
        console.warn('[Recluta] Tipo non valido:', numTipo);
        return;
    }

    // 1. Legge le risorse attuali
    let res;
    try {
        const r = await apiFetch('/api/resources/' + userId);
        res = r.data;
    } catch (err) {
        alert('Errore lettura risorse: ' + err.message);
        return;
    }

    // 2. Controlla che tutte e 4 le risorse siano >= 1
    const mancanti = [];
    if (res.grano    < 1) mancanti.push('Grano');
    if (res.legno    < 1) mancanti.push('Legno');
    if (res.pietra   < 1) mancanti.push('Pietra');
    if (res.minerali < 1) mancanti.push('Minerali');

    if (mancanti.length > 0) {
        alert('Risorse insufficienti: ' + mancanti.join(', '));
        return;
    }

    // 3. Sottrae 1 a ogni risorsa
    try {
        await apiFetch('/api/resources/' + userId + '/add', {
            method: 'PATCH',
            body: JSON.stringify(TROOP_COST),
        });
    } catch (err) {
        alert('Errore aggiornamento risorse: ' + err.message);
        return;
    }

    // 4. Aggiunge 1 alla truppa selezionata
    try {
        const troopsRes = await apiFetch('/api/troops/' + userId);
        const current   = troopsRes.data;

        // Costruisce l'oggetto aggiornato senza usare lo spread operator
        const updated = Object.assign({}, current);
        updated[troopType] = (current[troopType] !== undefined ? current[troopType] : 0) + 1;

        await apiFetch('/api/troops/' + userId, {
            method: 'PUT',
            body: JSON.stringify(updated),
        });
    } catch (err) {
        alert('Errore aggiornamento truppe: ' + err.message);
        return;
    }

    // 5. Aggiorna tutta l'UI
    await loadPlayerUI();

    console.log('[Recluta] +1 ' + troopType + ' — costo: 1 grano, 1 legno, 1 pietra, 1 minerali');
}


// ════════════════════════════════════════════════════
//  BOTTONE ATTACCA — castello nemico
// ════════════════════════════════════════════════════

const tilePanelAttackBtn = document.getElementById('tile-panel-attack-btn');

tilePanelAttackBtn.addEventListener('click', function() {
    if (!currentClickedTile) return;

    const userId  = sessionStorage.getItem('userId');
    const ownerId = currentClickedTile.fullData !== undefined && currentClickedTile.fullData !== null
        ? currentClickedTile.fullData.ownerId
        : undefined;

    if (!ownerId) {
        alert('Castello senza proprietario.');
        return;
    }
    if (ownerId === userId) {
        alert('Non puoi attaccare te stesso.');
        return;
    }

    // Cerca la prima tipologia di truppe disponibile
    const troopOrder = ['fanteria', 'cavalleria', 'arceri', 'balliste'];
    let chosenTroop  = null;
    let chosenAmount = 0;

    for (let i = 0; i < troopOrder.length; i++) {
        const type   = troopOrder[i];
        const el     = document.getElementById('troop-' + type);
        const amount = el ? parseInt(el.textContent.replace(/\D/g, '')) || 0 : 0;

        if (amount > 0) {
            chosenTroop  = type;
            chosenAmount = amount;
            break;
        }
    }

    if (!chosenTroop) {
        alert('Non hai soldati disponibili.');
        return;
    }

    closeTilePanel();

    // Il comportamento "nemico" è determinato da tileKey === 'enemyplayer'
    // all'interno di startMarch — non serve un ramo separato
    startMarch(currentClickedTile, chosenAmount, chosenTroop);
});