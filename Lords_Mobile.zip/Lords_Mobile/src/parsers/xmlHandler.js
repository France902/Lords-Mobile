/**
 * ============================================================
 *  src/parsers/xmlHandler.js
 *  Gestione log di battaglia — formato XML
 * ============================================================
 *
 *  Ogni battaglia ha un file XML dedicato in:
 *    data/output/battle_<battleId>.xml
 *
 *  Struttura XML generata:
 *
 *    <?xml version="1.0" encoding="UTF-8"?>
 *    <battle id="bat_a1b2c3d4" date="2025-04-01T12:00:00.000Z">
 *
 *      <attacker id="usr_drago01" name="Drago">
 *        <troops>5000</troops>
 *        <losses>1200</losses>
 *      </attacker>
 *
 *      <defender id="usr_phoenix" name="Phoenix">
 *        <troops>3000</troops>
 *        <losses>3000</losses>
 *      </defender>
 *
 *      <result>
 *        <winner>attacker</winner>
 *        <loot>
 *          <grano>2000</grano>
 *          <legno>1000</legno>
 *          <pietra>0</pietra>
 *          <minerali>0</minerali>
 *        </loot>
 *      </result>
 *
 *    </battle>
 * ============================================================
 */

const fs     = require('fs').promises;
const path   = require('path');
const crypto = require('crypto');

// Cartella dove vengono scritti i file XML delle battaglie
const OUTPUT_DIR = path.join(__dirname, '../../data/output');


// ─────────────────────────────────────────────────────────────
//  Funzioni di utilità interne — costruzione XML
// ─────────────────────────────────────────────────────────────

// Restituisce il percorso del file XML di una battaglia
function getFilePath(battleId) {
    return path.join(OUTPUT_DIR, 'battle_' + battleId + '.xml');
}

// Costruisce la stringa XML completa di una battaglia.
// I valori mancanti vengono sostituiti con valori di default sicuri (0 o stringa vuota).
function buildXML(battleId, date, data) {

    // Se il bottino non è stato specificato, usa tutti zeri
    const loot = data.loot !== undefined ? data.loot : { oro: 0, grano: 0, legno: 0, pietra: 0, minerali: 0 };

    // Valori con fallback espliciti per ogni campo
    const attackerName   = data.attackerName   !== undefined ? data.attackerName   : '';
    const attackerTroops = data.attackerTroops !== undefined ? data.attackerTroops : 0;
    const attackerLosses = data.attackerLosses !== undefined ? data.attackerLosses : 0;
    const defenderName   = data.defenderName   !== undefined ? data.defenderName   : '';
    const defenderTroops = data.defenderTroops !== undefined ? data.defenderTroops : 0;
    const defenderLosses = data.defenderLosses !== undefined ? data.defenderLosses : 0;
    const lootGrano      = loot.grano          !== undefined ? loot.grano          : 0;
    const lootLegno      = loot.legno          !== undefined ? loot.legno          : 0;
    const lootPietra     = loot.pietra         !== undefined ? loot.pietra         : 0;
    const lootMinerali   = loot.minerali       !== undefined ? loot.minerali       : 0;

    // Costruisce il testo XML riga per riga.
    // Ogni livello di indentazione usa 2 spazi per leggibilità del file su disco.
    const lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<battle id="' + battleId + '" date="' + date + '">',
        '',
        '  <attacker id="' + data.attackerId + '" name="' + attackerName + '">',
        '    <troops>' + attackerTroops + '</troops>',
        '    <losses>' + attackerLosses + '</losses>',
        '  </attacker>',
        '',
        '  <defender id="' + data.defenderId + '" name="' + defenderName + '">',
        '    <troops>' + defenderTroops + '</troops>',
        '    <losses>' + defenderLosses + '</losses>',
        '  </defender>',
        '',
        '  <result>',
        '    <winner>' + data.winner + '</winner>',
        '    <loot>',
        '      <grano>'    + lootGrano    + '</grano>',
        '      <legno>'    + lootLegno    + '</legno>',
        '      <pietra>'   + lootPietra   + '</pietra>',
        '      <minerali>' + lootMinerali + '</minerali>',
        '    </loot>',
        '  </result>',
        '',
        '</battle>',
    ];

    return lines.join('\n');
}


// ─────────────────────────────────────────────────────────────
//  Funzioni di utilità interne — lettura XML (parsing)
//
//  Il parsing viene fatto manualmente con regex perché non
//  si vogliono dipendenze esterne. Le tre funzioni qui sotto
//  lavorano insieme: extractBlock isola una sezione del file,
//  extractTag e extractAttr leggono i singoli valori al suo interno.
// ─────────────────────────────────────────────────────────────


// ── extractBlock ──────────────────────────────────────────────
//  Isola una sezione del file XML, dal tag di apertura
//  fino al corrispondente tag di chiusura (contenuto incluso).
//
//  Perché serve: i tag <attacker> e <defender> contengono
//  entrambi un tag <troops> e un tag <losses>. Senza isolare
//  prima il blocco, non sapremmo a quale combattente appartiene
//  il valore che stiamo leggendo.
//
//  Esempio — dato questo XML:
//    <attacker id="usr_a" name="Drago">
//      <troops>5000</troops>
//      <losses>1200</losses>
//    </attacker>
//    <defender id="usr_b" name="Phoenix">
//      <troops>3000</troops>      ← stesso tag, valore diverso!
//      <losses>3000</losses>
//    </defender>
//
//  extractBlock(xml, 'attacker') restituisce solo il blocco attaccante,
//  poi extractTag su quel testo legge 5000 e non 3000.
//
//  Come funziona la regex:
//    <attacker   → cerca il tag di apertura con quel nome
//    [^>]*       → salta eventuali attributi (es. id="..." name="...")
//    >           → fine del tag di apertura
//    [\s\S]*?    → cattura tutto quello che c'è dentro
//                  (\s = spazi/a capo, \S = caratteri normali, *? = il minimo possibile)
//    <\/attacker> → si ferma al primo tag di chiusura corrispondente
//
//  Se il tag non viene trovato restituisce '' così il chiamante non va in crash.

function extractBlock(xml, tagName) {
    const pattern = new RegExp('<' + tagName + '[^>]*>[\\s\\S]*?<\\/' + tagName + '>');
    const match   = xml.match(pattern);
    return match ? match[0] : '';
}


// ── extractTag ────────────────────────────────────────────────
//  Legge il valore testuale dentro un tag semplice.
//
//  Esempio:
//    extractTag('<troops>5000</troops>', 'troops')      →  "5000"
//    extractTag('<winner>attacker</winner>', 'winner')  →  "attacker"
//
//  Come funziona la regex:
//    <troops   → nome del tag (passato come parametro)
//    [^>]*     → salta eventuali attributi sul tag di apertura
//    >         → fine del tag di apertura
//    ([^<]*)   → cattura tutto fino al primo '<' — cioè il valore
//                le parentesi () creano il "gruppo di cattura"
//    <\/troops> → tag di chiusura
//
//  match[1] è il gruppo catturato (il valore tra le parentesi tonde).
//  Se il tag non esiste restituisce '' per evitare crash.

function extractTag(xml, tagName) {
    const pattern = new RegExp('<' + tagName + '[^>]*>([^<]*)<\\/' + tagName + '>');
    const match   = xml.match(pattern);
    return match ? match[1].trim() : '';
}


// ── extractAttr ───────────────────────────────────────────────
//  Legge il valore di un attributo dentro il tag di apertura.
//
//  Esempio:
//    extractAttr('<attacker id="usr_a" name="Drago">', 'attacker', 'id')
//    → "usr_a"
//
//  Come funziona la regex:
//    <attacker   → nome del tag
//    [^>]*       → salta altri attributi che vengono prima di quello cercato
//    id=         → nome dell'attributo cercato (passato come parametro)
//    "([^"]*)"   → cattura il valore tra virgolette
//                  [^"]* = qualsiasi carattere tranne una virgoletta
//    [^>]*>      → salta il resto del tag di apertura
//
//  match[1] è il valore dell'attributo.
//  Se l'attributo non esiste restituisce '' per evitare crash.

function extractAttr(xml, tagName, attrName) {
    const pattern = new RegExp('<' + tagName + '[^>]*' + attrName + '="([^"]*)"[^>]*>');
    const match   = xml.match(pattern);
    return match ? match[1] : '';
}


// ── parseXML ──────────────────────────────────────────────────
//  Converte l'intero contenuto di un file XML in un oggetto JS.
//  Usato da readBattleLog (legge un singolo file) e
//  da getBattlesByUser (scansiona tutti i file).
//
//  Strategia in tre passi:
//    1. Isola i blocchi <attacker>, <defender> e <loot>
//       così le letture successive non si confondono tra sezioni
//    2. Legge gli attributi del tag radice <battle> (id e date)
//    3. Legge i valori dei sotto-tag dentro ogni blocco isolato

function parseXML(xml) {

    // Passo 1 — isola le tre sezioni principali del file
    const attackerBlock = extractBlock(xml, 'attacker');
    const defenderBlock = extractBlock(xml, 'defender');
    const lootBlock     = extractBlock(xml, 'loot');

    // Passo 2 & 3 — leggi tutti i valori e costruisci l'oggetto risultato
    const result = {

        // Attributi del tag radice: <battle id="..." date="...">
        id:   extractAttr(xml, 'battle', 'id'),
        date: extractAttr(xml, 'battle', 'date'),

        // Dati dell'attaccante — letti SOLO dentro attackerBlock
        attacker: {
            id:     extractAttr(attackerBlock, 'attacker', 'id'),
            name:   extractAttr(attackerBlock, 'attacker', 'name'),
            troops: Number(extractTag(attackerBlock, 'troops')),
            losses: Number(extractTag(attackerBlock, 'losses')),
        },

        // Dati del difensore — letti SOLO dentro defenderBlock
        // (ha gli stessi sotto-tag dell'attaccante, per questo isolare i blocchi è fondamentale)
        defender: {
            id:     extractAttr(defenderBlock, 'defender', 'id'),
            name:   extractAttr(defenderBlock, 'defender', 'name'),
            troops: Number(extractTag(defenderBlock, 'troops')),
            losses: Number(extractTag(defenderBlock, 'losses')),
        },

        // Risultato della battaglia
        result: {
            winner: extractTag(xml, 'winner'),

            // Bottino letto dentro lootBlock (evita conflitti con tag numerici identici)
            loot: {
                grano:    Number(extractTag(lootBlock, 'grano')),
                legno:    Number(extractTag(lootBlock, 'legno')),
                pietra:   Number(extractTag(lootBlock, 'pietra')),
                minerali: Number(extractTag(lootBlock, 'minerali')),
            },
        },
    };

    return result;
}


// ─────────────────────────────────────────────────────────────
//  readBattleLog
//  Legge il file XML di una battaglia e lo restituisce come oggetto.
//
//  Chiamato da:  GET /api/battles/:battleId  (in server.js)
//  Argomenti:    battleId — es. "bat_a1b2c3d4"
//  Ritorna:      oggetto battaglia strutturato
// ─────────────────────────────────────────────────────────────

async function readBattleLog(battleId) {
    try {
        const xmlContent = await fs.readFile(getFilePath(battleId), 'utf-8');
        return parseXML(xmlContent);

    } catch (err) {
        throw new Error('Battaglia "' + battleId + '" non trovata.');
    }
}


// ─────────────────────────────────────────────────────────────
//  saveBattleLog
//  Costruisce e salva il file XML di una nuova battaglia.
//  Genera automaticamente un battleId se non fornito.
//
//  Chiamato da:  POST /api/battles  (in server.js)
//
//  Argomenti:    data — oggetto con:
//    attackerId     : id dell'attaccante          (obbligatorio)
//    attackerName   : nome dell'attaccante
//    attackerTroops : truppe iniziali attaccante
//    attackerLosses : perdite subite attaccante
//    defenderId     : id del difensore            (obbligatorio)
//    defenderName   : nome del difensore
//    defenderTroops : truppe iniziali difensore
//    defenderLosses : perdite subite difensore
//    winner         : "attacker" o "defender"     (obbligatorio)
//    loot           : { grano, legno, pietra, minerali }
//
//  Ritorna:  l'oggetto battaglia appena salvato (via parseXML)
// ─────────────────────────────────────────────────────────────

async function saveBattleLog(data) {

    // Valida i campi senza i quali il log non avrebbe senso
    if (!data.attackerId) throw new Error('Campo obbligatorio mancante: attackerId.');
    if (!data.defenderId) throw new Error('Campo obbligatorio mancante: defenderId.');
    if (!data.winner)     throw new Error('Campo obbligatorio mancante: winner.');

    // Usa il battleId fornito; se mancante ne genera uno casuale
    let battleId;
    if (data.battleId !== undefined) {
        battleId = data.battleId;
    } else {
        battleId = 'bat_' + crypto.randomBytes(4).toString('hex');
    }

    const date       = new Date().toISOString();
    const xmlContent = buildXML(battleId, date, data);

    await fs.writeFile(getFilePath(battleId), xmlContent, 'utf-8');

    // Parsiamo l'XML appena scritto così il formato di ritorno è sempre coerente
    return parseXML(xmlContent);
}


// ─────────────────────────────────────────────────────────────
//  getBattlesByUser
//  Scansiona tutti i file XML nella cartella output e
//  restituisce quelli che coinvolgono l'utente indicato
//  (sia come attaccante che come difensore).
//  I risultati sono ordinati dal più recente al più vecchio.
//
//  Chiamato da:  GET /api/battles/user/:userId  (in server.js)
//  Argomenti:    userId
//  Ritorna:      array di oggetti battaglia
// ─────────────────────────────────────────────────────────────

async function getBattlesByUser(userId) {

    let allFiles;
    try {
        allFiles = await fs.readdir(OUTPUT_DIR);
    } catch (err) {
        throw new Error('Cartella output non trovata.');
    }

    // Filtra solo i file che seguono il pattern battle_*.xml
    const battleFiles = [];
    for (let i = 0; i < allFiles.length; i++) {
        const fileName = allFiles[i];
        if (fileName.startsWith('battle_') && fileName.endsWith('.xml')) {
            battleFiles.push(fileName);
        }
    }

    const userBattles = [];

    for (let i = 0; i < battleFiles.length; i++) {
        const fileName = battleFiles[i];

        try {
            const xmlContent = await fs.readFile(path.join(OUTPUT_DIR, fileName), 'utf-8');
            const battle     = parseXML(xmlContent);

            // Aggiunge la battaglia all'array solo se riguarda questo utente
            const userIsAttacker = battle.attacker.id === userId;
            const userIsDefender = battle.defender.id === userId;

            if (userIsAttacker || userIsDefender) {
                userBattles.push(battle);
            }

        } catch (err) {
            // File corrotto o illeggibile: lo ignoriamo e continuiamo
        }
    }

    // Ordina per data decrescente (battaglia più recente prima)
    userBattles.sort(function(a, b) {
        return new Date(b.date) - new Date(a.date);
    });

    return userBattles;
}


// ─────────────────────────────────────────────────────────────
//  deleteBattleLog
//  Elimina il file XML di una battaglia dal disco.
//
//  Chiamato da:  DELETE /api/battles/:battleId  (in server.js)
//  Argomenti:    battleId
//  Ritorna:      void
// ─────────────────────────────────────────────────────────────

async function deleteBattleLog(battleId) {
    try {
        await fs.unlink(getFilePath(battleId));

    } catch (err) {
        throw new Error('Battaglia "' + battleId + '" non trovata.');
    }
}


// ─────────────────────────────────────────────────────────────
//  MARCE ATTIVE — marceAttive-<userId>.xml
//  Struttura: un file per utente con tutte le marce in corso.
//  Viene creato all'inizio di ogni marcia e aggiornato alla fine.
// ─────────────────────────────────────────────────────────────

function getMarchFilePath(userId) {
    return path.join(OUTPUT_DIR, 'marceAttive-' + userId + '.xml');
}

// Legge il valore di un attributo da una stringa di attributi già estratta.
// Diverso da extractAttr: qui non c'è un intero documento XML, solo la parte
// degli attributi di un singolo tag (es. 'id="m1" troops="100"').
//
// Esempio:
//   extractLocalAttr('id="m1" troops="100"', 'troops')  →  "100"
function extractLocalAttr(attrString, name) {
    const pattern = new RegExp(name + '="([^"]*)"');
    const match   = attrString.match(pattern);
    return match ? match[1] : '';
}

// Costruisce l'XML completo del file marce di un utente.
// Ogni marcia diventa un tag <marcia> con attributi e due sotto-tag.
function buildMarchesXML(userId, marches) {

    // Costruisce una riga XML per ogni marcia
    const marchLines = [];

    for (let i = 0; i < marches.length; i++) {
        const m = marches[i];

        const gatherDuration = m.gatherDuration !== undefined ? m.gatherDuration : 10;

        const line =
            '  <marcia id="' + m.marchId + '"' +
            ' startTime="'       + m.startTime       + '"' +
            ' durationSeconds="' + m.durationSeconds + '"' +
            ' gatherDuration="'  + gatherDuration    + '"' +
            ' troopType="'       + m.troopType       + '"' +
            ' troops="'          + m.troops          + '">\n' +
            '    <partenza row="'     + m.castleRow + '" col="' + m.castleCol + '"/>\n' +
            '    <destinazione row="' + m.targetRow + '" col="' + m.targetCol + '"/>\n' +
            '  </marcia>';

        marchLines.push(line);
    }

    const inner = marchLines.join('\n');

    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
           '<marceAttive userId="' + userId + '">\n' +
           inner + '\n' +
           '</marceAttive>';
}

// Legge tutte le marce attive di un utente dal file XML.
// Se il file non esiste restituisce un array vuoto (nessuna marcia in corso).
async function readMarchLogs(userId) {
    try {
        const content = await fs.readFile(getMarchFilePath(userId), 'utf-8');
        const marches = [];

        // Regex che trova ogni blocco <marcia ...>...</marcia>
        // Il flag 'g' significa "trova TUTTE le occorrenze, non solo la prima"
        const pattern = /<marcia([^>]*)>([\s\S]*?)<\/marcia>/g;
        let match;

        // .exec() con flag 'g' avanza ogni volta al match successivo
        // e restituisce null quando non ne trova altri
        while ((match = pattern.exec(content)) !== null) {
            const attrs = match[1]; // tutto quello che è dentro il tag <marcia ...>
            const inner = match[2]; // tutto quello che è tra <marcia> e </marcia>

            // Legge le coordinate di partenza e destinazione dai sotto-tag
            const partenza = inner.match(/<partenza row="([^"]*)" col="([^"]*)"/);
            const dest     = inner.match(/<destinazione row="([^"]*)" col="([^"]*)"/);

            // Legge gatherDuration con fallback a 10 se non presente
            const gatherDurationRaw = extractLocalAttr(attrs, 'gatherDuration');
            const gatherDuration    = gatherDurationRaw !== '' ? Number(gatherDurationRaw) : 10;

            marches.push({
                marchId:         extractLocalAttr(attrs, 'id'),
                userId:          userId,
                startTime:       Number(extractLocalAttr(attrs, 'startTime')),
                durationSeconds: Number(extractLocalAttr(attrs, 'durationSeconds')),
                gatherDuration:  gatherDuration,
                troopType:       extractLocalAttr(attrs, 'troopType'),
                troops:          Number(extractLocalAttr(attrs, 'troops')),
                castleRow:       partenza !== null ? Number(partenza[1]) : 0,
                castleCol:       partenza !== null ? Number(partenza[2]) : 0,
                targetRow:       dest     !== null ? Number(dest[1])     : 0,
                targetCol:       dest     !== null ? Number(dest[2])     : 0,
            });
        }

        return marches;

    } catch (err) {
        // File non trovato = nessuna marcia attiva
        return [];
    }
}

// Salva o aggiorna una singola marcia nel file dell'utente.
// Se la marcia esiste già (stesso marchId) viene sovrascritta, altrimenti aggiunta.
async function saveMarchLog(userId, marchData) {
    const existing = await readMarchLogs(userId);

    // Cerca se la marcia esiste già
    let found = false;
    for (let i = 0; i < existing.length; i++) {
        if (existing[i].marchId === marchData.marchId) {
            existing[i] = marchData;
            found = true;
            break;
        }
    }

    // Se non esisteva, la aggiunge in fondo
    if (!found) {
        existing.push(marchData);
    }

    await fs.writeFile(getMarchFilePath(userId), buildMarchesXML(userId, existing), 'utf-8');
}

// Elimina una marcia dal file dell'utente e restituisce i dati della marcia rimossa.
// I dati servono al chiamante per sapere quante truppe restituire al castello.
// Se tutte le marce sono finite, elimina il file.
async function deleteMarchLog(userId, marchId) {
    const existing = await readMarchLogs(userId);

    // Trova la marcia da eliminare per poterne restituire i dati
    let marchToDelete = null;
    for (let i = 0; i < existing.length; i++) {
        if (existing[i].marchId === marchId) {
            marchToDelete = existing[i];
            break;
        }
    }

    // Ricostruisce l'array senza la marcia eliminata
    const remaining = [];
    for (let i = 0; i < existing.length; i++) {
        if (existing[i].marchId !== marchId) {
            remaining.push(existing[i]);
        }
    }

    if (remaining.length === 0) {
        // Nessuna marcia rimasta: elimina il file
        try {
            await fs.unlink(getMarchFilePath(userId));
        } catch (err) {
            // Se il file non esiste va bene ugualmente
        }
    } else {
        await fs.writeFile(getMarchFilePath(userId), buildMarchesXML(userId, remaining), 'utf-8');
    }

    // Restituisce i dati della marcia eliminata (o null se non trovata)
    return marchToDelete;
}


module.exports = {
    readBattleLog, saveBattleLog, getBattlesByUser, deleteBattleLog,
    readMarchLogs, saveMarchLog, deleteMarchLog,
};