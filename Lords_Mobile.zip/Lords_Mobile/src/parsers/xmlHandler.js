/**
 * ============================================================
 *  src/parsers/xmlHandler.js
 *  Gestione log di battaglia — formato XML
 * ============================================================
 *
 *  Ogni battaglia ha un file XML dedicato in:
 *    data/output/battle_<battleId>.xml
 *
 *  Struttura XML generata:
 *
 *    <?xml version="1.0" encoding="UTF-8"?>
 *    <battle id="bat_a1b2c3d4" date="2025-04-01T12:00:00.000Z">
 *
 *      <attacker id="usr_drago01" name="Drago">
 *        <troops>5000</troops>
 *        <losses>1200</losses>
 *      </attacker>
 *
 *      <defender id="usr_phoenix" name="Phoenix">
 *        <troops>3000</troops>
 *        <losses>3000</losses>
 *      </defender>
 *
 *      <result>
 *        <winner>attacker</winner>
 *        <loot>
 *          <oro>5000</oro>
 *          <grano>2000</grano>
 *          <legno>1000</legno>
 *        </loot>
 *      </result>
 *
 *    </battle>
 * *
 *  Metodi esportati:
 *    readBattleLog    → usato da GET    /api/battles/:battleId
 *    saveBattleLog    → usato da POST   /api/battles
 *    getBattlesByUser → usato da GET    /api/battles/user/:userId
 *    deleteBattleLog  → usato da DELETE /api/battles/:battleId
 * ============================================================
 */

const fs     = require('fs').promises;
const path   = require('path');
const crypto = require('crypto');

// Cartella dove vengono scritti i file XML delle battaglie
const OUTPUT_DIR = path.join(__dirname, '../../data/output');


// ─────────────────────────────────────────────────────────────
//  Funzioni di utilità interne — costruzione XML
// ─────────────────────────────────────────────────────────────

// Restituisce il percorso del file XML di una battaglia
function getFilePath(battleId) {
    return path.join(OUTPUT_DIR, `battle_${battleId}.xml`);
}

// Crea un tag XML con contenuto e attributi opzionali
// Esempio: xmlTag('oro', 5000)           → "<oro>5000</oro>"
// Esempio: xmlTag('attacker', '...', { id: 'x' }) → "<attacker id="x">...</attacker>"
function xmlTag(tagName, content, attributes = {}) {

    const attrString = Object.entries(attributes)
        .map(([key, value]) => ` ${key}="${value}"`)
        .join('');

    return `<${tagName}${attrString}>${content}</${tagName}>`;
}

// Costruisce la stringa XML completa di una battaglia
function buildXML(battleId, date, data) {

    const loot = data.loot ?? { oro: 0, grano: 0, legno: 0 };

    // Ogni livello di indentazione è 2 spazi per leggibilità del file su disco
    return [
        '<?xml version="1.0" encoding="UTF-8"?>',
        `<battle id="${battleId}" date="${date}">`,
        ``,
        `  <attacker id="${data.attackerId}" name="${data.attackerName ?? ''}">`,
        `    ${xmlTag('troops', data.attackerTroops ?? 0)}`,
        `    ${xmlTag('losses', data.attackerLosses ?? 0)}`,
        `  </attacker>`,
        ``,
        `  <defender id="${data.defenderId}" name="${data.defenderName ?? ''}">`,
        `    ${xmlTag('troops', data.defenderTroops ?? 0)}`,
        `    ${xmlTag('losses', data.defenderLosses ?? 0)}`,
        `  </defender>`,
        ``,
        `  <result>`,
        `    ${xmlTag('winner', data.winner)}`,
        `    <loot>`,
        `      ${xmlTag('oro',   loot.oro   ?? 0)}`,
        `      ${xmlTag('grano', loot.grano ?? 0)}`,
        `      ${xmlTag('legno', loot.legno ?? 0)}`,
        `    </loot>`,
        `  </result>`,
        ``,
        `</battle>`,
    ].join('\n');
}


// ─────────────────────────────────────────────────────────────
//  Funzioni di utilità interne — lettura XML (parsing)
//
//  Il parsing viene fatto manualmente con regex perché non
//  vogliamo dipendenze esterne. Le tre funzioni qui sotto
//  lavorano insieme: extractBlock isola una sezione del file,
//  extractTag e extractAttr leggono i singoli valori al suo interno.
// ─────────────────────────────────────────────────────────────


// ── extractBlock ──────────────────────────────────────────────
//  Isola una sezione del file XML, dal tag di apertura
//  fino al corrispondente tag di chiusura (contenuto incluso).
//
//  Perché serve: i tag <attacker> e <defender> contengono
//  entrambi un tag <troops> e un tag <losses>. Senza isolare
//  prima il blocco, non sapremmo a quale combattente appartiene
//  il valore che stiamo leggendo.
//
//  Esempio — dato questo XML:
//    <attacker id="usr_a" name="Drago">
//      <troops>5000</troops>
//      <losses>1200</losses>
//    </attacker>
//    <defender id="usr_b" name="Phoenix">
//      <troops>3000</troops>      ← stessa struttura!
//      <losses>3000</losses>
//    </defender>
//
//  extractBlock(xml, 'attacker') restituisce solo:
//    "<attacker id="usr_a" name="Drago">
//       <troops>5000</troops>
//       <losses>1200</losses>
//     </attacker>"
//
//  Poi extractTag su quel sotto-testo legge 5000, non 3000.
//
//  Come funziona la regex:
//    <attacker   → cerca il tag di apertura (con quel nome)
//    [^>]*       → salta eventuali attributi  (es. id="..." name="...")
//    >           → fine del tag di apertura
//    [\s\S]*?    → cattura TUTTO quello che c'è dentro
//                  (\s = spazi/newline, \S = caratteri normali, *? = minimo possibile)
//    <\/attacker> → si ferma al primo tag di chiusura corrispondente
//
//  Se il tag non esiste restituisce '' così il chiamante non va in crash.

function extractBlock(xml, tagName) {
    const pattern = new RegExp(`<${tagName}[^>]*>[\\s\\S]*?<\\/${tagName}>`);
    const match   = xml.match(pattern);
    return match ? match[0] : '';
}


// ── extractTag ────────────────────────────────────────────────
//  Legge il valore testuale dentro un tag semplice.
//
//  Esempio:
//    extractTag('<troops>5000</troops>', 'troops')  →  "5000"
//    extractTag('<winner>attacker</winner>', 'winner')  →  "attacker"
//
//  Come funziona la regex:
//    <troops   → nome del tag (passato come parametro)
//    [^>]*     → salta eventuali attributi sul tag di apertura
//    >         → fine del tag di apertura
//    ([^<]*)   → cattura tutto fino al primo '<' (cioè il valore)
//                le parentesi tonde () creano il "gruppo di cattura"
//    <\/troops> → tag di chiusura
//
//  match[1] è il gruppo catturato (il valore dentro le parentesi tonde).
//  Se il tag non esiste restituisce '' per evitare crash.

function extractTag(xml, tagName) {
    const pattern = new RegExp(`<${tagName}[^>]*>([^<]*)<\\/${tagName}>`);
    const match   = xml.match(pattern);
    return match ? match[1].trim() : '';
}


// ── extractAttr ───────────────────────────────────────────────
//  Legge il valore di un attributo dentro il tag di apertura.
//
//  Esempio:
//    extractAttr('<attacker id="usr_a" name="Drago">', 'attacker', 'id')
//    → "usr_a"
//
//  Come funziona la regex:
//    <attacker   → nome del tag
//    [^>]*       → salta altri attributi che vengono prima di quello cercato
//    id=         → nome dell'attributo cercato (passato come parametro)
//    "([^"]*)"   → cattura il valore tra virgolette
//                  [^"]* = qualsiasi carattere tranne una virgoletta
//    [^>]*>      → salta il resto del tag di apertura
//
//  match[1] è il valore dell'attributo.
//  Se l'attributo non esiste restituisce '' per evitare crash.

function extractAttr(xml, tagName, attrName) {
    const pattern = new RegExp(`<${tagName}[^>]*${attrName}="([^"]*)"[^>]*>`);
    const match   = xml.match(pattern);
    return match ? match[1] : '';
}


// ── parseXML ──────────────────────────────────────────────────
//  Converte l'intero contenuto di un file XML in un oggetto JS.
//  Usato da readBattleLog (legge un singolo file) e
//  da getBattlesByUser (scansiona tutti i file).
//
//  Strategia in tre passi:
//    1. Isola i blocchi <attacker>, <defender> e <loot>
//       così le letture successive non si confondono tra sezioni
//    2. Legge gli attributi del tag radice <battle> (id e date)
//    3. Legge i valori dei sotto-tag dentro ogni blocco isolato

function parseXML(xml) {

    // Passo 1 — isola le tre sezioni principali del file
    const attackerBlock = extractBlock(xml, 'attacker');
    const defenderBlock = extractBlock(xml, 'defender');
    const lootBlock     = extractBlock(xml, 'loot');

    // Passo 2 & 3 — leggi tutti i valori e restituisci l'oggetto
    return {

        // Attributi del tag radice: <battle id="..." date="...">
        id:   extractAttr(xml, 'battle', 'id'),
        date: extractAttr(xml, 'battle', 'date'),

        // Dati dell'attaccante — letti SOLO dentro attackerBlock
        attacker: {
            id:     extractAttr(attackerBlock, 'attacker', 'id'),
            name:   extractAttr(attackerBlock, 'attacker', 'name'),
            troops: Number(extractTag(attackerBlock, 'troops')),
            losses: Number(extractTag(attackerBlock, 'losses')),
        },

        // Dati del difensore — letti SOLO dentro defenderBlock
        // (ha gli stessi sotto-tag di attacker, per questo isolare i blocchi è fondamentale)
        defender: {
            id:     extractAttr(defenderBlock, 'defender', 'id'),
            name:   extractAttr(defenderBlock, 'defender', 'name'),
            troops: Number(extractTag(defenderBlock, 'troops')),
            losses: Number(extractTag(defenderBlock, 'losses')),
        },

        // Risultato della battaglia
        result: {
            winner: extractTag(xml, 'winner'),

            // Bottino letto dentro lootBlock (evita conflitti con altri tag numerici)
            loot: {
                oro:   Number(extractTag(lootBlock, 'oro')),
                grano: Number(extractTag(lootBlock, 'grano')),
                legno: Number(extractTag(lootBlock, 'legno')),
            },
        },
    };
}


// ─────────────────────────────────────────────────────────────
//  readBattleLog
//  Legge il file XML di una battaglia e lo restituisce come oggetto.
//
//  Chiamato da:  GET /api/battles/:battleId  (in server.js)
//  Argomenti:    battleId — es. "bat_a1b2c3d4"
//  Ritorna:      oggetto battaglia strutturato
// ─────────────────────────────────────────────────────────────

async function readBattleLog(battleId) {

    try {
        const xmlContent = await fs.readFile(getFilePath(battleId), 'utf-8');
        return parseXML(xmlContent);

    } catch {
        throw new Error(`Battaglia "${battleId}" non trovata.`);
    }
}


// ─────────────────────────────────────────────────────────────
//  saveBattleLog
//  Costruisce e salva il file XML di una nuova battaglia.
//  Genera automaticamente un battleId se non fornito.
//
//  Chiamato da:  POST /api/battles  (in server.js)
//
//  Argomenti:    data — oggetto con:
//    attackerId     : id dell'attaccante          (obbligatorio)
//    attackerName   : nome dell'attaccante
//    attackerTroops : truppe iniziali attaccante
//    attackerLosses : perdite subite attaccante
//    defenderId     : id del difensore            (obbligatorio)
//    defenderName   : nome del difensore
//    defenderTroops : truppe iniziali difensore
//    defenderLosses : perdite subite difensore
//    winner         : "attacker" o "defender"     (obbligatorio)
//    loot           : { oro, grano, legno }
//
//  Ritorna:  l'oggetto battaglia appena salvato (via parseXML)
// ─────────────────────────────────────────────────────────────

async function saveBattleLog(data) {

    // Valida i campi senza i quali il log non avrebbe senso
    if (!data.attackerId) throw new Error('Campo obbligatorio mancante: attackerId.');
    if (!data.defenderId) throw new Error('Campo obbligatorio mancante: defenderId.');
    if (!data.winner)     throw new Error('Campo obbligatorio mancante: winner.');

    // Genera un id univoco se non è stato fornito dall'esterno
    const battleId = data.battleId ?? `bat_${crypto.randomBytes(4).toString('hex')}`;
    const date     = new Date().toISOString();

    const xmlContent = buildXML(battleId, date, data);

    await fs.writeFile(getFilePath(battleId), xmlContent, 'utf-8');

    // Parsiamo l'XML appena generato così il formato di ritorno è sempre coerente
    return parseXML(xmlContent);
}


// ─────────────────────────────────────────────────────────────
//  getBattlesByUser
//  Scansiona tutti i file XML nella cartella output e
//  restituisce quelli che coinvolgono l'utente indicato
//  (sia come attaccante che come difensore).
//  I risultati sono ordinati dal più recente al più vecchio.
//
//  Chiamato da:  GET /api/battles/user/:userId  (in server.js)
//  Argomenti:    userId
//  Ritorna:      array di oggetti battaglia
// ─────────────────────────────────────────────────────────────

async function getBattlesByUser(userId) {

    let allFiles;

    try {
        allFiles = await fs.readdir(OUTPUT_DIR);
    } catch {
        throw new Error('Cartella output non trovata.');
    }

    // Filtra solo i file che seguono il pattern battle_*.xml
    const battleFiles = allFiles.filter(
        fileName => fileName.startsWith('battle_') && fileName.endsWith('.xml')
    );

    const userBattles = [];

    for (const fileName of battleFiles) {

        try {
            const xmlContent = await fs.readFile(
                path.join(OUTPUT_DIR, fileName),
                'utf-8'
            );

            const battle = parseXML(xmlContent);

            // Aggiunge la battaglia all'array solo se riguarda questo utente
            const userIsAttacker = battle.attacker.id === userId;
            const userIsDefender = battle.defender.id === userId;

            if (userIsAttacker || userIsDefender) {
                userBattles.push(battle);
            }

        } catch {
            // File corrotto o illeggibile: lo ignoriamo e continuiamo
        }
    }

    // Ordina per data decrescente (battaglia più recente prima)
    userBattles.sort((a, b) => new Date(b.date) - new Date(a.date));

    return userBattles;
}


// ─────────────────────────────────────────────────────────────
//  deleteBattleLog
//  Elimina il file XML di una battaglia dal disco.
//
//  Chiamato da:  DELETE /api/battles/:battleId  (in server.js)
//  Argomenti:    battleId
//  Ritorna:      void
// ─────────────────────────────────────────────────────────────

async function deleteBattleLog(battleId) {

    try {
        await fs.unlink(getFilePath(battleId));

    } catch {
        throw new Error(`Battaglia "${battleId}" non trovata.`);
    }
}


module.exports = { readBattleLog, saveBattleLog, getBattlesByUser, deleteBattleLog };