/**
 * ============================================================
 *  src/parsers/jsonHandler.js
 *  Gestione profili utente — formato JSON
 * ============================================================
 *
 *  Ogni utente ha un file dedicato salvato in:
 *    data/output/<userId>.json
 *
 *  Esempio di file generato:
 *  {
 *    "id":        "usr_drago01",
 *    "name":      "Drago",
 *    "level":     15,
 *    "power":     320000,
 *    "guild":     "Iron Throne",
 *    "createdAt": "2025-01-01T00:00:00.000Z",
 *    "updatedAt": "2025-04-01T12:00:00.000Z"
 *  }
 *
 *  Metodi esportati:
 *    readUser   → usato da GET    /api/users/:id
 *    createUser → usato da POST   /api/users
 *    updateUser → usato da PUT    /api/users/:id
 *    deleteUser → usato da DELETE /api/users/:id
 * ============================================================
 */

const fs   = require('fs').promises;
const path = require('path');

// Cartella dove vengono scritti i file JSON degli utenti
const OUTPUT_DIR = path.join(__dirname, '../../data/output');


// ─────────────────────────────────────────────────────────────
//  Funzione di utilità interna
//  Costruisce il percorso del file JSON dato un userId.
//  Non viene esportata: la usano solo i metodi qui sotto.
// ─────────────────────────────────────────────────────────────

function getFilePath(userId) {
    return path.join(OUTPUT_DIR, `${userId}.json`);
}


// ─────────────────────────────────────────────────────────────
//  readUser
//  Legge il file JSON di un utente e lo restituisce come oggetto.
//
//  Chiamato da:  GET /api/users/:id  (in server.js)
//  Argomenti:    userId — stringa identificativa (es. "usr_drago01")
//  Ritorna:      oggetto con i dati dell'utente
//  Errore:       se il file non esiste lancia un errore leggibile
// ─────────────────────────────────────────────────────────────

async function readUser(userId) {

    const filePath = getFilePath(userId);

    try {
        const fileContent = await fs.readFile(filePath, 'utf-8');
        return JSON.parse(fileContent);

    } catch {
        throw new Error(`Utente "${userId}" non trovato.`);
    }
}


// ─────────────────────────────────────────────────────────────
//  createUser
//  Crea un nuovo file JSON con i dati iniziali dell'utente.
//  Se il file esiste già, lancia un errore (no sovrascrittura).
//
//  Chiamato da:  POST /api/users  (in server.js)
//  Argomenti:    data — oggetto con almeno { id, name }
//  Ritorna:      l'oggetto utente appena creato
// ─────────────────────────────────────────────────────────────

async function createUser(data) {

    // Campi obbligatori: senza id e name non possiamo creare il file
    if (!data.id || !data.name) {
        throw new Error('Campi obbligatori mancanti: id e name.');
    }

    const filePath = getFilePath(data.id);

    // Controlla se l'utente esiste già prima di scrivere
    try {
        await fs.access(filePath);
        throw new Error(`Utente "${data.id}" esiste già.`);

    } catch (err) {
        // Se l'errore è "esiste già" lo rilanciamo, altrimenti
        // significa che il file non c'è e possiamo procedere
        if (err.message.includes('esiste già')) throw err;
    }

    // Costruisce l'oggetto utente con valori di default per i campi facoltativi
    const now     = new Date().toISOString();
    const newUser = {
        id:        data.id,
        name:      data.name,
        password:  data.password,
        level:     data.level ?? 1,
        power:     data.power ?? 0,
        guild:     data.guild ?? '',
        castleRow: data.castleRow ?? null,   // ← aggiunto
        castleCol: data.castleCol ?? null,   // ← aggiunto
        createdAt: now,
        updatedAt: now,
    };

    // Scrive il file con indentazione per renderlo leggibile anche a mano
    await fs.writeFile(filePath, JSON.stringify(newUser, null, 2), 'utf-8');

    return newUser;
}


// ─────────────────────────────────────────────────────────────
//  updateUser
//  Aggiorna solo i campi forniti, mantenendo gli altri invariati.
//  id e createdAt non sono mai modificabili.
//
//  Chiamato da:  PUT /api/users/:id  (in server.js)
//  Argomenti:    userId  — id dell'utente da modificare
//                updates — oggetto con solo i campi da cambiare
//                          es. { level: 20, power: 500000 }
//  Ritorna:      l'oggetto utente aggiornato
// ─────────────────────────────────────────────────────────────

async function updateUser(userId, updates) {

    // Legge i dati attuali (lancia errore se l'utente non esiste)
    const existingUser = await readUser(userId);

    // Unisce i vecchi dati con i nuovi.
    // I campi in "updates" sovrascrivono quelli in "existingUser",
    // ma id e createdAt vengono rimessi esplicitamente per sicurezza.
    const updatedUser = {
        ...existingUser,
        ...updates,
        id:        existingUser.id,
        createdAt: existingUser.createdAt,
        updatedAt: new Date().toISOString(),
    };

    await fs.writeFile(
        getFilePath(userId),
        JSON.stringify(updatedUser, null, 2),
        'utf-8'
    );

    return updatedUser;
}


// ─────────────────────────────────────────────────────────────
//  deleteUser
//  Elimina il file JSON dell'utente dal disco.
//
//  Chiamato da:  DELETE /api/users/:id  (in server.js)
//  Argomenti:    userId — id dell'utente da eliminare
//  Ritorna:      void
// ─────────────────────────────────────────────────────────────

async function deleteUser(userId) {

    try {
        await fs.unlink(getFilePath(userId));

    } catch {
        throw new Error(`Utente "${userId}" non trovato.`);
    }
}
async function findUserByName(name) {
    try {
        // Legge la lista di tutti i file nella cartella dei dati
        const files = await fs.readdir(OUTPUT_DIR);

        for (const file of files) {
            // Consideriamo solo i file .json ed escludiamo file di risorse o truppe
            if (file.endsWith('.json') && !file.includes('_resources') && !file.includes('_troops')) {
                const filePath = path.join(OUTPUT_DIR, file);
                const content = await fs.readFile(filePath, 'utf-8');
                const user = JSON.parse(content);

                // Confronto case-insensitive (opzionale, qui è esatto)
                if (user.name === name) {
                    return user;
                }
            }
        }
        return null; // Nessun utente trovato con quel nome

    } catch (err) {
        console.error("[jsonHandler] Errore durante la ricerca utente:", err);
        throw new Error("Errore durante la ricerca nel database utenti.");
    }
}

// Esporta i metodi includendo findUserByName
module.exports = { 
    readUser, 
    createUser, 
    updateUser, 
    deleteUser, 
    findUserByName 
};