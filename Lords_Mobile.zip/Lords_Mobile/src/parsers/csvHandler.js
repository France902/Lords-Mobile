/**
 * ============================================================
 *  src/parsers/csvHandler.js
 *  Gestione risorse utente — formato CSV
 * ============================================================
 *
 *  Ogni utente ha un file CSV dedicato in:
 *    data/output/<userId>_resources.csv
 *
 *  Struttura del file (intestazione fissa + 1 riga dati):
 *    userId,grano,legno,oro,pietra,minerali,timestamp
 *    usr_drago01,50000,30000,10000,20000,5000,2025-04-01T12:00:00.000Z
 *
 *  Il file contiene SEMPRE una sola riga dati.
 *  Ogni aggiornamento sovrascrive quella riga, non aggiunge righe.
 *
 * ============================================================
 */

const fs   = require('fs').promises;
const path = require('path');

// Cartella dove vengono scritti i file CSV
const OUTPUT_DIR = path.join(__dirname, '../../data/output');

// Intestazione fissa — l'ordine delle colonne NON va mai cambiato
const CSV_HEADER = 'userId,grano,legno,oro,pietra,minerali,timestamp';

// Nomi delle sole colonne "risorsa" (esclusi userId e timestamp)
// Usati nel metodo addResources per iterare sui delta
const RESOURCE_KEYS = ['grano', 'legno', 'oro', 'pietra', 'minerali'];


// ─────────────────────────────────────────────────────────────
//  Funzioni di utilità interne
//  Non vengono esportate: servono solo ai metodi pubblici.
// ─────────────────────────────────────────────────────────────

// Restituisce il percorso del file CSV delle risorse di un utente
function getFilePath(userId) {
    return path.join(OUTPUT_DIR, userId + '_resources.csv');
}

// Converte la riga dati CSV (stringa) in un oggetto JavaScript
// Esempio input:  "usr_drago01,50000,30000,10000,20000,5000,2025-..."
// Esempio output: { userId: "usr_drago01", grano: 50000, ... }
function parseRow(csvLine) {
    const parts     = csvLine.split(',');
    const userId    = parts[0];
    const grano     = Number(parts[1]);
    const legno     = Number(parts[2]);
    const oro       = Number(parts[3]);
    const pietra    = Number(parts[4]);
    const minerali  = Number(parts[5]);
    const timestamp = parts[6];

    return { userId, grano, legno, oro, pietra, minerali, timestamp };
}

// Converte un oggetto risorse in una stringa riga CSV
// Esempio input:  { userId: "usr_drago01", grano: 50000, ... }
// Esempio output: "usr_drago01,50000,30000,10000,20000,5000,2025-..."
function toRow(obj) {
    const fields = [
        obj.userId,
        obj.grano,
        obj.legno,
        obj.oro,
        obj.pietra,
        obj.minerali,
        obj.timestamp,
    ];
    return fields.join(',');
}

// Scrive (o sovrascrive) il file CSV con l'intestazione e la riga dati fornita
async function writeCSV(userId, resourceObj) {
    const content = CSV_HEADER + '\n' + toRow(resourceObj);
    await fs.writeFile(getFilePath(userId), content, 'utf-8');
}


// ─────────────────────────────────────────────────────────────
//  readResources
//  Legge il file CSV e restituisce le risorse attuali dell'utente.
//
//  Chiamato da:  GET /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//  Ritorna:      oggetto { userId, grano, legno, oro, pietra, minerali, timestamp }
// ─────────────────────────────────────────────────────────────

async function readResources(userId) {
    try {
        const fileContent = await fs.readFile(getFilePath(userId), 'utf-8');

        // Il file ha 2 righe: riga 0 = intestazione, riga 1 = dati
        const lines = fileContent.trim().split('\n');

        if (lines.length < 2) {
            throw new Error('File CSV vuoto o corrotto.');
        }

        return parseRow(lines[1]);

    } catch (err) {
        throw new Error('Risorse per "' + userId + '" non trovate.');
    }
}


// ─────────────────────────────────────────────────────────────
//  createResources
//  Crea il file CSV con le risorse di partenza dell'utente.
//  Se il file esiste già lancia un errore (no sovrascrittura).
//
//  Chiamato da:  POST /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//                data — { grano, legno, oro, pietra, minerali }
//                       i campi mancanti partono da 0
//  Ritorna:      l'oggetto risorse appena creato
// ─────────────────────────────────────────────────────────────

async function createResources(userId, data) {
    const filePath = getFilePath(userId);

    // Controlla se esiste già un file per questo utente
    try {
        await fs.access(filePath);
        // Se arriviamo qui, il file esiste già
        throw new Error('Risorse per "' + userId + '" esistono già.');
    } catch (err) {
        if (err.message.includes('esistono già')) throw err;
        // Se l'errore NON è il nostro messaggio, significa che il file
        // non esiste — possiamo procedere a crearlo
    }

    // Usa il valore fornito; se mancante, parte da 0
    const newResources = {
        userId:    userId,
        grano:     data.grano    !== undefined ? data.grano    : 0,
        legno:     data.legno    !== undefined ? data.legno    : 0,
        oro:       data.oro      !== undefined ? data.oro      : 0,
        pietra:    data.pietra   !== undefined ? data.pietra   : 0,
        minerali:  data.minerali !== undefined ? data.minerali : 0,
        timestamp: new Date().toISOString(),
    };

    await writeCSV(userId, newResources);
    return newResources;
}


// ─────────────────────────────────────────────────────────────
//  updateResources
//  Sovrascrive i valori delle risorse con quelli nuovi forniti.
//  I campi non inclusi in "data" mantengono il valore precedente.
//
//  Chiamato da:  PUT /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//                data — campi da aggiornare, es. { oro: 99999 }
//  Ritorna:      l'oggetto risorse aggiornato
// ─────────────────────────────────────────────────────────────

async function updateResources(userId, data) {
    // Legge i valori attuali (lancia errore se non esistono)
    const existing = await readResources(userId);

    // Parte dai valori esistenti e sovrascrive solo quelli presenti in "data"
    const updated = {
        userId:    userId,
        grano:     data.grano    !== undefined ? data.grano    : existing.grano,
        legno:     data.legno    !== undefined ? data.legno    : existing.legno,
        oro:       data.oro      !== undefined ? data.oro      : existing.oro,
        pietra:    data.pietra   !== undefined ? data.pietra   : existing.pietra,
        minerali:  data.minerali !== undefined ? data.minerali : existing.minerali,
        timestamp: new Date().toISOString(),
    };

    await writeCSV(userId, updated);
    return updated;
}


// ─────────────────────────────────────────────────────────────
//  addResources
//  Somma un delta alle risorse attuali.
//  Usa valori positivi per guadagni, negativi per perdite.
//  Nessuna risorsa scende sotto 0.
//
//  Chiamato da:  PATCH /api/resources/:userId/add  (in server.js)
//
//  Caso d'uso tipico — dopo una battaglia:
//    vincitore: addResources('usr_a', { oro: +5000, grano: +2000 })
//    perdente:  addResources('usr_b', { oro: -5000, grano: -2000 })
//
//  Argomenti:    userId
//                delta — es. { grano: 500, oro: -200 }
//  Ritorna:      l'oggetto risorse aggiornato
// ─────────────────────────────────────────────────────────────

async function addResources(userId, delta) {
    const existing = await readResources(userId);

    const updated = {
        userId:    userId,
        grano:     existing.grano,
        legno:     existing.legno,
        oro:       existing.oro,
        pietra:    existing.pietra,
        minerali:  existing.minerali,
        timestamp: new Date().toISOString(),
    };

    // Applica i delta: somma il valore, ma non scendere mai sotto 0
    for (let i = 0; i < RESOURCE_KEYS.length; i++) {
        const key = RESOURCE_KEYS[i];

        if (delta[key] !== undefined) {
            const newValue = existing[key] + Number(delta[key]);
            updated[key]   = newValue < 0 ? 0 : newValue;
        }
    }

    await writeCSV(userId, updated);
    return updated;
}


// ─────────────────────────────────────────────────────────────
//  MAP — mappa.csv
//  Header: row,col,src,resources,ownerId
//  Una riga per tile — solo le tile non-erba base sono obbligatorie.
//  Le tile mancanti vengono considerate grass1 di default.
// ─────────────────────────────────────────────────────────────

const MAP_FILE   = path.join(OUTPUT_DIR, 'mappa.csv');
const MAP_HEADER = 'row,col,src,resources,ownerId';

// Converte una riga CSV in un oggetto tile
function parseTileRow(line) {
    const parts     = line.split(',');
    const row       = Number(parts[0]);
    const col       = Number(parts[1]);
    const src       = parts[2] || 'grass1';
    const resources = (parts[3] !== '' && parts[3] !== undefined) ? Number(parts[3]) : null;
    const ownerId   = (parts[4] && parts[4].trim() !== '') ? parts[4].trim() : null;

    return { row, col, src, resources, ownerId };
}

// Converte un oggetto tile in una riga CSV
function toTileRow(tile) {
    const fields = [
        tile.row,
        tile.col,
        tile.src,
        tile.resources !== null && tile.resources !== undefined ? tile.resources : '',
        tile.ownerId   !== null && tile.ownerId   !== undefined ? tile.ownerId   : '',
    ];
    return fields.join(',');
}

async function readMap() {
    try {
        const content = await fs.readFile(MAP_FILE, 'utf-8');
        const lines   = content.replace(/\r/g, '').trim().split('\n');

        // lines[1] contiene i metadati nel formato "#200,200"
        // .slice(1) rimuove il carattere '#' → "200,200"
        const meta = lines[1].slice(1).split(',');
        const cols = Number(meta[0]);
        const rows = Number(meta[1]);

        if (isNaN(cols) || isNaN(rows)) {
            throw new Error('Dimensioni mappa non valide');
        }

        // Crea una griglia vuota (tutte erba di default)
        const map = [];
        for (let r = 0; r < rows; r++) {
            const row = [];
            for (let c = 0; c < cols; c++) {
                row.push({ row: r, col: c, src: 'grass1', resources: null, ownerId: null });
            }
            map.push(row);
        }

        // Sovrascrive le celle che hanno dati nel CSV (salta header e riga meta)
        for (let i = 2; i < lines.length; i++) {
            if (!lines[i].trim()) continue;
            const tile = parseTileRow(lines[i]);
            if (tile.row >= 0 && tile.row < rows && tile.col >= 0 && tile.col < cols) {
                map[tile.row][tile.col] = tile;
            }
        }

        return { cols, rows, map };

    } catch (err) {
        console.error('Errore lettura mappa:', err.message);
        return null;
    }
}

async function writeMap(cols, rows, tileMap) {
    const lines = [MAP_HEADER, '#' + cols + ',' + rows];

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            const cell = tileMap[r][c];

            // Normalizza: accetta sia stringhe che oggetti
            let tile;
            if (typeof cell === 'string') {
                tile = { row: r, col: c, src: cell, resources: null, ownerId: null };
            } else {
                tile = {
                    row:       r,
                    col:       c,
                    src:       cell.src       !== undefined ? cell.src       : 'grass1',
                    resources: cell.resources !== undefined ? cell.resources : null,
                    ownerId:   cell.ownerId   !== undefined ? cell.ownerId   : null,
                };
            }

            // Salva SOLO le tile con dati non-default.
            // Le tile erba senza dati extra vengono omesse — il reader le ricostruisce.
            const isDefaultGrass = tile.src.startsWith('grass') && tile.resources === null && tile.ownerId === null;
            if (!isDefaultGrass) {
                lines.push(toTileRow(tile));
            }
        }
    }

    await fs.writeFile(MAP_FILE, lines.join('\n'), 'utf-8');
    return { cols, rows, map: tileMap };
}

async function setMapTile(row, col, src, ownerId) {
    let content;
    try {
        content = await fs.readFile(MAP_FILE, 'utf-8');
    } catch (err) {
        throw new Error('mappa.csv non trovato.');
    }

    const lines = content.trim().split('\n');
    const meta  = lines[1].replace(/\r/g, '').trim().split('\n');
    const cols  = Number(meta[0]);
    const rows  = Number(meta[1]);

    if (row < 0 || row >= rows || col < 0 || col >= cols) {
        throw new Error('Tile (' + row + ', ' + col + ') fuori dai limiti.');
    }

    const newTile = {
        row:       row,
        col:       col,
        src:       src,
        resources: null,
        ownerId:   ownerId !== undefined ? ownerId : null,
    };
    const newRow = toTileRow(newTile);

    // Cerca se esiste già una riga per questa coordinata e la aggiorna
    let found = false;
    for (let i = 2; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const parts = lines[i].split(',');
        if (Number(parts[0]) === row && Number(parts[1]) === col) {
            lines[i] = newRow;
            found    = true;
            break;
        }
    }

    // Se non esiste, aggiunge una nuova riga alla fine
    if (!found) {
        lines.push(newRow);
    }

    await fs.writeFile(MAP_FILE, lines.join('\n'), 'utf-8');
}

async function readMapSize() {
    const content   = await fs.readFile(MAP_FILE, 'utf-8');
    const lines     = content.replace(/\r/g, '').trim().split('\n');
    const metaLine  = lines[1]; // formato: "#50,50"

    if (!metaLine || !metaLine.startsWith('#')) {
        throw new Error('Riga metadati mappa non trovata. Riga trovata: "' + metaLine + '"');
    }

    const parts = metaLine.slice(1).split(',');
    const cols  = Number(parts[0]);
    const rows  = Number(parts[1]);

    if (isNaN(cols) || isNaN(rows)) {
        throw new Error('Metadati mappa non validi: "' + metaLine + '"');
    }

    return { cols, rows };
}

async function updateMapTileResources(row, col, delta) {
    let content;
    try {
        content = await fs.readFile(MAP_FILE, 'utf-8');
    } catch (err) {
        throw new Error('mappa.csv non trovato.');
    }

    const lines = content.trim().split('\n');
    let found   = false;

    for (let i = 2; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const parts = lines[i].split(',');
        if (Number(parts[0]) === row && Number(parts[1]) === col) {
            const tile     = parseTileRow(lines[i]);
            const current  = tile.resources !== null ? tile.resources : 0;
            tile.resources = current + delta < 0 ? 0 : current + delta;
            lines[i]       = toTileRow(tile);
            found          = true;
            break;
        }
    }

    if (!found) {
        throw new Error('Tile (' + row + ', ' + col + ') non trovata o non ha risorse.');
    }

    await fs.writeFile(MAP_FILE, lines.join('\n'), 'utf-8');
}


// ─────────────────────────────────────────────────────────────
//  TRUPPE — <userId>_troops.csv
// ─────────────────────────────────────────────────────────────

const TROOP_KEYS = ['fanteria', 'cavalleria', 'arceri', 'balliste'];

function getTroopsPath(userId) {
    return path.join(OUTPUT_DIR, userId + '_troops.csv');
}

function parseTroopsRow(line) {
    const parts      = line.split(',');
    const userId     = parts[0];
    const fanteria   = Number(parts[1]);
    const cavalleria = Number(parts[2]);
    const arceri     = Number(parts[3]);
    const balliste   = Number(parts[4]);
    const timestamp  = parts[5];

    return { userId, fanteria, cavalleria, arceri, balliste, timestamp };
}

function toTroopsRow(obj) {
    const fields = [obj.userId, obj.fanteria, obj.cavalleria, obj.arceri, obj.balliste, obj.timestamp];
    return fields.join(',');
}

async function writeTroopsCSV(userId, obj) {
    const content = 'userId,fanteria,cavalleria,arceri,balliste,timestamp\n' + toTroopsRow(obj);
    await fs.writeFile(getTroopsPath(userId), content, 'utf-8');
}

async function readTroops(userId) {
    try {
        const content = await fs.readFile(getTroopsPath(userId), 'utf-8');
        const lines   = content.trim().split('\n');
        if (lines.length < 2) throw new Error('File truppe vuoto o corrotto.');
        return parseTroopsRow(lines[1]);
    } catch (err) {
        throw new Error('Truppe per "' + userId + '" non trovate.');
    }
}

async function createTroops(userId, data) {
    // data è opzionale — se non viene passato si usa un oggetto vuoto
    if (data === undefined) data = {};

    const filePath = getTroopsPath(userId);
    try {
        await fs.access(filePath);
        // Se arriviamo qui il file esiste già
        throw new Error('Truppe per "' + userId + '" esistono già.');
    } catch (err) {
        if (err.message.includes('esistono già')) throw err;
        // Altrimenti il file non esiste — possiamo crearlo
    }

    const obj = {
        userId:     userId,
        fanteria:   data.fanteria   !== undefined ? data.fanteria   : 20,
        cavalleria: data.cavalleria !== undefined ? data.cavalleria : 0,
        arceri:     data.arceri     !== undefined ? data.arceri     : 0,
        balliste:   data.balliste   !== undefined ? data.balliste   : 0,
        timestamp:  new Date().toISOString(),
    };

    await writeTroopsCSV(userId, obj);
    return obj;
}

async function updateTroops(userId, updates) {
    const existing = await readTroops(userId);

    const updated = {
        userId:     userId,
        fanteria:   updates.fanteria   !== undefined ? updates.fanteria   : existing.fanteria,
        cavalleria: updates.cavalleria !== undefined ? updates.cavalleria : existing.cavalleria,
        arceri:     updates.arceri     !== undefined ? updates.arceri     : existing.arceri,
        balliste:   updates.balliste   !== undefined ? updates.balliste   : existing.balliste,
        timestamp:  new Date().toISOString(),
    };

    await writeTroopsCSV(userId, updated);
    return updated;
}


module.exports = {
    readResources, createResources, updateResources, addResources,
    readMap, writeMap, setMapTile, readMapSize, updateMapTileResources,
    readTroops, createTroops, updateTroops,
};