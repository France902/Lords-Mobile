/**
 * ============================================================
 *  src/parsers/csvHandler.js
 *  Gestione risorse utente — formato CSV
 * ============================================================
 *
 *  Ogni utente ha un file CSV dedicato in:
 *    data/output/<userId>_resources.csv
 *
 *  Struttura del file (intestazione fissa + 1 riga dati):
 *    userId,grano,legno,oro,pietra,ferro,timestamp
 *    usr_drago01,50000,30000,10000,20000,5000,2025-04-01T12:00:00.000Z
 *
 *  Il file contiene SEMPRE una sola riga dati.
 *  Ogni aggiornamento sovrascrive quella riga, non aggiunge righe.
 *
 *  Metodi esportati:
 *    readResources   → usato da GET   /api/resources/:userId
 *    createResources → usato da POST  /api/resources/:userId
 *    updateResources → usato da PUT   /api/resources/:userId
 *    addResources    → usato da PATCH /api/resources/:userId/add
 * ============================================================
 */

const fs   = require('fs').promises;
const path = require('path');

// Cartella dove vengono scritti i file CSV
const OUTPUT_DIR = path.join(__dirname, '../../data/output');

// Intestazione fissa — l'ordine delle colonne NON va mai cambiato
const CSV_HEADER = 'userId,grano,legno,oro,pietra,ferro,timestamp';

// Nomi delle sole colonne "risorsa" (esclusi userId e timestamp)
// Usati nel metodo addResources per iterare sui delta
const RESOURCE_KEYS = ['grano', 'legno', 'oro', 'pietra', 'ferro'];


// ─────────────────────────────────────────────────────────────
//  Funzioni di utilità interne
//  Non vengono esportate: servono solo ai metodi pubblici.
// ─────────────────────────────────────────────────────────────

// Restituisce il percorso del file CSV delle risorse di un utente
function getFilePath(userId) {
    return path.join(OUTPUT_DIR, `${userId}_resources.csv`);
}

// Converte la riga dati CSV (stringa) in un oggetto JavaScript
// Esempio input:  "usr_drago01,50000,30000,10000,20000,5000,2025-..."
// Esempio output: { userId: "usr_drago01", grano: 50000, ... }
function parseRow(csvLine) {
    const [userId, grano, legno, oro, pietra, ferro, timestamp] = csvLine.split(',');

    return {
        userId,
        grano:     Number(grano),
        legno:     Number(legno),
        oro:       Number(oro),
        pietra:    Number(pietra),
        ferro:     Number(ferro),
        timestamp,
    };
}

// Converte un oggetto risorse in una stringa riga CSV
// Esempio input:  { userId: "usr_drago01", grano: 50000, ... }
// Esempio output: "usr_drago01,50000,30000,10000,20000,5000,2025-..."
function toRow(obj) {
    return [
        obj.userId,
        obj.grano,
        obj.legno,
        obj.oro,
        obj.pietra,
        obj.ferro,
        obj.timestamp,
    ].join(',');
}

// Scrive (o sovrascrive) il file CSV con l'intestazione e la riga dati fornita
async function writeCSV(userId, resourceObj) {
    const content = `${CSV_HEADER}\n${toRow(resourceObj)}`;
    await fs.writeFile(getFilePath(userId), content, 'utf-8');
}


// ─────────────────────────────────────────────────────────────
//  readResources
//  Legge il file CSV e restituisce le risorse attuali dell'utente.
//
//  Chiamato da:  GET /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//  Ritorna:      oggetto { userId, grano, legno, oro, pietra, ferro, timestamp }
// ─────────────────────────────────────────────────────────────

async function readResources(userId) {

    try {
        const fileContent = await fs.readFile(getFilePath(userId), 'utf-8');

        // Il file ha 2 righe: riga 0 = intestazione, riga 1 = dati
        const lines = fileContent.trim().split('\n');

        if (lines.length < 2) {
            throw new Error('File CSV vuoto o corrotto.');
        }

        return parseRow(lines[1]);

    } catch {
        throw new Error(`Risorse per "${userId}" non trovate.`);
    }
}


// ─────────────────────────────────────────────────────────────
//  createResources
//  Crea il file CSV con le risorse di partenza dell'utente.
//  Se il file esiste già lancia un errore (no sovrascrittura).
//
//  Chiamato da:  POST /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//                data — { grano, legno, oro, pietra, ferro }
//                       i campi mancanti partono da 0
//  Ritorna:      l'oggetto risorse appena creato
// ─────────────────────────────────────────────────────────────

async function createResources(userId, data) {

    const filePath = getFilePath(userId);

    // Controlla se esiste già un file per questo utente
    try {
        await fs.access(filePath);
        throw new Error(`Risorse per "${userId}" esistono già.`);

    } catch (err) {
        if (err.message.includes('esistono già')) throw err;
        // File non trovato → possiamo crearlo
    }

    const newResources = {
        userId,
        grano:     data.grano  ?? 0,
        legno:     data.legno  ?? 0,
        oro:       data.oro    ?? 0,
        pietra:    data.pietra ?? 0,
        ferro:     data.ferro  ?? 0,
        timestamp: new Date().toISOString(),
    };

    await writeCSV(userId, newResources);

    return newResources;
}


// ─────────────────────────────────────────────────────────────
//  updateResources
//  Sovrascrive i valori delle risorse con quelli nuovi forniti.
//  I campi non inclusi in "data" mantengono il valore precedente.
//
//  Chiamato da:  PUT /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//                data — campi da aggiornare, es. { oro: 99999 }
//  Ritorna:      l'oggetto risorse aggiornato
// ─────────────────────────────────────────────────────────────

async function updateResources(userId, data) {

    // Legge i valori attuali (lancia errore se non esistono)
    const existing = await readResources(userId);

    const updated = {
        ...existing,
        ...data,
        userId,                              // non sovrascrivibile
        timestamp: new Date().toISOString(), // aggiorna sempre il timestamp
    };

    await writeCSV(userId, updated);

    return updated;
}


// ─────────────────────────────────────────────────────────────
//  addResources
//  Somma un delta alle risorse attuali.
//  Usa valori positivi per guadagni, negativi per perdite.
//  Nessuna risorsa scende sotto 0.
//
//  Chiamato da:  PATCH /api/resources/:userId/add  (in server.js)
//
//  Caso d'uso tipico — dopo una battaglia:
//    vincitore: addResources('usr_a', { oro: +5000, grano: +2000 })
//    perdente:  addResources('usr_b', { oro: -5000, grano: -2000 })
//
//  Argomenti:    userId
//                delta — es. { grano: 500, oro: -200 }
//  Ritorna:      l'oggetto risorse aggiornato
// ─────────────────────────────────────────────────────────────

async function addResources(userId, delta) {

    const existing = await readResources(userId);

    // Crea una copia dei valori attuali e applica i delta
    const updated = {
        ...existing,
        userId,
        timestamp: new Date().toISOString(),
    };

    for (const key of RESOURCE_KEYS) {

        if (delta[key] !== undefined) {
            const newValue = existing[key] + Number(delta[key]);

            // Impedisce che le risorse diventino negative
            updated[key] = Math.max(0, newValue);
        }
    }

    await writeCSV(userId, updated);

    return updated;
}


module.exports = { readResources, createResources, updateResources, addResources };