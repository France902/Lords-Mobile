/**
 * ============================================================
 *  src/parsers/csvHandler.js
 *  Gestione risorse utente — formato CSV
 * ============================================================
 *
 *  Ogni utente ha un file CSV dedicato in:
 *    data/output/<userId>_resources.csv
 *
 *  Struttura del file (intestazione fissa + 1 riga dati):
 *    userId,grano,legno,oro,pietra,ferro,timestamp
 *    usr_drago01,50000,30000,10000,20000,5000,2025-04-01T12:00:00.000Z
 *
 *  Il file contiene SEMPRE una sola riga dati.
 *  Ogni aggiornamento sovrascrive quella riga, non aggiunge righe.
 *
 *  Metodi esportati:
 *    readResources   → usato da GET   /api/resources/:userId
 *    createResources → usato da POST  /api/resources/:userId
 *    updateResources → usato da PUT   /api/resources/:userId
 *    addResources    → usato da PATCH /api/resources/:userId/add
 * ============================================================
 */

const fs   = require('fs').promises;
const path = require('path');

// Cartella dove vengono scritti i file CSV
const OUTPUT_DIR = path.join(__dirname, '../../data/output');

// Intestazione fissa — l'ordine delle colonne NON va mai cambiato
const CSV_HEADER = 'userId,grano,legno,oro,pietra,ferro,timestamp';

// Nomi delle sole colonne "risorsa" (esclusi userId e timestamp)
// Usati nel metodo addResources per iterare sui delta
const RESOURCE_KEYS = ['grano', 'legno', 'oro', 'pietra', 'ferro'];


// ─────────────────────────────────────────────────────────────
//  Funzioni di utilità interne
//  Non vengono esportate: servono solo ai metodi pubblici.
// ─────────────────────────────────────────────────────────────

// Restituisce il percorso del file CSV delle risorse di un utente
function getFilePath(userId) {
    return path.join(OUTPUT_DIR, `${userId}_resources.csv`);
}

// Converte la riga dati CSV (stringa) in un oggetto JavaScript
// Esempio input:  "usr_drago01,50000,30000,10000,20000,5000,2025-..."
// Esempio output: { userId: "usr_drago01", grano: 50000, ... }
function parseRow(csvLine) {
    const [userId, grano, legno, oro, pietra, ferro, timestamp] = csvLine.split(',');

    return {
        userId,
        grano:     Number(grano),
        legno:     Number(legno),
        oro:       Number(oro),
        pietra:    Number(pietra),
        ferro:     Number(ferro),
        timestamp,
    };
}

// Converte un oggetto risorse in una stringa riga CSV
// Esempio input:  { userId: "usr_drago01", grano: 50000, ... }
// Esempio output: "usr_drago01,50000,30000,10000,20000,5000,2025-..."
function toRow(obj) {
    return [
        obj.userId,
        obj.grano,
        obj.legno,
        obj.oro,
        obj.pietra,
        obj.ferro,
        obj.timestamp,
    ].join(',');
}

// Scrive (o sovrascrive) il file CSV con l'intestazione e la riga dati fornita
async function writeCSV(userId, resourceObj) {
    const content = `${CSV_HEADER}\n${toRow(resourceObj)}`;
    await fs.writeFile(getFilePath(userId), content, 'utf-8');
}


// ─────────────────────────────────────────────────────────────
//  readResources
//  Legge il file CSV e restituisce le risorse attuali dell'utente.
//
//  Chiamato da:  GET /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//  Ritorna:      oggetto { userId, grano, legno, oro, pietra, ferro, timestamp }
// ─────────────────────────────────────────────────────────────

async function readResources(userId) {

    try {
        const fileContent = await fs.readFile(getFilePath(userId), 'utf-8');

        // Il file ha 2 righe: riga 0 = intestazione, riga 1 = dati
        const lines = fileContent.trim().split('\n');

        if (lines.length < 2) {
            throw new Error('File CSV vuoto o corrotto.');
        }

        return parseRow(lines[1]);

    } catch {
        throw new Error(`Risorse per "${userId}" non trovate.`);
    }
}


// ─────────────────────────────────────────────────────────────
//  createResources
//  Crea il file CSV con le risorse di partenza dell'utente.
//  Se il file esiste già lancia un errore (no sovrascrittura).
//
//  Chiamato da:  POST /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//                data — { grano, legno, oro, pietra, ferro }
//                       i campi mancanti partono da 0
//  Ritorna:      l'oggetto risorse appena creato
// ─────────────────────────────────────────────────────────────

async function createResources(userId, data) {

    const filePath = getFilePath(userId);

    // Controlla se esiste già un file per questo utente
    try {
        await fs.access(filePath);
        throw new Error(`Risorse per "${userId}" esistono già.`);

    } catch (err) {
        if (err.message.includes('esistono già')) throw err;
        // File non trovato → possiamo crearlo
    }

    const newResources = {
        userId,
        grano:     data.grano  ?? 0,
        legno:     data.legno  ?? 0,
        oro:       data.oro    ?? 0,
        pietra:    data.pietra ?? 0,
        ferro:     data.ferro  ?? 0,
        timestamp: new Date().toISOString(),
    };

    await writeCSV(userId, newResources);

    return newResources;
}


// ─────────────────────────────────────────────────────────────
//  updateResources
//  Sovrascrive i valori delle risorse con quelli nuovi forniti.
//  I campi non inclusi in "data" mantengono il valore precedente.
//
//  Chiamato da:  PUT /api/resources/:userId  (in server.js)
//  Argomenti:    userId
//                data — campi da aggiornare, es. { oro: 99999 }
//  Ritorna:      l'oggetto risorse aggiornato
// ─────────────────────────────────────────────────────────────

async function updateResources(userId, data) {

    // Legge i valori attuali (lancia errore se non esistono)
    const existing = await readResources(userId);

    const updated = {
        ...existing,
        ...data,
        userId,                              // non sovrascrivibile
        timestamp: new Date().toISOString(), // aggiorna sempre il timestamp
    };

    await writeCSV(userId, updated);

    return updated;
}


// ─────────────────────────────────────────────────────────────
//  addResources
//  Somma un delta alle risorse attuali.
//  Usa valori positivi per guadagni, negativi per perdite.
//  Nessuna risorsa scende sotto 0.
//
//  Chiamato da:  PATCH /api/resources/:userId/add  (in server.js)
//
//  Caso d'uso tipico — dopo una battaglia:
//    vincitore: addResources('usr_a', { oro: +5000, grano: +2000 })
//    perdente:  addResources('usr_b', { oro: -5000, grano: -2000 })
//
//  Argomenti:    userId
//                delta — es. { grano: 500, oro: -200 }
//  Ritorna:      l'oggetto risorse aggiornato
// ─────────────────────────────────────────────────────────────

async function addResources(userId, delta) {

    const existing = await readResources(userId);

    // Crea una copia dei valori attuali e applica i delta
    const updated = {
        ...existing,
        userId,
        timestamp: new Date().toISOString(),
    };

    for (const key of RESOURCE_KEYS) {

        if (delta[key] !== undefined) {
            const newValue = existing[key] + Number(delta[key]);

            // Impedisce che le risorse diventino negative
            updated[key] = Math.max(0, newValue);
        }
    }

    await writeCSV(userId, updated);

    return updated;
}

// ─────────────────────────────────────────────────────────────
//  MAP — mappa.csv
//  Header: row,col,src,resources,ownerId
//  Una riga per tile — solo le tile non-erba base sono obbligatorie
//  Le tile mancanti vengono considerate grass1 di default
// ─────────────────────────────────────────────────────────────

const MAP_FILE   = path.join(OUTPUT_DIR, 'mappa.csv');
const MAP_HEADER = 'row,col,src,resources,ownerId';

// Converte una riga CSV in oggetto tile
function parseTileRow(line) {
    const [row, col, src, resources, ownerId] = line.split(',');
    return {
        row:       Number(row),
        col:       Number(col),
        src:       src || 'grass1',
        resources: resources !== '' && resources !== undefined ? Number(resources) : null,
        ownerId:   ownerId?.trim() || null,
    };
}

// Converte un oggetto tile in riga CSV
function toTileRow(tile) {
    return [
        tile.row,
        tile.col,
        tile.src,
        tile.resources ?? '',
        tile.ownerId   ?? '',
    ].join(',');
}

async function readMap() {
    try {
        const content = await fs.readFile(MAP_FILE, 'utf-8');
        const lines = content.replace(/\r/g, '').trim().split('\n');

        // CORREZIONE QUI:
        // lines[1] è "#200,200"
        // .slice(1) toglie il cancelletto -> "200,200"
        // .split(',') divide in ["200", "200"]
        const meta = lines[1].slice(1).split(',');
        const cols = Number(meta[0]);
        const rows = Number(meta[1]);

        if (isNaN(cols) || isNaN(rows)) throw new Error("Dimensioni mappa non valide");

        // Inizializza la mappa con le dimensioni corrette
        const map = Array.from({ length: rows }, (_, r) =>
            Array.from({ length: cols }, (_, c) => ({ 
                row: r, 
                col: c, 
                src: 'grass1', 
                resources: null, 
                ownerId: null 
            }))
        );

        // Riempie con i dati dal CSV (saltando header e meta)
        for (let i = 2; i < lines.length; i++) {
            if (!lines[i].trim()) continue;
            const tile = parseTileRow(lines[i]);
            if (tile.row >= 0 && tile.row < rows && tile.col >= 0 && tile.col < cols) {
                map[tile.row][tile.col] = tile;
            }
        }

        return { cols, rows, map };

    } catch (err) {
        console.error("Errore lettura mappa:", err.message);
        return null;
    }
}

async function writeMap(cols, rows, tileMap) {
    const lines = [MAP_HEADER, `#${cols},${rows}`];

    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            const cell = tileMap[r][c];

            // Normalizza: accetta sia stringhe che oggetti
            const tile = typeof cell === 'string'
                ? { row: r, col: c, src: cell, resources: null, ownerId: null }
                : { row: r, col: c, src: cell.src ?? 'grass1', resources: cell.resources ?? null, ownerId: cell.ownerId ?? null };

            // Salva SOLO le tile che hanno qualcosa di non-default
            // Le tile grass senza dati extra vengono omesse — il reader le ricostruisce
            const isDefaultGrass = tile.src.startsWith('grass') && tile.resources === null && tile.ownerId === null;
            if (!isDefaultGrass) {
                lines.push(toTileRow(tile));
            }
        }
    }

    await fs.writeFile(MAP_FILE, lines.join('\n'), 'utf-8');
    return { cols, rows, map: tileMap };
}

async function setMapTile(row, col, src, extraData = {}) {
    // Legge il file riga per riga e aggiorna o inserisce la tile
    let content;
    try {
        content = await fs.readFile(MAP_FILE, 'utf-8');
    } catch {
        throw new Error('mappa.csv non trovato.');
    }

    const lines = content.trim().split('\n');
    const meta  = lines[1].replace(/\r/g, '').trim().split('\n');
    const cols  = Number(meta[0]);
    const rows  = Number(meta[1]);

    if (row < 0 || row >= rows || col < 0 || col >= cols) {
        throw new Error(`Tile (${row}, ${col}) fuori dai limiti.`);
    }

    const newTile = { row, col, src, resources: extraData.resources ?? null, ownerId: extraData.ownerId ?? null };
    const newRow  = toTileRow(newTile);

    // Cerca se esiste già una riga per questa coordinata
    let found = false;
    for (let i = 2; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const parts = lines[i].split(',');
        if (Number(parts[0]) === row && Number(parts[1]) === col) {
            lines[i] = newRow;
            found = true;
            break;
        }
    }

    if (!found) lines.push(newRow);

    await fs.writeFile(MAP_FILE, lines.join('\n'), 'utf-8');
}

async function readMapSize() {
    const content  = await fs.readFile(MAP_FILE, 'utf-8');

    // Normalizza line ending Windows → Unix, poi splitta
    const lines    = content.replace(/\r/g, '').trim().split('\n');
    const metaLine = lines[1];   // "#50,50"

    if (!metaLine || !metaLine.startsWith('#')) {
        throw new Error(`Riga metadati mappa non trovata. Riga trovata: "${metaLine}"`);
    }

    const [cols, rows] = metaLine.slice(1).split(',').map(Number);

    if (isNaN(cols) || isNaN(rows)) {
        throw new Error(`Metadati mappa non validi: "${metaLine}"`);
    }


    return  { cols, rows };
}

async function updateMapTileResources(row, col, delta) {
    let content;
    try {
        content = await fs.readFile(MAP_FILE, 'utf-8');
    } catch {
        throw new Error('mappa.csv non trovato.');
    }

    const lines = content.trim().split('\n');
    let found   = false;

    for (let i = 2; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const parts = lines[i].split(',');
        if (Number(parts[0]) === row && Number(parts[1]) === col) {
            const tile      = parseTileRow(lines[i]);
            tile.resources  = Math.max(0, (tile.resources ?? 0) + delta);
            lines[i]        = toTileRow(tile);
            found           = true;
            break;
        }
    }

    if (!found) throw new Error(`Tile (${row}, ${col}) non trovata o non ha risorse.`);

    await fs.writeFile(MAP_FILE, lines.join('\n'), 'utf-8');
}


const TROOP_KEYS = ['fanteria', 'cavalleria', 'arceri', 'balliste'];

function getTroopsPath(userId) {
    return path.join(OUTPUT_DIR, `${userId}_troops.csv`);
}

function parseTroopsRow(line) {
    const [userId, fanteria, cavalleria, arceri, balliste, timestamp] = line.split(',');
    return {
        userId,
        fanteria:   Number(fanteria),
        cavalleria: Number(cavalleria),
        arceri:     Number(arceri),
        balliste:   Number(balliste),
        timestamp,
    };
}

function toTroopsRow(obj) {
    return [obj.userId, obj.fanteria, obj.cavalleria, obj.arceri, obj.balliste, obj.timestamp].join(',');
}

async function writeTroopsCSV(userId, obj) {
    const content = `userId,fanteria,cavalleria,arceri,balliste,timestamp\n${toTroopsRow(obj)}`;
    await fs.writeFile(getTroopsPath(userId), content, 'utf-8');
}

async function readTroops(userId) {
    try {
        const content = await fs.readFile(getTroopsPath(userId), 'utf-8');
        const lines   = content.trim().split('\n');
        if (lines.length < 2) throw new Error('File truppe vuoto o corrotto.');
        return parseTroopsRow(lines[1]);
    } catch {
        throw new Error(`Truppe per "${userId}" non trovate.`);
    }
}

async function createTroops(userId, data = {}) {
    const filePath = getTroopsPath(userId);
    try {
        await fs.access(filePath);
        throw new Error(`Truppe per "${userId}" esistono già.`);
    } catch (err) {
        if (err.message.includes('esistono già')) throw err;
    }

    const obj = {
        userId,
        fanteria:   data.fanteria   ?? 100,
        cavalleria: data.cavalleria ?? 100,
        arceri:     data.arceri     ?? 100,
        balliste:   data.balliste   ?? 100,
        timestamp:  new Date().toISOString(),
    };
    await writeTroopsCSV(userId, obj);
    return obj;
}

async function updateTroops(userId, updates) {
    const existing = await readTroops(userId);
    const updated  = { ...existing, ...updates, userId, timestamp: new Date().toISOString() };
    await writeTroopsCSV(userId, updated);
    return updated;
}


module.exports = {
    readResources, createResources, updateResources, addResources,
    readMap, writeMap, setMapTile, readMapSize, updateMapTileResources,
    readTroops, createTroops, updateTroops,
};