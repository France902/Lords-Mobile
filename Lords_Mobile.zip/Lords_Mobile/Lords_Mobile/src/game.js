const canvas = document.getElementById('game-canvas');
    const ctx    = canvas.getContext('2d');

    function resizeCanvas() {
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    resizeCanvas();


    // ════════════════════════════════════════════════════
    //  TILE TYPES
    //  Ogni tipo di terreno ha un src relativo al file HTML.
    //  Il pattern viene creato una volta sola in loadTiles()
    //  e poi riusato per ogni drawDiamond — zero overhead.
    // ════════════════════════════════════════════════════

    const TILE_TYPES = {
        grass1: {
            src:     '../data/input/resources/grass.png',
            pattern: null,   // verrà popolato da loadTiles()
        },
        grass2: {
            src:     '../data/input/resources/grass2.png',
            pattern: null,   // verrà popolato da loadTiles()
        },
        grass3: {
            src:     '../data/input/resources/grass3.png',
            pattern: null,   // verrà popolato da loadTiles()
        },
        grass4: {
            src:     '../data/input/resources/grass4.png',
            pattern: null,   // verrà popolato da loadTiles()
        },
        // stone: { src: '../data/input/resources/stone.png', pattern: null },
        // water: { src: '../data/input/resources/water.png', pattern: null },
    };


    // ════════════════════════════════════════════════════
    //  loadTiles()
    //  Carica tutte le immagini definite in TILE_TYPES
    //  e crea il CanvasPattern corrispondente.
    //  Ritorna una Promise — il render parte solo dopo.
    // ════════════════════════════════════════════════════

    function loadTiles() {
        const promises = Object.entries(TILE_TYPES).map(([key, tile]) => {
            return new Promise((resolve, reject) => {
                const img = new Image();

                img.onload = () => {
                    // 'repeat' → la texture si ripete dentro la sagoma del rombo
                    tile.pattern = ctx.createPattern(img, 'repeat');
                    console.log(`[Tile] "${key}" caricato correttamente.`);
                    resolve();
                };

                img.onerror = () => {
                    // Se il file manca, il tile usa un colore di fallback
                    // così la griglia non crasha — utile in sviluppo
                    console.warn(`[Tile] "${key}" non trovato (${tile.src}). Uso colore fallback.`);
                    tile.pattern = '#4caf50';
                    resolve();   // resolve comunque — non vogliamo un reject qui
                };

                img.src = tile.src;
            });
        });

        return Promise.all(promises);
    }


    // ════════════════════════════════════════════════════
    //  drawDiamond()
    //  Ora accetta fillStyle direttamente (stringa o pattern)
    // ════════════════════════════════════════════════════

    function drawDiamond(cx, cy, halfW, halfH, fillStyle) {

        ctx.beginPath();
        ctx.moveTo(cx,         cy - halfH);
        ctx.lineTo(cx + halfW, cy        );
        ctx.lineTo(cx,         cy + halfH);
        ctx.lineTo(cx - halfW, cy        );
        ctx.closePath();

        ctx.fillStyle = fillStyle;
        ctx.fill();

        ctx.fill();
        ctx.lineWidth = 0.5;
        ctx.strokeStyle = fillStyle;
        ctx.stroke();
    }


    // ════════════════════════════════════════════════════
    //  drawDiamondGrid()
    // ════════════════════════════════════════════════════

    function drawDiamondGrid() {

        const w = canvas.width;
        const h = canvas.height;

        const halfH = 54;
        const halfW = halfH * 2;

        const stepX = halfW * 2;
        const stepY = halfH;

        const cols = Math.ceil(w / stepX) + 2;
        const rows = Math.ceil(h / stepY) + 2;

        for (let row = -1; row < rows; row++) {

            const offsetX = (row % 2 !== 0) ? halfW : 0;

            for (let col = -1; col < cols; col++) {

                const cx = col * stepX + offsetX;
                const cy = row * stepY;

                // Qui scegli il tipo per ogni cella — per ora tutto grass
                const num = Math.floor(Math.random() * 4);
                let tile;
                switch(num) {
                    case 0:
                        tile = TILE_TYPES.grass1;
                        break;
                    case 1:
                        tile = TILE_TYPES.grass2;
                        break;
                    case 2:
                        tile = TILE_TYPES.grass3;
                        break;
                    case 3:
                        tile = TILE_TYPES.grass4;
                        break;
                }

                console.log(num);
                
                const fillStyle   = tile.pattern ?? '#4caf50';

                drawDiamond(cx, cy, halfW, halfH, fillStyle);
            }
        }
    }


    // ════════════════════════════════════════════════════
    //  render()
    // ════════════════════════════════════════════════════

    function render() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawDiamondGrid();
    }


    // ════════════════════════════════════════════════════
    //  Avvio — prima carica le tile, poi disegna
    // ════════════════════════════════════════════════════

    loadTiles().then(() => {
        render();
    });


    // ════════════════════════════════════════════════════
    //  Resize
    // ════════════════════════════════════════════════════

    let resizeTimer;

    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            resizeCanvas();
            render();
        }, 120);
    });