// ════════════════════════════════════════════════════════════
//  SEZIONE CLIENT (Logica UI e Registrazione)
// ════════════════════════════════════════════════════════════

let playIsPressed = false;

function playAction() {
    if(!playIsPressed) {
        playIsPressed = true;
        document.getElementById('formUtente').style.display = 'flex';
        document.getElementById('btn-gioca').style.display = 'none';
    }
}

// ════════════════════════════════════════════════════════════
//  CONFIGURAZIONE E UTILS API
// ════════════════════════════════════════════════════════════
const USE_SERVER = true; // Impostalo a true per parlare con Express

async function apiFetch(url, options = {}) {
    const response = await fetch(url, {
        headers: { 'Content-Type': 'application/json' },
        ...options,
    });

    const data = await response.json();
    if (!data.ok) {
        throw new Error(data.error ?? 'Errore dal server');
    }
    return data;
}

// ════════════════════════════════════════════════════════════
//  LOGICA DI REGISTRAZIONE (CLIENT)
// ════════════════════════════════════════════════════════════

async function registraUtente() {
    const nome     = document.getElementById('nome').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!nome || !password) {
        alert('Compila tutti i campi.');
        return;
    }

    const userId = 'usr_' + nome.toLowerCase().replace(/\s+/g, '_') + '_' + Date.now();

    try {
        // 1. Chiamata al server per creare l'utente (POST /api/users)
        await apiFetch('/api/users', {
            method: 'POST',
            body: JSON.stringify({
                id: userId,
                name: nome,
                password: password,
                level: 1,
                power: 0
            })
        });

        // 2. Chiamata al server per inizializzare le risorse (POST /api/resources/:id)
        await apiFetch(`/api/resources/${userId}`, {
            method: 'POST',
            body: JSON.stringify({
                grano: 1000,
                legno: 1000,
                oro: 500,
                pietra: 500,
                ferro: 250
            })
        });

        // Salva i dati in sessione e vai al gioco
        sessionStorage.setItem('userId', userId);
        sessionStorage.setItem('userName', nome);

        window.location.href = '/game.html';

    } catch (err) {
        alert('Errore durante la registrazione: ' + err.message);
    }
}

// ════════════════════════════════════════════════════════════
//  INIZIALIZZAZIONE DATI (Eseguita in game.html o all'avvio)
// ════════════════════════════════════════════════════════════

async function initServerData() {
    const userId = sessionStorage.getItem('userId');
    if (!userId || !USE_SERVER) return;

    try {
        // Recuperiamo i dati aggiornati dal server
        const userRes = await apiFetch(`/api/users/${userId}`);
        const resRes  = await apiFetch(`/api/resources/${userId}`);

        // Aggiorna UI
        const nameEl = document.getElementById('player-name');
        if (nameEl) nameEl.textContent = userRes.data.name;
        
        renderResources(resRes.data);

    } catch (err) {
        console.warn('[Server] Errore caricamento:', err.message);
    }
}

function renderResources(resources) {
    ['grano', 'legno', 'oro', 'pietra', 'ferro'].forEach(key => {
        const el = document.getElementById(`res-${key}`);
        if (el) el.textContent = resources[key].toLocaleString('it-IT');
    });
}