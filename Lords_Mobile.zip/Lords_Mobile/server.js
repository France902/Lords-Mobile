/**
 * ============================================================
 *  server.js
 *  Entry point — server Express per Lords Mobile
 * ============================================================
 *
 *  Avvio:  node server.js   (oppure: npm start)
 *  Porta:  3000 di default, oppure la variabile PORT
 *
 *  Struttura delle route:
 *    /api/users/:id          → jsonHandler  (profili utente, JSON)
 *    /api/resources/:userId  → csvHandler   (risorse, CSV)
 *    /api/battles/...        → xmlHandler   (log battaglie, XML)
 *    *                       → index.html   (SPA client)
 * ============================================================
 */

const express = require('express');
const path    = require('path');

// I tre handler gestiscono rispettivamente JSON, CSV e XML
const jsonHandler = require('./src/parsers/jsonHandler');
const csvHandler  = require('./src/parsers/csvHandler');
const xmlHandler  = require('./src/parsers/xmlHandler');

const app  = express();
const PORT = process.env.PORT || 3000;


// ─────────────────────────────────────────────────────────────
//  Middleware globali
// ─────────────────────────────────────────────────────────────

// Permette al server di leggere il body delle richieste POST/PUT come JSON
app.use(express.json());

// Permette di leggere body da form HTML standard (application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));

// Serve i file statici (index.html, CSS, app.js) dalla cartella src/
app.use(express.static(path.join(__dirname, 'src')));


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — UTENTI  (dati salvati in JSON)
//  File toccati: data/output/<userId>.json
// ═══════════════════════════════════════════════════════════════════════════════

// Legge il profilo di un utente
// ← app.js chiama: loadUser(userId)
app.get('/api/users/:id', async (req, res) => {

    try {
        const user = await jsonHandler.readUser(req.params.id);
        res.json({ ok: true, data: user });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Crea un nuovo utente
// Body atteso: { id, name, level?, power?, guild? }
// ← app.js chiama: createUser()
app.post('/api/users', async (req, res) => {

    try {
        const newUser = await jsonHandler.createUser(req.body);
        res.status(201).json({ ok: true, data: newUser });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Aggiorna i campi di un utente (solo quelli forniti nel body)
// Body atteso: { level?, power?, guild?, ... }
// ← app.js chiama: levelUpUser(userId, newLevel, newPower)
app.put('/api/users/:id', async (req, res) => {

    try {
        const updated = await jsonHandler.updateUser(req.params.id, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Elimina un utente
// ← non usato direttamente in app.js, disponibile per admin/debug
app.delete('/api/users/:id', async (req, res) => {

    try {
        await jsonHandler.deleteUser(req.params.id);
        res.json({ ok: true, message: `Utente ${req.params.id} eliminato.` });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — RISORSE  (dati salvati in CSV)
//  File toccati: data/output/<userId>_resources.csv
// ═══════════════════════════════════════════════════════════════════════════════

// Legge le risorse attuali dell'utente
// ← app.js chiama: loadResources(userId)
app.get('/api/resources/:userId', async (req, res) => {

    try {
        const resources = await csvHandler.readResources(req.params.userId);
        res.json({ ok: true, data: resources });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Crea le risorse iniziali dell'utente (da usare una volta sola alla registrazione)
// Body atteso: { grano?, legno?, oro?, pietra?, ferro? }
// ← app.js chiama: initResources(userId)
app.post('/api/resources/:userId', async (req, res) => {

    try {
        const resources = await csvHandler.createResources(req.params.userId, req.body);
        res.status(201).json({ ok: true, data: resources });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Sovrascrive le risorse con nuovi valori assoluti
// Body atteso: { grano?, legno?, oro?, pietra?, ferro? }
// ← non usato in app.js di default, utile per cheat/admin
app.put('/api/resources/:userId', async (req, res) => {

    try {
        const updated = await csvHandler.updateResources(req.params.userId, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Aggiunge (o sottrae) risorse in modo incrementale
// Body atteso: { grano?: ±N, legno?: ±N, oro?: ±N, ... }
// ← app.js chiama: applyLoot(userId, loot)  dopo ogni battaglia
app.patch('/api/resources/:userId/add', async (req, res) => {

    try {
        const updated = await csvHandler.addResources(req.params.userId, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — BATTAGLIE  (dati salvati in XML)
//  File toccati: data/output/battle_<battleId>.xml
//
//  ATTENZIONE all'ordine delle route:
//  "/api/battles/user/:userId" deve stare PRIMA di "/api/battles/:battleId"
//  altrimenti Express interpreta "user" come un battleId.
// ═══════════════════════════════════════════════════════════════════════════════

// Restituisce tutte le battaglie di un utente (attaccante o difensore)
// ← app.js chiama: loadBattleHistory(userId)
app.get('/api/battles/user/:userId', async (req, res) => {

    try {
        const battles = await xmlHandler.getBattlesByUser(req.params.userId);
        res.json({ ok: true, data: battles });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// Legge il log di una singola battaglia
// ← non usato in app.js di default, utile per mostrare il dettaglio di una battaglia
app.get('/api/battles/:battleId', async (req, res) => {

    try {
        const battle = await xmlHandler.readBattleLog(req.params.battleId);
        res.json({ ok: true, data: battle });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Salva il risultato di una nuova battaglia
// Body atteso: { attackerId, attackerName?, attackerTroops?, attackerLosses?,
//               defenderId, defenderName?, defenderTroops?, defenderLosses?,
//               winner, loot?: { oro, grano, legno } }
// ← app.js chiama: resolveBattle(attacker, defender, result)
app.post('/api/battles', async (req, res) => {

    try {
        const battle = await xmlHandler.saveBattleLog(req.body);
        res.status(201).json({ ok: true, data: battle });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Elimina il log di una battaglia
// ← non usato in app.js di default, utile per admin/debug
app.delete('/api/battles/:battleId', async (req, res) => {

    try {
        await xmlHandler.deleteBattleLog(req.params.battleId);
        res.json({ ok: true, message: `Battaglia ${req.params.battleId} eliminata.` });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ─────────────────────────────────────────────────────────────
//  Catch-all — SPA fallback
//  Qualsiasi route non-API rimanda a index.html.
//  Necessario per il routing client-side.
// ─────────────────────────────────────────────────────────────

app.get(/^(.*)$/, (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'index.html'));
});


// ─────────────────────────────────────────────────────────────
//  Avvio del server
// ─────────────────────────────────────────────────────────────

app.listen(PORT, () => {
    console.log(`Lords Mobile server avviato → http://localhost:${PORT}`);
});

// Esportato per eventuali test con Jest/Supertest
module.exports = app;