/**
 * ============================================================
 *  server.js
 *  Entry point — server Express per Lords Mobile
 * ============================================================
 *
 *  Avvio:  node server.js   (oppure: npm start)
 *  Porta:  3000 di default, oppure la variabile PORT
 *
 *  Struttura delle route:
 *    /api/users/:id          → jsonHandler  (profili utente, JSON)
 *    /api/resources/:userId  → csvHandler   (risorse, CSV)
 *    /api/battles/...        → xmlHandler   (log battaglie, XML)
 *    *                       → index.html   (SPA client)
 * ============================================================
 */

const express = require('express');
const path    = require('path');


// I tre handler gestiscono rispettivamente JSON, CSV e XML
const jsonHandler = require('./src/parsers/jsonHandler');
const csvHandler  = require('./src/parsers/csvHandler');
const xmlHandler  = require('./src/parsers/xmlHandler');

const app  = express();
const PORT = process.env.PORT || 3000;


app.use('/data', express.static(path.join(__dirname, 'data')));



// ─────────────────────────────────────────────────────────────
//  Middleware globali
// ─────────────────────────────────────────────────────────────

// Permette al server di leggere il body delle richieste POST/PUT come JSON
app.use(express.json());

// Permette di leggere body da form HTML standard (application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));

// Serve i file statici (index.html, CSS, app.js) dalla cartella src/
app.use(express.static(path.join(__dirname, 'src')));


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — UTENTI  (dati salvati in JSON)
//  File toccati: data/output/<userId>.json
// ═══════════════════════════════════════════════════════════════════════════════

// Legge il profilo di un utente
// ← app.js chiama: loadUser(userId)
app.get('/api/users/:id', async (req, res) => {

    try {
        const user = await jsonHandler.readUser(req.params.id);
        res.json({ ok: true, data: user });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Crea un nuovo utente
// Body atteso: { id, name, level?, power?, guild? }
// ← app.js chiama: createUser()
app.post('/api/users', async (req, res) => {

    try {
        const newUser = await jsonHandler.createUser(req.body);
        res.status(201).json({ ok: true, data: newUser });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — LOGIN
// ═══════════════════════════════════════════════════════════════════════════════

app.post('/api/users/login', async (req, res) => {
    try {
        const { name, password } = req.body;

        if (!name || !password) {
            return res.status(400).json({ ok: false, error: 'Nome e password obbligatori.' });
        }

        // Recuperiamo tutti gli utenti per trovare quello con il nome corrispondente
        // Nota: jsonHandler deve avere un metodo per listare o cercare utenti.
        // Se non ce l'ha, dobbiamo implementare una ricerca sui file nella cartella data/output
        const user = await jsonHandler.findUserByName(name);

        if (!user) {
            return res.status(404).json({ ok: false, error: 'Utente non trovato.' });
        }

        // Controllo password (in chiaro come da tuo setup attuale)
        if (user.password !== password) {
            return res.status(401).json({ ok: false, error: 'Password errata.' });
        }

        // Login successo: restituiamo i dati necessari al client
        res.json({ 
            ok: true, 
            data: { 
                id: user.id, 
                name: user.name, 
                castleRow: user.castleRow, 
                castleCol: user.castleCol 
            } 
        });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// Aggiorna i campi di un utente (solo quelli forniti nel body)
// Body atteso: { level?, power?, guild?, ... }
// ← app.js chiama: levelUpUser(userId, newLevel, newPower)
app.put('/api/users/:id', async (req, res) => {

    try {
        const updated = await jsonHandler.updateUser(req.params.id, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Elimina un utente
// ← non usato direttamente in app.js, disponibile per admin/debug
app.delete('/api/users/:id', async (req, res) => {

    try {
        await jsonHandler.deleteUser(req.params.id);
        res.json({ ok: true, message: `Utente ${req.params.id} eliminato.` });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — RISORSE  (dati salvati in CSV)
//  File toccati: data/output/<userId>_resources.csv
// ═══════════════════════════════════════════════════════════════════════════════

// Legge le risorse attuali dell'utente
// ← app.js chiama: loadResources(userId)
app.get('/api/resources/:userId', async (req, res) => {

    try {
        const resources = await csvHandler.readResources(req.params.userId);
        res.json({ ok: true, data: resources });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Crea le risorse iniziali dell'utente (da usare una volta sola alla registrazione)
// Body atteso: { grano?, legno?, oro?, pietra?, ferro? }
// ← app.js chiama: initResources(userId)
app.post('/api/resources/:userId', async (req, res) => {

    try {
        const resources = await csvHandler.createResources(req.params.userId, req.body);
        res.status(201).json({ ok: true, data: resources });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Sovrascrive le risorse con nuovi valori assoluti
// Body atteso: { grano?, legno?, oro?, pietra?, ferro? }
// ← non usato in app.js di default, utile per cheat/admin
app.put('/api/resources/:userId', async (req, res) => {

    try {
        const updated = await csvHandler.updateResources(req.params.userId, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Aggiunge (o sottrae) risorse in modo incrementale
// Body atteso: { grano?: ±N, legno?: ±N, oro?: ±N, ... }
// ← app.js chiama: applyLoot(userId, loot)  dopo ogni battaglia
app.patch('/api/resources/:userId/add', async (req, res) => {

    try {
        const updated = await csvHandler.addResources(req.params.userId, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — BATTAGLIE  (dati salvati in XML)
//  File toccati: data/output/battle_<battleId>.xml
//
//  ATTENZIONE all'ordine delle route:
//  "/api/battles/user/:userId" deve stare PRIMA di "/api/battles/:battleId"
//  altrimenti Express interpreta "user" come un battleId.
// ═══════════════════════════════════════════════════════════════════════════════

// Restituisce tutte le battaglie di un utente (attaccante o difensore)
// ← app.js chiama: loadBattleHistory(userId)
app.get('/api/battles/user/:userId', async (req, res) => {

    try {
        const battles = await xmlHandler.getBattlesByUser(req.params.userId);
        res.json({ ok: true, data: battles });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// Legge il log di una singola battaglia
// ← non usato in app.js di default, utile per mostrare il dettaglio di una battaglia
app.get('/api/battles/:battleId', async (req, res) => {

    try {
        const battle = await xmlHandler.readBattleLog(req.params.battleId);
        res.json({ ok: true, data: battle });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Salva il risultato di una nuova battaglia
// Body atteso: { attackerId, attackerName?, attackerTroops?, attackerLosses?,
//               defenderId, defenderName?, defenderTroops?, defenderLosses?,
//               winner, loot?: { oro, grano, legno } }
// ← app.js chiama: resolveBattle(attacker, defender, result)
app.post('/api/battles', async (req, res) => {

    try {
        const battle = await xmlHandler.saveBattleLog(req.body);
        res.status(201).json({ ok: true, data: battle });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Elimina il log di una battaglia
// ← non usato in app.js di default, utile per admin/debug
app.delete('/api/battles/:battleId', async (req, res) => {

    try {
        await xmlHandler.deleteBattleLog(req.params.battleId);
        res.json({ ok: true, message: `Battaglia ${req.params.battleId} eliminata.` });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — MAPPA  (salvata in mappa.csv)
//  GET /api/map → restituisce la mappa esistente o la genera ex novo
// ═══════════════════════════════════════════════════════════════════════════════

const MAP_COLS  = 200;
const MAP_ROWS  = 200;

const GRASS_TYPES = ['grass1', 'grass2', 'grass3'];
const CAMP_TYPES = ['campwheat', 'campmineral', 'camprock', 'campwood'];
const CASTLE_TYPES = ['mainplayer', 'enemyplayer'];
const TREE_TYPES = ['trees1', 'trees2', 'trees3'];

const CAMP_INITIAL_RESOURCES = {
    campwheat: 5000,
    campmineral: 3000,
    camprock: 4000,
    campwood: 4500
};

app.get('/api/map', async (req, res) => {
    try {
        let mapData = await csvHandler.readMap();

        if (!mapData) {
            console.log('[Map] mappa.csv non trovato — genero la mappa...');

            const tileMap = [];
            for (let r = 0; r < MAP_ROWS; r++) {
                tileMap[r] = [];
                for (let c = 0; c < MAP_COLS; c++) {
                    const randomChance = Math.random(); 

                    let selectedTile;
                    let resources = null; // Default per erba e alberi

                    if (randomChance < 0.80) {
                        selectedTile = GRASS_TYPES[Math.floor(Math.random() * GRASS_TYPES.length)];
                    } else if(randomChance < 0.90) {
                        selectedTile = TREE_TYPES[Math.floor(Math.random() * TREE_TYPES.length)];
                    } else {
                        // È un CAMP
                        selectedTile = CAMP_TYPES[Math.floor(Math.random() * CAMP_TYPES.length)];
                        // Assegna le risorse in base al tipo di campo
                        resources = CAMP_INITIAL_RESOURCES[selectedTile] || 1000;
                    }

                    // Salviamo come oggetto per passare i dati al csvHandler
                    tileMap[r][c] = {
                        src: selectedTile,
                        resources: resources,
                        ownerId: null
                    };
                }
            }

            // Il tuo csvHandler.writeMap è già predisposto per ricevere oggetti o stringhe
            mapData = await csvHandler.writeMap(MAP_COLS, MAP_ROWS, tileMap);
            console.log('[Map] mappa.csv creato con risorse.');
        }

        res.json({ ok: true, data: mapData });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});

app.get('/api/troops/:userId', async (req, res) => {
    try {
        const troops = await csvHandler.readTroops(req.params.userId);
        res.json({ ok: true, data: troops });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});

app.post('/api/troops/:userId', async (req, res) => {
    try {
        const troops = await csvHandler.createTroops(req.params.userId, req.body);
        res.status(201).json({ ok: true, data: troops });
    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});

app.put('/api/troops/:userId', async (req, res) => {
    try {
        const troops = await csvHandler.updateTroops(req.params.userId, req.body);
        res.json({ ok: true, data: troops });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — MAPSIZE
//  GET /api/mapsize → restituisce solo cols e rows dalla prima riga del CSV
//  Usata dal client in fase di registrazione per calcolare la posizione castello
// ═══════════════════════════════════════════════════════════════════════════════

app.get('/api/mapsize', async (req, res) => {
    try {
        
        const size = await csvHandler.readMapSize();
        console.log(size);
        res.json({ ok: true, data: size });
    } catch (err) {
        // Se mappa.csv non esiste ancora, restituisce le costanti di default
        res.json({ ok: true, data: { cols: MAP_COLS, rows: MAP_ROWS } });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — SET TILE
//  PATCH /api/map/tile → sovrascrive una singola cella nella mappa
//  Body atteso: { row, col, tileKey }
// ═══════════════════════════════════════════════════════════════════════════════

app.patch('/api/map/tile', async (req, res) => {
    try {
        const { row, col, tileKey } = req.body;

        if (row === undefined || col === undefined || !tileKey) {
            return res.status(400).json({ ok: false, error: 'row, col e tileKey sono obbligatori.' });
        }

        await csvHandler.setMapTile(Number(row), Number(col), tileKey);
        res.json({ ok: true, data: { row, col, tileKey } });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});

// ════════════════════════════════════════════════════
//  MAP REGENERATION — ogni ora
//  Tiene i castelli, rigenera tutto il resto
// ════════════════════════════════════════════════════

async function regenerateMap() {

    try {
        const existing = await csvHandler.readMap();
        if (!existing) {
            console.warn('[Map] Nessuna mappa da rigenerare.');
            return;
        }

        const { cols, rows, map } = existing;

        // 1. Raccoglie tutte le posizioni castle prima di distruggerle
        const castles = [];
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const tile = map[r][c];
                const src  = typeof tile === 'string' ? tile : tile?.src;
                if (src === 'mainplayer' || src === 'enemyplayer') {
                    castles.push({
                        row:     r,
                        col:     c,
                        src,
                        ownerId: tile?.ownerId ?? null,
                    });
                }
            }
        }

        // 2. Genera mappa completamente nuova
        const castlePositions = new Set(castles.map(c => `${c.row},${c.col}`));
        const newMap = [];

        for (let r = 0; r < rows; r++) {
            newMap[r] = [];
            for (let c = 0; c < cols; c++) {

                // Le posizioni castello vengono saltate — ci tornano i castelli
                if (castlePositions.has(`${r},${c}`)) {
                    newMap[r][c] = { src: 'grass1', resources: null, ownerId: null };
                    continue;
                }

                const randomChance = Math.random();
                let src, resources = null;

                if (randomChance < 0.80) {
                    src = GRASS_TYPES[Math.floor(Math.random() * GRASS_TYPES.length)];
                } else if (randomChance < 0.90) {
                    src = TREE_TYPES[Math.floor(Math.random() * TREE_TYPES.length)];
                } else {
                    src       = CAMP_TYPES[Math.floor(Math.random() * CAMP_TYPES.length)];
                    resources = CAMP_INITIAL_RESOURCES[src] ?? 1000;
                }

                newMap[r][c] = { src, resources, ownerId: null };
            }
        }

        // 3. Rimette i castelli nelle posizioni originali
        for (const castle of castles) {
            newMap[castle.row][castle.col] = {
                src:     castle.src,
                resources: null,
                ownerId: castle.ownerId,
            };
        }

        await csvHandler.writeMap(cols, rows, newMap);

        // 4. Aggiorna il timestamp di versione — il client lo usa per sapere se ricaricare
        mapVersion = Date.now();

        console.log(`[Map] Rigenerata. Castelli preservati: ${castles.length}. Versione: ${mapVersion}`);

    } catch (err) {
        console.error('[Map] Errore rigenerazione:', err.message);
    }
}

// Timestamp che cambia ad ogni rigenerazione — usato dal client per polling leggero
let mapVersion = Date.now();

// Avvia il timer — prima rigenerazione dopo 1 ora, poi ogni ora
setInterval(regenerateMap, 1000 * 60 * 60);

// Route leggera — il client chiede solo se la versione è cambiata
// Se il numero è diverso dall'ultimo che conosce, scarica la mappa intera
app.get('/api/map/version', (req, res) => {
    res.json({ ok: true, data: { version: mapVersion } });
});

// ════════════════════════════════════════════════════
//  MARCE — persistenza su XML, truppe su CSV
// ════════════════════════════════════════════════════

// Crea una nuova marcia:
// 1. Toglie le truppe dal CSV
// 2. Scrive la marcia nell'XML dell'utente
app.post('/api/marches', async (req, res) => {
    const {
        userId, castleRow, castleCol,
        targetRow, targetCol,
        troops, troopType,
        durationSeconds, startTime,
        gatherDuration,          // ← nuovo
    } = req.body;

    if (!userId || !troopType || troops === undefined) {
        return res.status(400).json({ ok: false, error: 'Dati marcia incompleti.' });
    }

    try {
        const current = await csvHandler.readTroops(userId);

        if ((current[troopType] ?? 0) < troops) {
            return res.status(400).json({ ok: false, error: `Truppe insufficienti: ${troopType}.` });
        }

        const updated = { ...current };
        updated[troopType] = current[troopType] - Number(troops);
        await csvHandler.updateTroops(userId, updated);

        const marchId = `${userId}_${startTime}_${Math.random().toString(36).slice(2)}`;

        await xmlHandler.saveMarchLog(userId, {
            marchId, userId,
            castleRow: Number(castleRow), castleCol: Number(castleCol),
            targetRow: Number(targetRow), targetCol: Number(targetCol),
            troops:    Number(troops),
            troopType,
            durationSeconds: Number(durationSeconds),
            gatherDuration:  Number(gatherDuration ?? 10),
            startTime:       Number(startTime),
        });

        res.status(201).json({ ok: true, data: { marchId } });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});

// Restituisce tutte le marce attive di un utente dall'XML
// Calcola progress e posizione corrente interpolata
app.get('/api/marches/:userId', async (req, res) => {
    const { userId } = req.params;
    const now        = Date.now();

    try {
        const marches = await xmlHandler.readMarchLogs(userId);
        const result  = marches.map(march => {
            const elapsed  = (now - march.startTime) / 1000;
            const progress = Math.min(elapsed / march.durationSeconds, 1);
            const currentRow = march.castleRow + (march.targetRow - march.castleRow) * progress;
            const currentCol = march.castleCol + (march.targetCol - march.castleCol) * progress;
            return { ...march, progress, currentRow, currentCol };
        });

        res.json({ ok: true, data: result });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});

// Termina una marcia:
// 1. Legge i dati dall'XML per sapere quante truppe restituire
// 2. Restituisce le truppe al CSV
// 3. Elimina la marcia dall'XML
// Il parametro returnTroops=false serve per le marce cancellate in battaglia
app.delete('/api/marches/:userId/:marchId', async (req, res) => {
    const { userId, marchId } = req.params;
    const returnTroops = req.query.returnTroops !== 'false';   // default: true

    try {
        const march = await xmlHandler.deleteMarchLog(userId, marchId);

        if (!march) {
            return res.status(404).json({ ok: false, error: 'Marcia non trovata.' });
        }

        // Restituisce le truppe solo se la marcia è completata normalmente
        if (returnTroops && march.troopType && march.troops > 0) {
            const current = await csvHandler.readTroops(userId);
            const updated = { ...current };
            updated[march.troopType] = (current[march.troopType] ?? 0) + march.troops;
            await csvHandler.updateTroops(userId, updated);
        }

        res.json({ ok: true, data: { marchId, troopsReturned: returnTroops ? march.troops : 0 } });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});

// ════════════════════════════════════════════════════
//  ROUTE — LOOT CAMP
//  POST /api/map/loot
//  Legge le risorse di un camp, le aggiunge all'utente,
//  azzera il camp sulla mappa.
//  Body: { userId, row, col }
// ════════════════════════════════════════════════════

// Mappa tipo camp → chiave risorsa utente
const CAMP_RESOURCE_MAP = {
    campwheat:   'grano',
    campwood:    'legno',
    campmineral: 'ferro',
    camprock:    'pietra',
};

app.post('/api/map/loot', async (req, res) => {
    const { userId, row, col } = req.body;

    if (!userId || row === undefined || col === undefined) {
        return res.status(400).json({ ok: false, error: 'userId, row e col obbligatori.' });
    }

    try {
        // 1. Legge la mappa per trovare il camp e le sue risorse
        const mapData = await csvHandler.readMap();
        if (!mapData) return res.status(500).json({ ok: false, error: 'Mappa non trovata.' });

        const tile = mapData.map[Number(row)]?.[Number(col)];
        if (!tile) return res.status(404).json({ ok: false, error: `Tile (${row}, ${col}) non trovata.` });

        const campSrc   = typeof tile === 'string' ? tile : tile.src;
        const resources = typeof tile === 'object' ? (tile.resources ?? 0) : 0;
        const resKey    = CAMP_RESOURCE_MAP[campSrc];

        if (!resKey) {
            return res.status(400).json({ ok: false, error: `Tile "${campSrc}" non è un camp saccheggiabile.` });
        }

        if (resources <= 0) {
            return res.json({ ok: true, data: { looted: 0, resource: resKey } });
        }

        // 2. Aggiunge le risorse all'utente
        await csvHandler.addResources(userId, { [resKey]: resources });

        // 3. Azzera le risorse del camp sulla mappa
        await csvHandler.updateMapTileResources(Number(row), Number(col), -resources);

        console.log(`[Loot] ${userId} ha saccheggiato (${row},${col}) → +${resources} ${resKey}`);

        res.json({ ok: true, data: { looted: resources, resource: resKey } });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// ─────────────────────────────────────────────────────────────
//  Catch-all — SPA fallback
//  Qualsiasi route non-API rimanda a index.html.
//  Necessario per il routing client-side.
// ─────────────────────────────────────────────────────────────

app.get(/^(.*)$/, (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'index.html'));
});


// ─────────────────────────────────────────────────────────────
//  Avvio del server
// ─────────────────────────────────────────────────────────────

app.listen(PORT, () => {
    console.log(`Lords Mobile server avviato → http://localhost:${PORT}`);
});

// Esportato per eventuali test con Jest/Supertest
module.exports = app;