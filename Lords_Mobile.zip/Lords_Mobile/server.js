/**
 * ============================================================
 *  server.js
 *  Entry point — server Express per Lords Mobile
 * ============================================================
 *
 *  Avvio:  node server.js   (oppure: npm start)
 *  Porta:  3000 di default, oppure la variabile PORT
 *
 *  Struttura delle route:
 *    /api/users/:id          → jsonHandler  (profili utente, JSON)
 *    /api/resources/:userId  → csvHandler   (risorse, CSV)
 *    /api/battles/...        → xmlHandler   (log battaglie, XML)
 * ============================================================
 */

const express = require('express');
const path    = require('path');

// I tre handler gestiscono rispettivamente JSON, CSV e XML
const jsonHandler = require('./src/parsers/jsonHandler');
const csvHandler  = require('./src/parsers/csvHandler');
const xmlHandler  = require('./src/parsers/xmlHandler');

const app  = express();
const PORT = process.env.PORT || 3000;

// Serve i file nella cartella /data come file statici (scaricabili dal browser)
app.use('/data', express.static(path.join(__dirname, 'data')));


// ─────────────────────────────────────────────────────────────
//  Middleware globali
// ─────────────────────────────────────────────────────────────

// Permette al server di leggere il body delle richieste POST/PUT come JSON
app.use(express.json());

// Permette di leggere body da form HTML standard (application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));

// Serve i file statici (index.html, CSS, app.js) dalla cartella src/
app.use(express.static(path.join(__dirname, 'src')));


// ════════════════════════════════════════════════════
//  POWER — ricalcola e salva la potenza dell'utente
//  Formula: (totale truppe × 100) + (totale risorse × 5)
// ════════════════════════════════════════════════════

async function recalcPower(userId) {
    try {
        // Leggo le truppe e le risorse dell'utente in sequenza
        const troopsRes = await csvHandler.readTroops(userId);
        const resRes    = await csvHandler.readResources(userId);

        // Se un valore non esiste uso 0 come fallback
        const totalTroops =
            (troopsRes.fanteria   || 0) +
            (troopsRes.cavalleria || 0) +
            (troopsRes.arceri     || 0) +
            (troopsRes.balliste   || 0);

        const totalResources =
            (resRes.grano    || 0) +
            (resRes.legno    || 0) +
            (resRes.pietra   || 0) +
            (resRes.minerali || 0);

        const power = (totalTroops * 100) + (totalResources * 5);

        await jsonHandler.updateUser(userId, { power: power });

        return power;

    } catch (err) {
        console.warn('[Power] Errore ricalcolo per ' + userId + ':', err.message);
    }
}


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — UTENTI  (dati salvati in JSON)
//  File toccati: data/output/<userId>.json
// ═══════════════════════════════════════════════════════════════════════════════

// Legge il profilo di un utente
app.get('/api/users/:id', async function(req, res) {
    try {
        const user = await jsonHandler.readUser(req.params.id);
        res.json({ ok: true, data: user });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Crea un nuovo utente
// Body atteso: { id, name, level?, power?, guild? }
app.post('/api/users', async function(req, res) {
    try {
        const newUser = await jsonHandler.createUser(req.body);
        res.status(201).json({ ok: true, data: newUser });
    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — LOGIN
// ═══════════════════════════════════════════════════════════════════════════════

app.post('/api/users/login', async function(req, res) {
    try {
        const name     = req.body.name;
        const password = req.body.password;

        if (!name || !password) {
            return res.status(400).json({ ok: false, error: 'Nome e password obbligatori.' });
        }

        // Cerca l'utente per nome tra tutti i file salvati
        const user = await jsonHandler.findUserByName(name);

        if (!user) {
            return res.status(404).json({ ok: false, error: 'Utente non trovato.' });
        }

        // Controllo password (in chiaro)
        if (user.password !== password) {
            return res.status(401).json({ ok: false, error: 'Password errata.' });
        }

        // Login riuscito — restituiamo solo i dati necessari al client
        res.json({
            ok: true,
            data: {
                id:         user.id,
                name:       user.name,
                castleRow:  user.castleRow,
                castleCol:  user.castleCol
            }
        });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// Aggiorna i campi di un utente (solo quelli forniti nel body)
app.put('/api/users/:id', async function(req, res) {
    try {
        const updated = await jsonHandler.updateUser(req.params.id, req.body);
        res.json({ ok: true, data: updated });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Elimina un utente
app.delete('/api/users/:id', async function(req, res) {
    try {
        await jsonHandler.deleteUser(req.params.id);
        res.json({ ok: true, message: 'Utente ' + req.params.id + ' eliminato.' });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — RISORSE  (dati salvati in CSV)
//  File toccati: data/output/<userId>_resources.csv
// ═══════════════════════════════════════════════════════════════════════════════

// Legge le risorse attuali dell'utente
app.get('/api/resources/:userId', async function(req, res) {
    try {
        const resources = await csvHandler.readResources(req.params.userId);
        res.json({ ok: true, data: resources });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Crea le risorse iniziali dell'utente (chiamata una volta sola alla registrazione)
// Body atteso: { grano?, legno?, oro?, pietra?, ferro? }
app.post('/api/resources/:userId', async function(req, res) {
    try {
        const resources = await csvHandler.createResources(req.params.userId, req.body);
        res.status(201).json({ ok: true, data: resources });
    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Sovrascrive le risorse con valori assoluti (utile per admin/cheat)
app.put('/api/resources/:userId', async function(req, res) {
    try {
        const updated = await csvHandler.updateResources(req.params.userId, req.body);
        await recalcPower(req.params.userId);
        res.json({ ok: true, data: updated });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Aggiunge (o sottrae) risorse in modo incrementale
// Body atteso: { grano?: ±N, legno?: ±N, ... }
app.patch('/api/resources/:userId/add', async function(req, res) {
    try {
        const updated = await csvHandler.addResources(req.params.userId, req.body);
        await recalcPower(req.params.userId);
        res.json({ ok: true, data: updated });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — BATTAGLIE  (dati salvati in XML)
//  File toccati: data/output/battle_<battleId>.xml
// ═══════════════════════════════════════════════════════════════════════════════

// Restituisce tutte le battaglie di un utente (attaccante o difensore)
app.get('/api/battles/user/:userId', async function(req, res) {
    try {
        const battles = await xmlHandler.getBattlesByUser(req.params.userId);
        res.json({ ok: true, data: battles });
    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// Legge il log di una singola battaglia
app.get('/api/battles/:battleId', async function(req, res) {
    try {
        const battle = await xmlHandler.readBattleLog(req.params.battleId);
        res.json({ ok: true, data: battle });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Salva il risultato di una nuova battaglia
app.post('/api/battles', async function(req, res) {
    try {
        const battle = await xmlHandler.saveBattleLog(req.body);
        res.status(201).json({ ok: true, data: battle });
    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Elimina il log di una battaglia
app.delete('/api/battles/:battleId', async function(req, res) {
    try {
        await xmlHandler.deleteBattleLog(req.params.battleId);
        res.json({ ok: true, message: 'Battaglia ' + req.params.battleId + ' eliminata.' });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — MAPPA  (salvata in mappa.csv)
//  GET /api/map → restituisce la mappa esistente o la genera ex novo
// ═══════════════════════════════════════════════════════════════════════════════

const MAP_COLS = 15;
const MAP_ROWS = 30;

// Possibili tipi di tile per ogni categoria
const GRASS_TYPES = ['grass1', 'grass2', 'grass3'];
const CAMP_TYPES  = ['campwheat', 'campmineral', 'camprock', 'campwood'];
const TREE_TYPES  = ['trees1', 'trees2', 'trees3'];

// Risorse iniziali assegnate ad ogni tipo di campo al momento della generazione
const CAMP_INITIAL_RESOURCES = {
    campwheat:   5000,
    campmineral: 3000,
    camprock:    4000,
    campwood:    4500
};

app.get('/api/map', async function(req, res) {
    try {
        let mapData = await csvHandler.readMap();

        // Se la mappa non esiste ancora, la generiamo da zero
        if (!mapData) {
            console.log('[Map] mappa.csv non trovato — genero la mappa...');

            const tileMap = [];

            for (let r = 0; r < MAP_ROWS; r++) {
                tileMap[r] = [];

                for (let c = 0; c < MAP_COLS; c++) {
                    const randomChance = Math.random();

                    let selectedTile;
                    let resources = null; // Erba e alberi non hanno risorse

                    if (randomChance < 0.80) {
                        // 80% di probabilità: erba
                        const index = Math.floor(Math.random() * GRASS_TYPES.length);
                        selectedTile = GRASS_TYPES[index];

                    } else if (randomChance < 0.90) {
                        // 10% di probabilità: alberi
                        const index = Math.floor(Math.random() * TREE_TYPES.length);
                        selectedTile = TREE_TYPES[index];

                    } else {
                        // 10% di probabilità: campo risorse
                        const index = Math.floor(Math.random() * CAMP_TYPES.length);
                        selectedTile = CAMP_TYPES[index];
                        resources    = CAMP_INITIAL_RESOURCES[selectedTile] || 1000;
                    }

                    tileMap[r][c] = {
                        src:     selectedTile,
                        resources: resources,
                        ownerId: null
                    };
                }
            }

            mapData = await csvHandler.writeMap(MAP_COLS, MAP_ROWS, tileMap);
            console.log('[Map] mappa.csv creato con risorse.');
        }

        res.json({ ok: true, data: mapData });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// ─────────────────────────────────────────────────────────────
//  ROUTE — TRUPPE
// ─────────────────────────────────────────────────────────────

app.get('/api/troops/:userId', async function(req, res) {
    try {
        const troops = await csvHandler.readTroops(req.params.userId);
        res.json({ ok: true, data: troops });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});

app.post('/api/troops/:userId', async function(req, res) {
    try {
        const troops = await csvHandler.createTroops(req.params.userId, req.body);
        await recalcPower(req.params.userId);
        res.status(201).json({ ok: true, data: troops });
    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});

app.put('/api/troops/:userId', async function(req, res) {
    try {
        const troops = await csvHandler.updateTroops(req.params.userId, req.body);
        await recalcPower(req.params.userId);
        res.json({ ok: true, data: troops });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — MAPSIZE
//  GET /api/mapsize → restituisce solo cols e rows
//  Usata dal client in fase di registrazione per calcolare la posizione castello
// ═══════════════════════════════════════════════════════════════════════════════

app.get('/api/mapsize', async function(req, res) {
    try {
        const size = await csvHandler.readMapSize();
        console.log(size);
        res.json({ ok: true, data: size });
    } catch (err) {
        // Se mappa.csv non esiste ancora, restituisce le costanti di default
        res.json({ ok: true, data: { cols: MAP_COLS, rows: MAP_ROWS } });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — SET TILE
//  PATCH /api/map/tile → sovrascrive una singola cella nella mappa
//  Body atteso: { row, col, tileKey, ownerId }
// ═══════════════════════════════════════════════════════════════════════════════

app.patch('/api/map/tile', async function(req, res) {
    try {
        const row     = req.body.row;
        const col     = req.body.col;
        const tileKey = req.body.tileKey;
        const ownerId = req.body.ownerId;

        console.log(ownerId);

        await csvHandler.setMapTile(Number(row), Number(col), tileKey, ownerId);
        res.json({ ok: true, data: { row: row, col: col, tileKey: tileKey, ownerId: ownerId } });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// ════════════════════════════════════════════════════
//  MAP REGENERATION — ogni ora
//  Tiene i castelli, rigenera tutto il resto
// ════════════════════════════════════════════════════

async function regenerateMap() {
    try {
        const existing = await csvHandler.readMap();
        if (!existing) {
            console.warn('[Map] Nessuna mappa da rigenerare.');
            return;
        }

        const cols = existing.cols;
        const rows = existing.rows;
        const map  = existing.map;

        // 1. Raccoglie tutte le posizioni dei castelli prima di rigenerare
        const castles = [];
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const tile = map[r][c];

                // Il tile può essere una stringa semplice o un oggetto con .src
                let src;
                if (typeof tile === 'string') {
                    src = tile;
                } else {
                    src = tile.src;
                }

                if (src === 'mainplayer' || src === 'enemyplayer') {
                    // Salva il castello con la sua posizione e proprietario
                    let ownerId = null;
                    if (tile && tile.ownerId) {
                        ownerId = tile.ownerId;
                    }
                    castles.push({ row: r, col: c, src: src, ownerId: ownerId });
                }
            }
        }

        // 2. Costruisce un insieme con le posizioni dei castelli (per escluderle)
        //    Formato: "riga,colonna" — es. "12,7"
        const castlePositions = {};
        for (let i = 0; i < castles.length; i++) {
            const key = castles[i].row + ',' + castles[i].col;
            castlePositions[key] = true;
        }

        // 3. Genera mappa completamente nuova
        const newMap = [];
        for (let r = 0; r < rows; r++) {
            newMap[r] = [];
            for (let c = 0; c < cols; c++) {
                const key = r + ',' + c;

                // Le posizioni castello vengono saltate — ci tornano dopo
                if (castlePositions[key]) {
                    newMap[r][c] = { src: 'grass1', resources: null, ownerId: null };
                    continue;
                }

                const randomChance = Math.random();
                let src;
                let resources = null;

                if (randomChance < 0.80) {
                    const index = Math.floor(Math.random() * GRASS_TYPES.length);
                    src = GRASS_TYPES[index];
                } else if (randomChance < 0.90) {
                    const index = Math.floor(Math.random() * TREE_TYPES.length);
                    src = TREE_TYPES[index];
                } else {
                    const index = Math.floor(Math.random() * CAMP_TYPES.length);
                    src       = CAMP_TYPES[index];
                    resources = CAMP_INITIAL_RESOURCES[src] || 1000;
                }

                newMap[r][c] = { src: src, resources: resources, ownerId: null };
            }
        }

        // 4. Rimette i castelli nelle posizioni originali
        for (let i = 0; i < castles.length; i++) {
            const castle = castles[i];
            newMap[castle.row][castle.col] = {
                src:       castle.src,
                resources: null,
                ownerId:   castle.ownerId
            };
        }

        await csvHandler.writeMap(cols, rows, newMap);

        // 5. Aggiorna il timestamp — il client lo confronta per capire se ricaricare la mappa
        mapVersion = Date.now();

        console.log('[Map] Rigenerata. Castelli preservati: ' + castles.length + '. Versione: ' + mapVersion);

    } catch (err) {
        console.error('[Map] Errore rigenerazione:', err.message);
    }
}

// Timestamp aggiornato ad ogni rigenerazione
let mapVersion = Date.now();

// Prima rigenerazione dopo 1 ora, poi ogni ora
setInterval(regenerateMap, 1000 * 60 * 60);

// Route leggera: il client chiede solo se la versione è cambiata
app.get('/api/map/version', function(req, res) {
    res.json({ ok: true, data: { version: mapVersion } });
});


// ════════════════════════════════════════════════════
//  MARCE — persistenza su XML, truppe su CSV
// ════════════════════════════════════════════════════

// Crea una nuova marcia:
// 1. Toglie le truppe dal CSV
// 2. Scrive la marcia nell'XML dell'utente
app.post('/api/marches', async function(req, res) {
    const userId          = req.body.userId;
    const castleRow       = req.body.castleRow;
    const castleCol       = req.body.castleCol;
    const targetRow       = req.body.targetRow;
    const targetCol       = req.body.targetCol;
    const troops          = req.body.troops;
    const troopType       = req.body.troopType;
    const durationSeconds = req.body.durationSeconds;
    const startTime       = req.body.startTime;
    const gatherDuration  = req.body.gatherDuration;  // durata raccolta risorse

    if (!userId || !troopType || troops === undefined) {
        return res.status(400).json({ ok: false, error: 'Dati marcia incompleti.' });
    }

    try {
        const current = await csvHandler.readTroops(userId);

        // Controlla che l'utente abbia abbastanza truppe del tipo richiesto
        if ((current[troopType] || 0) < troops) {
            return res.status(400).json({ ok: false, error: 'Truppe insufficienti: ' + troopType + '.' });
        }

        // Copia l'oggetto truppe e sottrae quelle in marcia
        const updated = Object.assign({}, current);
        updated[troopType] = current[troopType] - Number(troops);
        await csvHandler.updateTroops(userId, updated);

        // ID univoco per la marcia: userId + timestamp + stringa casuale
        const marchId = userId + '_' + startTime + '_' + Math.random().toString(36).slice(2);

        await xmlHandler.saveMarchLog(userId, {
            marchId:         marchId,
            userId:          userId,
            castleRow:       Number(castleRow),
            castleCol:       Number(castleCol),
            targetRow:       Number(targetRow),
            targetCol:       Number(targetCol),
            troops:          Number(troops),
            troopType:       troopType,
            durationSeconds: Number(durationSeconds),
            gatherDuration:  Number(gatherDuration || 10),
            startTime:       Number(startTime)
        });

        await recalcPower(userId);

        res.status(201).json({ ok: true, data: { marchId: marchId } });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// Restituisce tutte le marce attive di un utente
// Calcola avanzamento e posizione attuale interpolata
app.get('/api/marches/:userId', async function(req, res) {
    const userId = req.params.userId;
    const now    = Date.now();

    try {
        const marches = await xmlHandler.readMarchLogs(userId);
        const result  = [];

        for (let i = 0; i < marches.length; i++) {
            const march = marches[i];

            // Quanto tempo è passato dall'inizio della marcia, in secondi
            const elapsed  = (now - march.startTime) / 1000;

            // Progresso da 0 (inizio) a 1 (arrivato)
            const progress = Math.min(elapsed / march.durationSeconds, 1);

            // Posizione attuale interpolata tra castello e destinazione
            const currentRow = march.castleRow + (march.targetRow - march.castleRow) * progress;
            const currentCol = march.castleCol + (march.targetCol - march.castleCol) * progress;

            // Copia i dati della marcia e aggiunge i campi calcolati
            const enriched = Object.assign({}, march);
            enriched.progress   = progress;
            enriched.currentRow = currentRow;
            enriched.currentCol = currentCol;

            result.push(enriched);
        }

        res.json({ ok: true, data: result });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// Termina una marcia:
// 1. Legge i dati dall'XML
// 2. Restituisce le truppe al CSV (se la marcia non è stata cancellata in battaglia)
// 3. Elimina la marcia dall'XML
app.delete('/api/marches/:userId/:marchId', async function(req, res) {
    const userId  = req.params.userId;
    const marchId = req.params.marchId;

    // Se il parametro returnTroops è 'false', non si restituiscono le truppe
    const returnTroops = req.query.returnTroops !== 'false'; // default: true

    try {
        const march = await xmlHandler.deleteMarchLog(userId, marchId);

        if (!march) {
            return res.status(404).json({ ok: false, error: 'Marcia non trovata.' });
        }

        // Restituisce le truppe solo se la marcia è completata normalmente
        if (returnTroops && march.troopType && march.troops > 0) {
            const current = await csvHandler.readTroops(userId);
            const updated = Object.assign({}, current);
            updated[march.troopType] = (current[march.troopType] || 0) + march.troops;
            await csvHandler.updateTroops(userId, updated);
        }

        await recalcPower(userId);

        res.json({
            ok: true,
            data: {
                marchId:       marchId,
                troopsReturned: returnTroops ? march.troops : 0
            }
        });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// ════════════════════════════════════════════════════
//  ROUTE — LOOT CAMP
//  POST /api/map/loot
//  Legge le risorse di un camp, le aggiunge all'utente,
//  diminuisce le risorse del campo.
//  Body: { userId, row, col, troops }
// ════════════════════════════════════════════════════

// Associa ogni tipo di camp alla chiave risorsa corrispondente nell'inventario utente
const CAMP_RESOURCE_MAP = {
    campwheat:   'grano',
    campwood:    'legno',
    campmineral: 'minerali',
    camprock:    'pietra'
};

app.post('/api/map/loot', async function(req, res) {
    const userId = req.body.userId;
    const row    = req.body.row;
    const col    = req.body.col;
    const troops = req.body.troops;

    if (!userId || row === undefined || col === undefined) {
        return res.status(400).json({ ok: false, error: 'userId, row e col obbligatori.' });
    }

    try {
        const mapData = await csvHandler.readMap();
        if (!mapData) {
            return res.status(500).json({ ok: false, error: 'Mappa non trovata.' });
        }

        // Legge la tile alla posizione indicata
        const tile = mapData.map[Number(row)] && mapData.map[Number(row)][Number(col)];
        if (!tile) {
            return res.status(404).json({ ok: false, error: 'Tile (' + row + ', ' + col + ') non trovata.' });
        }

        // Recupera il tipo di tile (può essere stringa o oggetto)
        let campSrc;
        if (typeof tile === 'string') {
            campSrc = tile;
        } else {
            campSrc = tile.src;
        }

        // Recupera le risorse disponibili nel campo
        let available = 0;
        if (typeof tile === 'object' && tile.resources !== undefined && tile.resources !== null) {
            available = tile.resources;
        }

        // Trova la chiave risorsa corrispondente al tipo di campo
        const resKey = CAMP_RESOURCE_MAP[campSrc];

        if (!resKey) {
            return res.status(400).json({ ok: false, error: 'Tile "' + campSrc + '" non è un camp saccheggiabile.' });
        }

        // Se il campo è già vuoto, non c'è nulla da prendere
        if (available <= 0) {
            return res.json({ ok: true, data: { looted: 0, resource: resKey } });
        }

        // Ogni truppa raccoglie 2 unità di risorsa, ma non si può superare il disponibile
        const requested = Number(troops || 0) * 2;
        const looted    = Math.min(requested, available);

        await csvHandler.addResources(userId, { [resKey]: looted });
        await csvHandler.updateMapTileResources(Number(row), Number(col), -looted);
        await recalcPower(userId);

        console.log('[Loot] ' + userId + ' → (' + row + ',' + col + '): ' +
            troops + ' truppe × 2 = ' + looted + ' ' + resKey +
            ' (disponibili: ' + available + ')');

        res.json({ ok: true, data: { looted: looted, resource: resKey } });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// ════════════════════════════════════════════════════
//  ROUTE — RISOLUZIONE BATTAGLIA
//  POST /api/battles/resolve
// ════════════════════════════════════════════════════

app.post('/api/battles/resolve', async function(req, res) {
    const attackerId  = req.body.attackerId;
    const defenderId  = req.body.defenderId;
    const troopType   = req.body.troopType;
    const marchTroops = req.body.marchTroops;

    if (!attackerId || !defenderId || !troopType) {
        return res.status(400).json({ ok: false, error: 'Campi obbligatori mancanti.' });
    }

    try {
        // Legge le truppe di attaccante e difensore
        const atkTroops = await csvHandler.readTroops(attackerId);
        const defTroops = await csvHandler.readTroops(defenderId);

        // Le truppe attaccanti sono quelle della marcia (non quelle nel CSV — sono già state tolte)
        const atkCount = Number(marchTroops || 0);

        // Le truppe difensore sono la somma di tutti i tipi
        const defCount =
            (defTroops.fanteria   || 0) +
            (defTroops.cavalleria || 0) +
            (defTroops.arceri     || 0) +
            (defTroops.balliste   || 0);

        if (atkCount === 0) {
            return res.status(400).json({ ok: false, error: 'Nessuna truppa in marcia.' });
        }

        // L'attaccante vince se ha almeno tante truppe quanto il difensore
        const attackerWins = atkCount >= defCount;

        // Perdite attaccante: se vince perde tante truppe quante il difensore (massimo le sue), altrimenti tutte
        const atkLosses    = attackerWins ? Math.min(defCount, atkCount) : atkCount;
        const atkSurvivors = Math.max(0, atkCount - atkLosses);

        // Perdite difensore: se perde, perde tutto — se vince, perde tante truppe quante l'attaccante
        const defLosses = attackerWins ? defCount : Math.min(atkCount, defCount);

        // Restituisce i sopravvissuti attaccanti al CSV
        if (atkSurvivors > 0) {
            const updatedAtk = Object.assign({}, atkTroops);
            updatedAtk[troopType] = (atkTroops[troopType] || 0) + atkSurvivors;
            await csvHandler.updateTroops(attackerId, updatedAtk);
        }

        // Aggiorna le truppe del difensore in proporzione alle perdite
        if (defCount > 0) {
            const ratio = Math.max(0, (defCount - defLosses) / defCount);
            await csvHandler.updateTroops(defenderId, {
                fanteria:   Math.floor((defTroops.fanteria   || 0) * ratio),
                cavalleria: Math.floor((defTroops.cavalleria || 0) * ratio),
                arceri:     Math.floor((defTroops.arceri     || 0) * ratio),
                balliste:   Math.floor((defTroops.balliste   || 0) * ratio)
            });
        }

        // Loot: 50% delle risorse del difensore, solo se l'attaccante vince
        const loot = { grano: 0, legno: 0, pietra: 0, minerali: 0 };

        if (attackerWins) {
            const defRes = await csvHandler.readResources(defenderId);

            loot.grano    = Math.floor((defRes.grano    || 0) * 0.5);
            loot.legno    = Math.floor((defRes.legno    || 0) * 0.5);
            loot.pietra   = Math.floor((defRes.pietra   || 0) * 0.5);
            loot.minerali = Math.floor((defRes.minerali || 0) * 0.5);

            // Aggiunge il loot all'attaccante e lo toglie al difensore
            await csvHandler.addResources(attackerId, loot);
            await csvHandler.addResources(defenderId, {
                grano:    -loot.grano,
                legno:    -loot.legno,
                pietra:   -loot.pietra,
                minerali: -loot.minerali
            });
        }

        // Salva il log della battaglia in XML
        const atkUser = await jsonHandler.readUser(attackerId);
        const defUser = await jsonHandler.readUser(defenderId);

        await xmlHandler.saveBattleLog({
            attackerId:      attackerId,
            attackerName:    atkUser.name || attackerId,
            attackerTroops:  atkCount,
            attackerLosses:  atkLosses,
            defenderId:      defenderId,
            defenderName:    defUser.name || defenderId,
            defenderTroops:  defCount,
            defenderLosses:  defLosses,
            winner:          attackerWins ? 'attacker' : 'defender',
            loot:            loot
        });

        // Aggiorna la potenza di entrambi
        await recalcPower(attackerId);
        await recalcPower(defenderId);

        console.log('[Battle] ' + attackerId + '(' + atkCount + ') vs ' +
            defenderId + '(' + defCount + ') → ' +
            (attackerWins ? 'ATK' : 'DEF') + ' vince | superstiti ATK: ' + atkSurvivors);

        res.json({
            ok: true,
            data: {
                winner:             attackerWins ? 'attacker' : 'defender',
                attackerLosses:     atkLosses,
                attackerSurvivors:  atkSurvivors,
                defenderLosses:     defLosses,
                loot:               loot
            }
        });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// ─────────────────────────────────────────────────────────────
//  Catch-all — SPA fallback
//  Qualsiasi route non-API rimanda a index.html.
//  Necessario per il routing client-side.
// ─────────────────────────────────────────────────────────────

app.get(/^(.*)$/, function(req, res) {
    res.sendFile(path.join(__dirname, 'src', 'index.html'));
});


// ─────────────────────────────────────────────────────────────
//  Avvio del server
// ─────────────────────────────────────────────────────────────

app.listen(PORT, function() {
    console.log('Lords Mobile server avviato → http://localhost:' + PORT);
});

// Esportato per eventuali test con Jest/Supertest
module.exports = app;