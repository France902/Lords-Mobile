/**
 * ============================================================
 *  server.js
 *  Entry point — server Express per Lords Mobile
 * ============================================================
 *
 *  Avvio:  node server.js   (oppure: npm start)
 *  Porta:  3000 di default, oppure la variabile PORT
 *
 *  Struttura delle route:
 *    /api/users/:id          → jsonHandler  (profili utente, JSON)
 *    /api/resources/:userId  → csvHandler   (risorse, CSV)
 *    /api/battles/...        → xmlHandler   (log battaglie, XML)
 *    *                       → index.html   (SPA client)
 * ============================================================
 */

const express = require('express');
const path    = require('path');


// I tre handler gestiscono rispettivamente JSON, CSV e XML
const jsonHandler = require('./src/parsers/jsonHandler');
const csvHandler  = require('./src/parsers/csvHandler');
const xmlHandler  = require('./src/parsers/xmlHandler');

const app  = express();
const PORT = process.env.PORT || 3000;


app.use('/data', express.static(path.join(__dirname, 'data')));



// ─────────────────────────────────────────────────────────────
//  Middleware globali
// ─────────────────────────────────────────────────────────────

// Permette al server di leggere il body delle richieste POST/PUT come JSON
app.use(express.json());

// Permette di leggere body da form HTML standard (application/x-www-form-urlencoded)
app.use(express.urlencoded({ extended: true }));

// Serve i file statici (index.html, CSS, app.js) dalla cartella src/
app.use(express.static(path.join(__dirname, 'src')));


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — UTENTI  (dati salvati in JSON)
//  File toccati: data/output/<userId>.json
// ═══════════════════════════════════════════════════════════════════════════════

// Legge il profilo di un utente
// ← app.js chiama: loadUser(userId)
app.get('/api/users/:id', async (req, res) => {

    try {
        const user = await jsonHandler.readUser(req.params.id);
        res.json({ ok: true, data: user });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Crea un nuovo utente
// Body atteso: { id, name, level?, power?, guild? }
// ← app.js chiama: createUser()
app.post('/api/users', async (req, res) => {

    try {
        const newUser = await jsonHandler.createUser(req.body);
        res.status(201).json({ ok: true, data: newUser });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Aggiorna i campi di un utente (solo quelli forniti nel body)
// Body atteso: { level?, power?, guild?, ... }
// ← app.js chiama: levelUpUser(userId, newLevel, newPower)
app.put('/api/users/:id', async (req, res) => {

    try {
        const updated = await jsonHandler.updateUser(req.params.id, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Elimina un utente
// ← non usato direttamente in app.js, disponibile per admin/debug
app.delete('/api/users/:id', async (req, res) => {

    try {
        await jsonHandler.deleteUser(req.params.id);
        res.json({ ok: true, message: `Utente ${req.params.id} eliminato.` });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — RISORSE  (dati salvati in CSV)
//  File toccati: data/output/<userId>_resources.csv
// ═══════════════════════════════════════════════════════════════════════════════

// Legge le risorse attuali dell'utente
// ← app.js chiama: loadResources(userId)
app.get('/api/resources/:userId', async (req, res) => {

    try {
        const resources = await csvHandler.readResources(req.params.userId);
        res.json({ ok: true, data: resources });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Crea le risorse iniziali dell'utente (da usare una volta sola alla registrazione)
// Body atteso: { grano?, legno?, oro?, pietra?, ferro? }
// ← app.js chiama: initResources(userId)
app.post('/api/resources/:userId', async (req, res) => {

    try {
        const resources = await csvHandler.createResources(req.params.userId, req.body);
        res.status(201).json({ ok: true, data: resources });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Sovrascrive le risorse con nuovi valori assoluti
// Body atteso: { grano?, legno?, oro?, pietra?, ferro? }
// ← non usato in app.js di default, utile per cheat/admin
app.put('/api/resources/:userId', async (req, res) => {

    try {
        const updated = await csvHandler.updateResources(req.params.userId, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Aggiunge (o sottrae) risorse in modo incrementale
// Body atteso: { grano?: ±N, legno?: ±N, oro?: ±N, ... }
// ← app.js chiama: applyLoot(userId, loot)  dopo ogni battaglia
app.patch('/api/resources/:userId/add', async (req, res) => {

    try {
        const updated = await csvHandler.addResources(req.params.userId, req.body);
        res.json({ ok: true, data: updated });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — BATTAGLIE  (dati salvati in XML)
//  File toccati: data/output/battle_<battleId>.xml
//
//  ATTENZIONE all'ordine delle route:
//  "/api/battles/user/:userId" deve stare PRIMA di "/api/battles/:battleId"
//  altrimenti Express interpreta "user" come un battleId.
// ═══════════════════════════════════════════════════════════════════════════════

// Restituisce tutte le battaglie di un utente (attaccante o difensore)
// ← app.js chiama: loadBattleHistory(userId)
app.get('/api/battles/user/:userId', async (req, res) => {

    try {
        const battles = await xmlHandler.getBattlesByUser(req.params.userId);
        res.json({ ok: true, data: battles });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});


// Legge il log di una singola battaglia
// ← non usato in app.js di default, utile per mostrare il dettaglio di una battaglia
app.get('/api/battles/:battleId', async (req, res) => {

    try {
        const battle = await xmlHandler.readBattleLog(req.params.battleId);
        res.json({ ok: true, data: battle });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});


// Salva il risultato di una nuova battaglia
// Body atteso: { attackerId, attackerName?, attackerTroops?, attackerLosses?,
//               defenderId, defenderName?, defenderTroops?, defenderLosses?,
//               winner, loot?: { oro, grano, legno } }
// ← app.js chiama: resolveBattle(attacker, defender, result)
app.post('/api/battles', async (req, res) => {

    try {
        const battle = await xmlHandler.saveBattleLog(req.body);
        res.status(201).json({ ok: true, data: battle });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});


// Elimina il log di una battaglia
// ← non usato in app.js di default, utile per admin/debug
app.delete('/api/battles/:battleId', async (req, res) => {

    try {
        await xmlHandler.deleteBattleLog(req.params.battleId);
        res.json({ ok: true, message: `Battaglia ${req.params.battleId} eliminata.` });

    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — MAPPA  (salvata in mappa.csv)
//  GET /api/map → restituisce la mappa esistente o la genera ex novo
// ═══════════════════════════════════════════════════════════════════════════════

const MAP_COLS  = 200;
const MAP_ROWS  = 200;

const GRASS_TYPES = ['grass1', 'grass2', 'grass3'];
const CAMP_TYPES = ['campwheat', 'campmineral', 'camprock', 'campwood'];
const CASTLE_TYPES = ['mainplayer', 'enemyplayer'];
const TREE_TYPES = ['trees1', 'trees2', 'trees3'];

const CAMP_INITIAL_RESOURCES = {
    campwheat: 5000,
    campmineral: 3000,
    camprock: 4000,
    campwood: 4500
};

app.get('/api/map', async (req, res) => {
    try {
        let mapData = await csvHandler.readMap();

        if (!mapData) {
            console.log('[Map] mappa.csv non trovato — genero la mappa...');

            const tileMap = [];
            for (let r = 0; r < MAP_ROWS; r++) {
                tileMap[r] = [];
                for (let c = 0; c < MAP_COLS; c++) {
                    const randomChance = Math.random(); 

                    let selectedTile;
                    let resources = null; // Default per erba e alberi

                    if (randomChance < 0.80) {
                        selectedTile = GRASS_TYPES[Math.floor(Math.random() * GRASS_TYPES.length)];
                    } else if(randomChance < 0.90) {
                        selectedTile = TREE_TYPES[Math.floor(Math.random() * TREE_TYPES.length)];
                    } else {
                        // È un CAMP
                        selectedTile = CAMP_TYPES[Math.floor(Math.random() * CAMP_TYPES.length)];
                        // Assegna le risorse in base al tipo di campo
                        resources = CAMP_INITIAL_RESOURCES[selectedTile] || 1000;
                    }

                    // Salviamo come oggetto per passare i dati al csvHandler
                    tileMap[r][c] = {
                        src: selectedTile,
                        resources: resources,
                        ownerId: null
                    };
                }
            }

            // Il tuo csvHandler.writeMap è già predisposto per ricevere oggetti o stringhe
            mapData = await csvHandler.writeMap(MAP_COLS, MAP_ROWS, tileMap);
            console.log('[Map] mappa.csv creato con risorse.');
        }

        res.json({ ok: true, data: mapData });

    } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
    }
});

app.get('/api/troops/:userId', async (req, res) => {
    try {
        const troops = await csvHandler.readTroops(req.params.userId);
        res.json({ ok: true, data: troops });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});

app.post('/api/troops/:userId', async (req, res) => {
    try {
        const troops = await csvHandler.createTroops(req.params.userId, req.body);
        res.status(201).json({ ok: true, data: troops });
    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});

app.put('/api/troops/:userId', async (req, res) => {
    try {
        const troops = await csvHandler.updateTroops(req.params.userId, req.body);
        res.json({ ok: true, data: troops });
    } catch (err) {
        res.status(404).json({ ok: false, error: err.message });
    }
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — MAPSIZE
//  GET /api/mapsize → restituisce solo cols e rows dalla prima riga del CSV
//  Usata dal client in fase di registrazione per calcolare la posizione castello
// ═══════════════════════════════════════════════════════════════════════════════

app.get('/api/mapsize', async (req, res) => {
    try {
        
        const size = await csvHandler.readMapSize();
        console.log(size);
        res.json({ ok: true, data: size });
    } catch (err) {
        // Se mappa.csv non esiste ancora, restituisce le costanti di default
        res.json({ ok: true, data: { cols: MAP_COLS, rows: MAP_ROWS } });
    }
});


// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTE — SET TILE
//  PATCH /api/map/tile → sovrascrive una singola cella nella mappa
//  Body atteso: { row, col, tileKey }
// ═══════════════════════════════════════════════════════════════════════════════

app.patch('/api/map/tile', async (req, res) => {
    try {
        const { row, col, tileKey } = req.body;

        if (row === undefined || col === undefined || !tileKey) {
            return res.status(400).json({ ok: false, error: 'row, col e tileKey sono obbligatori.' });
        }

        await csvHandler.setMapTile(Number(row), Number(col), tileKey);
        res.json({ ok: true, data: { row, col, tileKey } });

    } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
    }
});

// ════════════════════════════════════════════════════
//  MAP REGENERATION — ogni ora
//  Tiene i castelli, rigenera tutto il resto
// ════════════════════════════════════════════════════

async function regenerateMap() {

    try {
        const existing = await csvHandler.readMap();
        if (!existing) {
            console.warn('[Map] Nessuna mappa da rigenerare.');
            return;
        }

        const { cols, rows, map } = existing;

        // 1. Raccoglie tutte le posizioni castle prima di distruggerle
        const castles = [];
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const tile = map[r][c];
                const src  = typeof tile === 'string' ? tile : tile?.src;
                if (src === 'mainplayer' || src === 'enemyplayer') {
                    castles.push({
                        row:     r,
                        col:     c,
                        src,
                        ownerId: tile?.ownerId ?? null,
                    });
                }
            }
        }

        // 2. Genera mappa completamente nuova
        const castlePositions = new Set(castles.map(c => `${c.row},${c.col}`));
        const newMap = [];

        for (let r = 0; r < rows; r++) {
            newMap[r] = [];
            for (let c = 0; c < cols; c++) {

                // Le posizioni castello vengono saltate — ci tornano i castelli
                if (castlePositions.has(`${r},${c}`)) {
                    newMap[r][c] = { src: 'grass1', resources: null, ownerId: null };
                    continue;
                }

                const randomChance = Math.random();
                let src, resources = null;

                if (randomChance < 0.80) {
                    src = GRASS_TYPES[Math.floor(Math.random() * GRASS_TYPES.length)];
                } else if (randomChance < 0.90) {
                    src = TREE_TYPES[Math.floor(Math.random() * TREE_TYPES.length)];
                } else {
                    src       = CAMP_TYPES[Math.floor(Math.random() * CAMP_TYPES.length)];
                    resources = CAMP_INITIAL_RESOURCES[src] ?? 1000;
                }

                newMap[r][c] = { src, resources, ownerId: null };
            }
        }

        // 3. Rimette i castelli nelle posizioni originali
        for (const castle of castles) {
            newMap[castle.row][castle.col] = {
                src:     castle.src,
                resources: null,
                ownerId: castle.ownerId,
            };
        }

        await csvHandler.writeMap(cols, rows, newMap);

        // 4. Aggiorna il timestamp di versione — il client lo usa per sapere se ricaricare
        mapVersion = Date.now();

        console.log(`[Map] Rigenerata. Castelli preservati: ${castles.length}. Versione: ${mapVersion}`);

    } catch (err) {
        console.error('[Map] Errore rigenerazione:', err.message);
    }
}

// Timestamp che cambia ad ogni rigenerazione — usato dal client per polling leggero
let mapVersion = Date.now();

// Avvia il timer — prima rigenerazione dopo 1 ora, poi ogni ora
setInterval(regenerateMap, 10000);

// Route leggera — il client chiede solo se la versione è cambiata
// Se il numero è diverso dall'ultimo che conosce, scarica la mappa intera
app.get('/api/map/version', (req, res) => {
    res.json({ ok: true, data: { version: mapVersion } });
});


// ─────────────────────────────────────────────────────────────
//  Catch-all — SPA fallback
//  Qualsiasi route non-API rimanda a index.html.
//  Necessario per il routing client-side.
// ─────────────────────────────────────────────────────────────

app.get(/^(.*)$/, (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'index.html'));
});


// ─────────────────────────────────────────────────────────────
//  Avvio del server
// ─────────────────────────────────────────────────────────────

app.listen(PORT, () => {
    console.log(`Lords Mobile server avviato → http://localhost:${PORT}`);
});

// Esportato per eventuali test con Jest/Supertest
module.exports = app;